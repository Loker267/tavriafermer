window.TF = window.TF || {};

TF.Updater = {
  repo: window.TF_GITHUB_REPO || 'Loker267/tavriafermer',
  currentVersion: window.TF_APP_VERSION || '1.6.0',
  latestInfo: null,
  checking: false,

  init() {
    this.registerServiceWorker();
    // Тихая проверка через 1.2 сек после старта, чтобы не тормозить загрузку
    setTimeout(() => this.check(true), 1200);
  },

  registerServiceWorker() {
    if (!('serviceWorker' in navigator)) return;
    if (location.protocol !== 'https:' && location.protocol !== 'http:') return;
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  },

  compareVersions(a, b) {
    const pa = String(a || '0').replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b || '0').replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const na = pa[i] || 0, nb = pb[i] || 0;
      if (na > nb) return 1;
      if (na < nb) return -1;
    }
    return 0;
  },

  async fetchVersionJson(branch) {
    const url = `https://raw.githubusercontent.com/${this.repo}/${branch}/version.json?t=${Date.now()}`;
    const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), 5000) : null;
    try {
      const resp = await fetch(url, { cache: 'no-store', signal: ctrl ? ctrl.signal : undefined });
      if (timer) clearTimeout(timer);
      if (!resp.ok) return null;
      const data = await resp.json();
      if (!data || !data.version) return null;
      return { ...data, branch };
    } catch (e) {
      if (timer) clearTimeout(timer);
      return null;
    }
  },

  async check(silent = true) {
    if (this.checking) return;
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      if (!silent && TF.UI) TF.UI.toast('Нет подключения к интернету.');
      return;
    }
    this.checking = true;
    try {
      let remote = await this.fetchVersionJson('main');
      if (!remote) remote = await this.fetchVersionJson('master');
      if (!remote) {
        if (!silent && TF.UI) TF.UI.toast('Не удалось связаться с GitHub. Попробуй позже.');
        return;
      }
      if (this.compareVersions(remote.version, this.currentVersion) > 0) {
        this.latestInfo = remote;
        this.showUpdateModal(remote);
      } else if (!silent && TF.UI) {
        TF.UI.toast(`У тебя последняя версия игры (v${this.currentVersion}).`);
      }
    } finally {
      this.checking = false;
    }
  },

  showUpdateModal(info) {
    const existing = document.getElementById('tfUpdateBackdrop');
    if (existing) existing.remove();

    const isWeb = location.protocol === 'https:' || location.protocol === 'http:';
    const items = Array.isArray(info.changelog) ? info.changelog : (info.changelog ? [String(info.changelog)] : []);
    const listHtml = items.length
      ? `<ul class="upd-changelog">${items.map(line => `<li>${line}</li>`).join('')}</ul>`
      : '<p class="muted">Улучшения и исправления ошибок.</p>';

    const backdrop = document.createElement('div');
    backdrop.id = 'tfUpdateBackdrop';
    backdrop.className = 'modal-backdrop';
    backdrop.style.zIndex = '9999';
    backdrop.innerHTML = `
      <div class="modal-window upd-modal">
        <div class="modal-header">
          <div class="modal-title">🚀 Доступно обновление v${info.version}</div>
          <button class="modal-close" id="updCloseX" title="Закрыть и играть на старой версии">✕</button>
        </div>
        <div class="modal-body">
          <div class="upd-ver-row">
            <span class="vs-tag">Текущая: <b>v${this.currentVersion}</b></span>
            <span>→</span>
            <span class="vs-tag upd-ver-new">Новая: <b>v${info.version}</b></span>
            ${info.date ? `<span class="muted" style="margin-left:auto;">${info.date}</span>` : ''}
          </div>
          ${info.title ? `<div class="upd-subtitle">${info.title}</div>` : ''}
          <div class="info-card" style="margin:10px 0;">
            <strong>📋 Что нового:</strong>
            ${listHtml}
          </div>
          <div class="muted" style="font-size:12px;margin-bottom:12px;">
            💾 Твои сохранения полностью защищены и автоматически перенесутся в новую версию.
            ${isWeb ? '' : '<br>📦 При локальном запуске с диска скачается свежий ZIP-архив с GitHub — просто распакуй его поверх папки игры.'}
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button class="buy-btn" id="updApplyBtn" style="flex:1;">${isWeb ? '🔄 Обновить сейчас' : '⬇ Скачать v' + info.version + ' (.zip)'}</button>
            <button class="buy-btn secondary" id="updLaterBtn">Позже</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);

    const close = () => backdrop.remove();
    backdrop.querySelector('#updCloseX').onclick = close;
    backdrop.querySelector('#updLaterBtn').onclick = close;
    backdrop.onclick = (e) => { if (e.target === backdrop) close(); };
    backdrop.querySelector('#updApplyBtn').onclick = () => this.applyUpdate(info, backdrop);
  },

  async applyUpdate(info, backdrop) {
    // Сохраняем игру перед обновлением!
    if (TF.Game && TF.Game.save) TF.Game.save();
    const isWeb = location.protocol === 'https:' || location.protocol === 'http:';
    const btn = backdrop.querySelector('#updApplyBtn');

    if (isWeb) {
      if (btn) { btn.disabled = true; btn.textContent = '⏳ Загружаем обновление...'; }
      try {
        if ('caches' in window) {
          const keys = await caches.keys();
          await Promise.all(keys.map(k => caches.delete(k)));
        }
        if ('serviceWorker' in navigator) {
          const regs = await navigator.serviceWorker.getRegistrations();
          await Promise.all(regs.map(r => r.update().catch(() => {})));
        }
      } catch (e) {}
      const sep = location.search ? '&' : '?';
      location.replace(location.pathname + location.search.replace(/[?&]upd=\d+/, '') + sep + 'upd=' + Date.now());
    } else {
      const branch = info.branch || 'main';
      const defaultZip = `https://github.com/${this.repo}/raw/${branch}/tavria-farmer.zip`;
      const zipUrl = info.zipUrl || defaultZip;
      const a = document.createElement('a');
      a.href = zipUrl;
      a.download = `tavria-farmer-v${info.version}.zip`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      a.remove();
      if (TF.UI) TF.UI.toast(`⬇ Скачивание v${info.version} началось! Распакуй архив поверх папки игры.`);
      backdrop.remove();
    }
  }
};
