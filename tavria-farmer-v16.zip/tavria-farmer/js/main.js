window.TF = window.TF || {};

TF.Game = {
  SAVE_KEY: 'tavria_farmer_save_v8',
  BACKUP_KEY: 'tavria_farmer_save_backup',
  SAVE_VERSION: 3,
  shopParkingSlots: 2, // 2 стартовых слота у дилера в Тавричанке, можно докупать до 8!
  canvas: null,
  ctx: null,
  lightCanvas: null,
  lightCtx: null,
  miniCanvas: null,
  miniCtx: null,

  money: 48000,
  day: 1,
  totalDays: 1,
  seasonIdx: 0,
  hour: 8.0,
  timeSpeedIdx: 1,
  activeVehicleUid: null,

  stats: { harvestedLiters: 0, totalEarned: 0, contractsDone: 0 },
  contracts: [],
  villageRep: { 'Любимо-Павловка': 0, 'Дудчино': 0, 'Тавричанка': 0, 'Любимо-Марьевка': 0, 'Марьяновка': 0, 'Заозёрное': 0 },

  cam: { x: 1750, y: 5500, zoom: 0.72, freeMode: false },
  keys: {},
  joy: { active: false, id: null, dx: 0, dy: 0 },
  lastTime: 0,
  saveTimer: 0,

  init() {
    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas.getContext('2d');
    this.lightCanvas = document.createElement('canvas');
    this.lightCtx = this.lightCanvas.getContext('2d');
    this.miniCanvas = document.getElementById('minimapCanvas');
    this.miniCtx = this.miniCanvas.getContext('2d');

    TF.World.init();
    TF.Audio.init();
    if (TF.Radio) TF.Radio.init();
    if (TF.Updater) TF.Updater.init();
    TF.UI.init();

    if (!this.load()) this.setupNewGame();
    if (this.contracts.length === 0) this.generateContracts();

    this.resize();
    window.addEventListener('resize', () => {
      this.resize();
      if (TF.UI.fullMapOpen) TF.UI.drawFullMap();
    });
    this.bindInputs();

    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  },

  setupNewGame() {
    this.money = 48000;
    this.day = 1;
    this.totalDays = 1;
    this.seasonIdx = 0;
    this.hour = 8.0;
    this.stats = { harvestedLiters: 0, totalEarned: 0, contractsDone: 0 };
    this.contracts = [];
    this.villageRep = { 'Любимо-Павловка': 0, 'Дудчино': 0, 'Тавричанка': 0, 'Любимо-Марьевка': 0, 'Марьяновка': 0, 'Заозёрное': 0 };
    this.shopParkingSlots = 2;
    TF.Vehicles.reset();
    TF.AI.reset();

    // Стартовая техника красиво расставлена: МТЗ+прицеп у дороги, Нива+жатка у Поля №1, плуг и сеялка на слотах парковки P1 и P2 (P3 и P4 свободны!)
    const mtz = TF.Vehicles.spawn('mtz82', 1820, 5770, 0);
    const pts = TF.Vehicles.spawn('pts4', 1755, 5770, 0);
    const niva = TF.Vehicles.spawn('sk5_niva', 1840, 5260, 0);
    const hdr = TF.Vehicles.spawn('header_niva', 1890, 5260, 0);
    TF.Vehicles.spawn('pln335', 1525, 5625, 0);
    TF.Vehicles.spawn('sz36', 1645, 5625, 0);

    mtz.attachment = pts.uid; pts.attachedTo = mtz.uid;
    niva.frontAttachment = hdr.uid; hdr.attachedTo = niva.uid;

    this.activeVehicleUid = niva.uid;
    this.cam.x = niva.x; this.cam.y = niva.y;
    this.generateContracts();
    TF.UI.toast('Добро пожаловать в Любимо-Павловку! Урожай на Поле №1 уже созрел.');
  },

  getFieldVillage(field) {
    return TF.World.getNearestVillageName(field.x + field.w / 2, field.y + field.h / 2);
  },

  getVillageDiscount(villageName) {
    const rep = (this.villageRep && this.villageRep[villageName]) || 0;
    return Math.min(0.15, rep * 0.015);
  },

  getFieldBuyPrice(field) {
    const vName = this.getFieldVillage(field);
    return Math.round(field.price * (1 - this.getVillageDiscount(vName)));
  },

  getFieldVillage(field) {
    return TF.World.getNearestVillageName(field.x + field.w / 2, field.y + field.h / 2);
  },

  getVillageDiscount(villageName) {
    const rep = (this.villageRep && this.villageRep[villageName]) || 0;
    return Math.min(0.15, rep * 0.015);
  },

  getFieldBuyPrice(field) {
    const vName = this.getFieldVillage(field);
    return Math.round(field.price * (1 - this.getVillageDiscount(vName)));
  },

  getFieldVillage(field) {
    return TF.World.getNearestVillageName(field.x + field.w / 2, field.y + field.h / 2);
  },

  getVillageDiscount(villageName) {
    const rep = (this.villageRep && this.villageRep[villageName]) || 0;
    return Math.min(0.15, rep * 0.015);
  },

  getFieldBuyPrice(field) {
    const vName = this.getFieldVillage(field);
    return Math.round(field.price * (1 - this.getVillageDiscount(vName)));
  },

  getFieldVillage(field) {
    return TF.World.getNearestVillageName(field.x + field.w / 2, field.y + field.h / 2);
  },

  getVillageDiscount(villageName) {
    const rep = (this.villageRep && this.villageRep[villageName]) || 0;
    return Math.min(0.15, rep * 0.015);
  },

  getFieldBuyPrice(field) {
    const vName = this.getFieldVillage(field);
    return Math.round(field.price * (1 - this.getVillageDiscount(vName)));
  },

  generateContracts() {
    const unowned = TF.World.fields.filter(f => !f.owned);
    const activeIds = this.contracts.filter(c => c.accepted).map(c => c.fieldId);
    const pool = unowned.filter(f => !activeIds.includes(f.id));
    this.contracts = this.contracts.filter(c => c.accepted);

    const elevs = TF.DATA.STATIONS.filter(s => s.type === 'elevator');
    const cropIds = Object.keys(TF.DATA.CROPS);
    const types = ['plow', 'seed', 'fertilize', 'harvest', 'seed_fert'];

    while (this.contracts.length < 5 && pool.length > 0) {
      const f = pool.splice(Math.floor(Math.random() * pool.length), 1)[0];
      const vName = this.getFieldVillage(f);
      const rep = (this.villageRep && this.villageRep[vName]) || 0;
      const repBonus = 1 + Math.min(0.45, rep * 0.04);
      const type = types[Math.floor(Math.random() * types.length)];
      const cropId = cropIds[Math.floor(Math.random() * cropIds.length)];
      const cDef = TF.DATA.CROPS[cropId];
      const elev = elevs[Math.floor(Math.random() * elevs.length)];

      let title = '', desc = '', baseRate = 260, expectedLiters = 0;
      if (type === 'plow') {
        title = `Вспашка стерни (${vName})`;
        desc = `Вспахать или прокультивировать ${f.name}.`;
        baseRate = 230;
      } else if (type === 'seed') {
        title = `Посев: ${cDef.icon} ${cDef.name} (${vName})`;
        desc = `Засеять ${f.name} культурой «${cDef.name}». Семена за счёт заказчика.`;
        baseRate = 290;
      } else if (type === 'fertilize') {
        title = `Подкормка удобрением (${vName})`;
        desc = `Внести удобрения на ${f.name}. Гранулы за счёт заказчика.`;
        baseRate = 210;
      } else if (type === 'seed_fert') {
        title = `Посев + удобрение: ${cDef.icon} ${cDef.name}`;
        desc = `Засеять ${f.name} и внести удобрения. Материалы заказчика.`;
        baseRate = 430;
      } else {
        expectedLiters = Math.round(f.tiles.length * cDef.yieldPerTile * 0.80);
        title = `Уборка и вывоз: ${cDef.icon} ${cDef.name}`;
        desc = `Убрать ${f.name} и сдать зерно заказчику на «${elev.name}».`;
        baseRate = 390;
      }

      const isUrgent = Math.random() < 0.14;
      const urgentMult = isUrgent ? (2.6 + Math.random() * 0.8) : 1.0;
      if (isUrgent) title = `🔥 СРОЧНО: ${title}`;

      const reward = Math.round(f.ha * baseRate * repBonus * urgentMult);
      this.contracts.push({
        id: 'c_' + Date.now() + '_' + f.id + '_' + Math.floor(Math.random() * 999),
        fieldId: f.id, village: vName, type, cropId,
        targetElevId: elev.id, targetElevName: elev.name,
        expectedLiters, deliveredLiters: 0,
        isUrgent,
        title, desc, reward, usedLoaner: false, accepted: false
      });
    }
  },

  isContractField(fieldId) { return this.contracts.some(c => c.accepted && c.fieldId === fieldId); },
  getContractForField(fieldId) { return this.contracts.find(c => c.accepted && c.fieldId === fieldId) || null; },

  acceptContract(id, withLoaner = false) {
    const c = this.contracts.find(x => x.id === id);
    if (!c || c.accepted) return;
    const f = TF.World.fields.find(x => x.id === c.fieldId);
    if (!f) return;

    c.accepted = true;
    c.usedLoaner = !!withLoaner;
    if (!withLoaner) c.reward = Math.round(c.reward * 1.25);

    for (const t of f.tiles) {
      if (c.type === 'plow') { t.state = 'stubble'; t.crop = null; t.growth = 0; t.fertilized = false; }
      else if (c.type === 'seed' || c.type === 'seed_fert') { t.state = 'plowed'; t.crop = null; t.growth = 0; t.fertilized = false; }
      else if (c.type === 'fertilize') { t.state = 'seeded'; t.crop = c.cropId; t.growth = 0.45; t.fertilized = false; }
      else if (c.type === 'harvest') { t.state = 'ready'; t.crop = c.cropId; t.growth = 1; t.fertilized = false; }
    }

    if (withLoaner) {
      const gx = f.entrance.gx, gy = f.entrance.gy;
      const isBig = f.ha >= 35;
      const spawnLoaner = (modelId, ox, oy) => {
        const v = TF.Vehicles.spawn(modelId, gx + ox, gy + oy, 0);
        if (v) v.loanerForContractId = c.id;
        return v;
      };
      if (c.type === 'plow') {
        const tr = spawnLoaner(isBig ? 'jd6155m' : 'mtz82', 0, 0);
        const imp = spawnLoaner(isBig ? 'lemken_karat' : 'pln335', -70, 0);
        tr.attachment = imp.uid; imp.attachedTo = tr.uid;
      } else if (c.type === 'seed') {
        const isRow = c.cropId === 'corn' || c.cropId === 'sunflower';
        const tr = spawnLoaner(isBig ? 'jd6155m' : 'mtz82', 0, 0);
        const imp = spawnLoaner(isRow ? (isBig ? 'horsch_maestro' : 'supn8') : (isBig ? 'vaderstad_600' : 'sz36'), -70, 0);
        tr.attachment = imp.uid; imp.attachedTo = tr.uid;
      } else if (c.type === 'fertilize') {
        const tr = spawnLoaner('mtz82', 0, 0);
        const imp = spawnLoaner(isBig ? 'amazone_ux5201' : 'rum5', -60, 0);
        tr.attachment = imp.uid; imp.attachedTo = tr.uid;
      } else if (c.type === 'seed_fert') {
        const isRow = c.cropId === 'corn' || c.cropId === 'sunflower';
        const tr = spawnLoaner('jd6155m', 0, 0);
        const imp = spawnLoaner(isRow ? 'supn8' : 'vaderstad_600', -70, 0);
        tr.attachment = imp.uid; imp.attachedTo = tr.uid;
        spawnLoaner('amazone_zats', 0, 75);
      } else if (c.type === 'harvest') {
        const cDef = TF.DATA.CROPS[c.cropId];
        const comb = spawnLoaner(isBig ? 'don1500' : 'sk5_niva', 0, 0);
        const hdr = spawnLoaner(cDef.headerType === 'corn' ? 'header_corn_sm' : 'header_niva', 55, 0);
        comb.frontAttachment = hdr.uid; hdr.attachedTo = comb.uid;
        const tr = spawnLoaner('mtz82', -90, 65);
        const trl = spawnLoaner(isBig ? 'fliegl_271' : 'pts4', -160, 65);
        tr.attachment = trl.uid; trl.attachedTo = tr.uid;
      }
      TF.UI.toast(`📋 Контракт взят! Техника заказчика подана к въезду на ${f.name}.`);
    } else {
      TF.UI.toast(`📋 Контракт взят своей техникой (+25% к оплате)!`);
    }
    this.save();
  },

  recordContractGrainDelivery(contractId, stationId, liters) {
    const c = this.contracts.find(x => x.id === contractId && x.accepted);
    if (!c) return;
    c.deliveredLiters = (c.deliveredLiters || 0) + liters;
  },

  getContractProgress(c) {
    const f = TF.World.fields.find(x => x.id === c.fieldId);
    if (!f) return 0;
    const sum = TF.World.getFieldSummary(f);
    if (c.type === 'plow') return sum.pctPlowed;
    if (c.type === 'seed') return Math.round((f.tiles.filter(t => t.state === 'seeded' || t.state === 'ready').length / f.tiles.length) * 100);
    if (c.type === 'fertilize') return sum.pctFert;
    if (c.type === 'seed_fert') {
      const seededPct = (f.tiles.filter(t => t.state === 'seeded' || t.state === 'ready').length / f.tiles.length) * 100;
      return Math.round((seededPct + sum.pctFert) / 2);
    }
    if (c.type === 'harvest') {
      const cutPct = 100 - sum.pctReady;
      const delivPct = c.expectedLiters > 0 ? Math.min(100, (c.deliveredLiters / c.expectedLiters) * 100) : 100;
      return Math.round(cutPct * 0.5 + delivPct * 0.5);
    }
    return 0;
  },

  removeLoanerEquipment(contractId) {
    for (let i = TF.Vehicles.list.length - 1; i >= 0; i--) {
      const v = TF.Vehicles.list[i];
      if (v.loanerForContractId === contractId) {
        if (v.ai) TF.AI.stopVehicle(v, true);
        if (this.activeVehicleUid === v.uid) this.activeVehicleUid = null;
        TF.Vehicles.list.splice(i, 1);
      }
    }
    if (!this.activeVehicleUid) this.activeVehicleUid = TF.Vehicles.getDrivables()[0]?.uid || null;
  },

  claimContract(id) {
    const idx = this.contracts.findIndex(x => x.id === id);
    if (idx === -1) return;
    const c = this.contracts[idx];
    if (this.getContractProgress(c) < 85) return;
    this.addMoney(c.reward, true);
    this.stats.contractsDone++;
    this.villageRep[c.village] = (this.villageRep[c.village] || 0) + 1;
    const discPct = Math.round(this.getVillageDiscount(c.village) * 100);
    this.removeLoanerEquipment(c.id);
    TF.Audio.playCash();
    TF.UI.toast(`💰 Контракт выполнен: +$${c.reward.toLocaleString('ru-RU')}! Репутация в «${c.village}» выросла (скидка ${discPct}%).`);
    this.contracts.splice(idx, 1);
    this.generateContracts();
    this.save();
  },

  cancelContract(id) {
    const idx = this.contracts.findIndex(x => x.id === id);
    if (idx === -1) return;
    this.removeLoanerEquipment(id);
    this.contracts.splice(idx, 1);
    this.generateContracts();
    TF.UI.toast('Контракт отменён, арендная техника возвращена.');
    this.save();
  },

  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.floor(window.innerWidth * dpr);
    this.canvas.height = Math.floor(window.innerHeight * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.lightCanvas.width = window.innerWidth;
    this.lightCanvas.height = window.innerHeight;
  },

  bindInputs() {
    window.addEventListener('keydown', (e) => {
      if (TF.UI.fullMapOpen) { if (e.key === 'Escape' || e.code === 'KeyM') TF.UI.closeFullMap(); return; }
      if (TF.UI.currentModal) { if (e.key === 'Escape') TF.UI.closeModal(); return; }
      this.keys[e.code] = true;
      if (e.code === 'KeyQ') TF.Vehicles.toggleHitch(this.getActiveVehicle());
      if (e.code === 'KeyB') TF.Vehicles.toggleWork(this.getActiveVehicle());
      if (e.code === 'KeyR') TF.Vehicles.performContextAction(this.getActiveVehicle());
      if (e.code === 'KeyH') TF.UI.handleQuickAI();
      if (e.code === 'KeyC') this.cycleCrop();
      if (e.code === 'KeyM') TF.UI.openFullMap();
      if (e.code === 'Tab') { e.preventDefault(); this.switchVehicle(); }
    });
    window.addEventListener('keyup', (e) => { this.keys[e.code] = false; });

    this.canvas.addEventListener('wheel', (e) => { e.preventDefault(); this.adjustZoom(e.deltaY < 0 ? 1.12 : 0.89); }, { passive: false });

    const base = document.getElementById('joystickBase'), knob = document.getElementById('joystickKnob'), maxR = 40;
    const updateJoy = (clientX, clientY) => {
      const rect = base.getBoundingClientRect();
      let dx = clientX - (rect.left + rect.width / 2), dy = clientY - (rect.top + rect.height / 2);
      const d = Math.hypot(dx, dy);
      if (d > maxR) { dx = (dx / d) * maxR; dy = (dy / d) * maxR; }
      this.joy.dx = dx / maxR; this.joy.dy = dy / maxR;
      knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    };
    const resetJoy = () => { this.joy.active = false; this.joy.id = null; this.joy.dx = 0; this.joy.dy = 0; knob.style.transform = 'translate(-50%, -50%)'; };

    base.addEventListener('touchstart', (e) => { e.preventDefault(); const t = e.changedTouches[0]; this.joy.active = true; this.joy.id = t.identifier; updateJoy(t.clientX, t.clientY); }, { passive: false });
    window.addEventListener('touchmove', (e) => { if (!this.joy.active) return; for (const t of e.changedTouches) if (t.identifier === this.joy.id) updateJoy(t.clientX, t.clientY); }, { passive: false });
    window.addEventListener('touchend', (e) => { if (!this.joy.active) return; for (const t of e.changedTouches) if (t.identifier === this.joy.id) resetJoy(); });
    base.addEventListener('mousedown', (e) => { this.joy.active = true; updateJoy(e.clientX, e.clientY); });
    window.addEventListener('mousemove', (e) => { if (this.joy.active && this.joy.id === null) updateJoy(e.clientX, e.clientY); });
    window.addEventListener('mouseup', () => { if (this.joy.active && this.joy.id === null) resetJoy(); });
  },

  getInput() {
    if (this.joy.active) {
      const mag = Math.min(1, Math.hypot(this.joy.dx, this.joy.dy));
      if (mag > 0.08) this.cam.freeMode = false;
      return { dirMode: true, targetAngle: Math.atan2(this.joy.dy, this.joy.dx), mag, throttle: 0, steer: 0 };
    }
    let throttle = 0, steer = 0;
    if (this.keys['KeyW'] || this.keys['ArrowUp']) throttle += 1;
    if (this.keys['KeyS'] || this.keys['ArrowDown']) throttle -= 1;
    if (this.keys['KeyA'] || this.keys['ArrowLeft']) steer -= 1;
    if (this.keys['KeyD'] || this.keys['ArrowRight']) steer += 1;
    if (throttle !== 0 || steer !== 0) this.cam.freeMode = false;
    return { dirMode: false, targetAngle: 0, mag: 0, throttle, steer };
  },

  getActiveVehicle() { return TF.Vehicles.getByUid(this.activeVehicleUid) || TF.Vehicles.getDrivables()[0] || null; },
  selectVehicle(uid) { this.activeVehicleUid = uid; this.cam.freeMode = false; const v = this.getActiveVehicle(); if (v) TF.UI.toast(`Вы за рулём: ${TF.DATA.getItem(v.modelId).name}`); },
  switchVehicle() { const list = TF.Vehicles.getDrivables(); if (!list.length) return; this.selectVehicle(list[(list.findIndex(v => v.uid === this.activeVehicleUid) + 1) % list.length].uid); },
  cycleCrop() {
    const v = this.getActiveVehicle();
    if (!v) return;
    let ids = Object.keys(TF.DATA.CROPS);
    if (v.attachment) {
      const att = TF.Vehicles.getByUid(v.attachment);
      const attDef = att ? TF.DATA.getItem(att.modelId) : null;
      if (attDef && attDef.role === 'seeder') {
        const allowed = TF.DATA.getSeederAllowedCrops(attDef);
        if (allowed.length) ids = allowed;
      }
    }
    const curIdx = ids.indexOf(v.selectedCrop || ids[0]);
    v.selectedCrop = ids[(curIdx + 1) % ids.length];
    const c = TF.DATA.CROPS[v.selectedCrop];
    TF.UI.toast(`Культура: ${c.icon} ${c.name}`);
  },
  cycleTimeSpeed() { this.timeSpeedIdx = (this.timeSpeedIdx + 1) % TF.DATA.TIME_SPEEDS.length; TF.UI.toast(`Скорость: x${TF.DATA.TIME_SPEEDS[this.timeSpeedIdx]}`); },

  skipToMorning() {
    const deltaDays = ((24 - this.hour) + 8) / 24;
    this.hour = 8.0;
    this.advanceDay(deltaDays);
    TF.UI.toast(`Утро (День ${this.day}, ${TF.DATA.SEASONS[this.seasonIdx].name}). Цены и погода обновились!`);
  },

  advanceDay(growthDays = 0) {
    if (growthDays > 0) TF.World.updateGrowth(growthDays, this.seasonIdx);
    this.day++;
    this.totalDays++;
    if (this.day > TF.DATA.DAYS_PER_SEASON) {
      this.day = 1;
      this.seasonIdx = (this.seasonIdx + 1) % TF.DATA.SEASONS.length;
      TF.UI.toast(`Новый сезон: ${TF.DATA.SEASONS[this.seasonIdx].icon} ${TF.DATA.SEASONS[this.seasonIdx].name}!`);
    }
    TF.World.fluctuatePrices(this.seasonIdx);
    TF.World.rollWeather(this.seasonIdx);
    this.generateContracts();
  },

  addMoney(amount, isIncome = false) {
    this.money = Math.max(0, this.money + amount);
    if (isIncome && amount > 0) this.stats.totalEarned += amount;
  },

  findFreeParkingBay(dest) {
    const lot = TF.DATA.PARKING_LOTS[dest === 'shop' ? 'shop' : 'base'];
    const unlocked = dest === 'shop' ? this.shopParkingSlots : 4;
    for (let i = 0; i < Math.min(unlocked, lot.bays.length); i++) {
      if (!TF.Vehicles.isBayOccupied(lot.bays[i])) return { bay: lot.bays[i], idx: i + 1 };
    }
    return null;
  },

  buyShopParkingSlots() {
    const lot = TF.DATA.PARKING_LOTS.shop;
    if (this.shopParkingSlots >= lot.bays.length) { TF.UI.toast('В Тавричанке уже куплены все 8 слотов!'); return; }
    if (this.money < lot.slotPrice) { TF.UI.toast(`Не хватает денег ($${lot.slotPrice.toLocaleString('ru-RU')})!`); return; }
    this.money -= lot.slotPrice;
    this.shopParkingSlots = Math.min(lot.bays.length, this.shopParkingSlots + 2);
    TF.Audio.playCash();
    TF.UI.toast(`🅿 Куплено +2 парковочных слота в Тавричанке (теперь ${this.shopParkingSlots}/${lot.bays.length})!`);
    this.save();
  },

  buyItem(modelId, dest) {
    const def = TF.DATA.getItem(modelId); if (!def) return;
    if (this.money < def.price) { TF.UI.toast('Недостаточно денег!'); return; }
    const free = this.findFreeParkingBay(dest);
    if (!free) {
      TF.UI.toast(`🅿 На парковке (${dest === 'shop' ? 'Тавричанка' : 'Любимо-Павловка'}) нет свободных мест! Отгони технику или докупи слоты.`);
      return;
    }
    this.money -= def.price;
    const v = TF.Vehicles.spawn(modelId, free.bay.x, free.bay.y, free.bay.angle || 0);
    if (v && (v.category === 'tractor' || v.category === 'combine')) { this.activeVehicleUid = v.uid; this.cam.freeMode = false; }
    TF.Audio.playCash();
    TF.UI.toast(`Куплено: ${def.name} → Слот P${free.idx} (${dest === 'shop' ? 'Тавричанка' : 'Любимо-Павловка'})!`);
    this.save();
  },

  buyField(fieldId) {
    const f = TF.World.fields.find(x => x.id === fieldId);
    if (!f || f.owned) return;
    const finalPrice = this.getFieldBuyPrice(f);
    if (this.money < finalPrice) { TF.UI.toast('Не хватает денег!'); return; }
    this.money -= finalPrice; f.owned = true;
    TF.Audio.playCash(); TF.UI.toast(`Куплено ${f.name} (${f.ha} га)!`);
    this.save();
  },

  sellVehicle(uid) {
    const idx = TF.Vehicles.list.findIndex(v => v.uid === uid); if (idx === -1) return;
    const v = TF.Vehicles.list[idx];
    if (v.loanerForContractId) { TF.UI.toast('Арендную технику заказчика продавать нельзя!'); return; }
    if (v.loanerForContractId) { TF.UI.toast('Арендную технику заказчика продавать нельзя!'); return; }
    if (v.loanerForContractId) { TF.UI.toast('Арендную технику заказчика продавать нельзя!'); return; }
    if (v.loanerForContractId) { TF.UI.toast('Арендную технику заказчика продавать нельзя!'); return; }
    if (TF.Vehicles.getDrivables().length <= 1 && (v.category === 'tractor' || v.category === 'combine')) { TF.UI.toast('Нельзя продать последнюю технику!'); return; }
    if (v.attachment) { const a = TF.Vehicles.getByUid(v.attachment); if (a) a.attachedTo = null; }
    if (v.frontAttachment) { const h = TF.Vehicles.getByUid(v.frontAttachment); if (h) h.attachedTo = null; }
    if (v.attachedTo) { const p = TF.Vehicles.getByUid(v.attachedTo); if (p) { if (p.attachment === v.uid) p.attachment = null; if (p.frontAttachment === v.uid) p.frontAttachment = null; } }
    const def = TF.DATA.getItem(v.modelId), refund = Math.round(def.price * 0.6);
    this.addMoney(refund); TF.Audio.playCash(); TF.Vehicles.list.splice(idx, 1);
    if (this.activeVehicleUid === uid) this.activeVehicleUid = TF.Vehicles.getDrivables()[0]?.uid || null;
    TF.UI.toast(`Продано ${def.name} за +$${refund.toLocaleString('ru-RU')}`);
    this.save();
  },

  focusCameraOn(x, y) { this.cam.x = x; this.cam.y = y; this.cam.freeMode = true; },
  adjustZoom(factor) { this.cam.zoom = Math.max(0.24, Math.min(1.6, this.cam.zoom * factor)); },

  loop(now) {
    const dt = Math.min(0.05, (now - this.lastTime) / 1000);
    this.lastTime = now;

    const speedMult = TF.DATA.TIME_SPEEDS[this.timeSpeedIdx];
    const deltaHours = (dt * speedMult) / 60;
    this.hour += deltaHours;
    TF.World.updateGrowth(deltaHours / 24, this.seasonIdx);
    TF.World.updateWetness(deltaHours, this.seasonIdx);
    if (this.hour >= 24) { this.hour -= 24; this.advanceDay(0); }

    const input = this.getInput();
    TF.Vehicles.update(dt, input, this.activeVehicleUid);

    const active = this.getActiveVehicle();
    if (active && !this.cam.freeMode) {
      this.cam.x += (active.x - this.cam.x) * Math.min(1, dt * 6);
      this.cam.y += (active.y - this.cam.y) * Math.min(1, dt * 6);
    }

    TF.Audio.update(this.cam, active, TF.Vehicles.list, dt);

    const vw = window.innerWidth, vh = window.innerHeight, ctx = this.ctx;
    ctx.save();
    ctx.clearRect(0, 0, vw, vh);
    ctx.translate(vw / 2, vh / 2);
    ctx.scale(this.cam.zoom, this.cam.zoom);
    ctx.translate(-this.cam.x, -this.cam.y);
    TF.World.draw(ctx, this.cam, vw, vh, this.seasonIdx, this.hour, now / 1000);
    TF.Vehicles.draw(ctx, this.activeVehicleUid, this.hour);
    ctx.restore();

    const nightAlpha = TF.World.getNightAlpha(this.hour, this.totalDays);
    if (nightAlpha > 0.01) {
      const lctx = this.lightCtx;
      lctx.clearRect(0, 0, vw, vh);
      lctx.globalCompositeOperation = 'source-over';
      const isTwilight = (this.hour > 18.5 && this.hour < 20.5) || (this.hour > 5 && this.hour < 7);
      lctx.fillStyle = isTwilight ? `rgba(28, 18, 42, ${nightAlpha * 0.78})` : `rgba(4, 10, 24, ${nightAlpha})`;
      lctx.fillRect(0, 0, vw, vh);
      TF.Vehicles.punchNightLights(lctx, this.cam, vw, vh, this.hour);
      ctx.drawImage(this.lightCanvas, 0, 0, vw, vh);
    }

    if (TF.World.weather === 'rain') {
      ctx.save();
      ctx.fillStyle = 'rgba(20, 35, 52, 0.14)';
      ctx.fillRect(0, 0, vw, vh);
      ctx.strokeStyle = 'rgba(185, 220, 255, 0.42)';
      ctx.lineWidth = 1.4;
      const t = now * 0.85;
      ctx.beginPath();
      for (let i = 0; i < 85; i++) {
        const rx = ((i * 97 + t * 0.35) % (vw + 80)) - 40;
        const ry = ((i * 131 + t * 1.15) % (vh + 60)) - 30;
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx - 7, ry + 20);
      }
      ctx.stroke();
      ctx.restore();
    }

    this.drawMinimap();
    if (TF.UI.fullMapOpen) TF.UI.drawFullMap();
    TF.UI.updateHUD();

    this.saveTimer += dt;
    if (this.saveTimer >= 30) { this.saveTimer = 0; this.save(); }
    requestAnimationFrame((t) => this.loop(t));
  },

  drawMinimap() {
    const mc = this.miniCtx, mw = this.miniCanvas.width, mh = this.miniCanvas.height;
    const sx = mw / TF.DATA.WORLD_W, sy = mh / TF.DATA.WORLD_H;
    mc.fillStyle = '#334729'; mc.fillRect(0, 0, mw, mh);
    mc.fillStyle = '#1f6d9c'; mc.fillRect(0, TF.DATA.CANAL.y * sy - 1, mw, 3);
    mc.strokeStyle = '#6c7275'; mc.lineWidth = 1.5;
    for (const r of TF.DATA.ROADS) { mc.beginPath(); mc.moveTo(r.x1 * sx, r.y1 * sy); mc.lineTo(r.x2 * sx, r.y2 * sy); mc.stroke(); }
    for (const f of TF.World.fields) { mc.fillStyle = f.owned ? '#5ec968' : (this.isContractField(f.id) ? '#4ba3e3' : '#9c8655'); mc.fillRect(f.x * sx, f.y * sy, Math.max(3, f.w * sx), Math.max(3, f.h * sy)); }
    for (const s of TF.DATA.STATIONS) { mc.fillStyle = s.type === 'elevator' ? '#ffe07d' : s.type === 'shop' ? '#4ba3e3' : '#e07b39'; mc.fillRect(s.x * sx - 1, s.y * sy - 1, 4, 4); }
    for (const v of TF.Vehicles.list) {
      if (v.category === 'tractor' || v.category === 'combine') {
        mc.fillStyle = v.broken ? '#ff4444' : (v.uid === this.activeVehicleUid ? '#ffffff' : (v.ai ? '#7dff8b' : '#ff8c69'));
        mc.beginPath(); mc.arc(v.x * sx, v.y * sy, v.uid === this.activeVehicleUid ? 3 : 2, 0, Math.PI * 2); mc.fill();
      }
    }
  },

  buildSavePayload() {
    return {
      saveVersion: this.SAVE_VERSION,
      appVersion: window.TF_APP_VERSION || '1.6.0',
      money: this.money, day: this.day, totalDays: this.totalDays, seasonIdx: this.seasonIdx, hour: this.hour,
      activeVehicleUid: this.activeVehicleUid, prices: TF.World.prices, weather: TF.World.weather, soilWetness: TF.World.soilWetness,
      strawSegments: TF.World.strawSegments.map(s => [Math.round(s.x), Math.round(s.y), +s.angle.toFixed(2), s.type === 'swath' ? 1 : 0]),
      stats: this.stats, contracts: this.contracts, villageRep: this.villageRep, shopParkingSlots: this.shopParkingSlots, hiredWorkerIds: TF.AI.hiredWorkerIds,
      fields: TF.World.fields.map(f => ({
        id: f.id, owned: f.owned,
        tiles: f.tiles.map(t => [t.state === 'stubble' ? 0 : t.state === 'plowed' ? 1 : t.state === 'seeded' ? 2 : 3, t.crop ? t.crop.slice(0, 2) : '', Math.round(t.growth * 100), t.fertilized ? 1 : 0])
      })),
      vehicles: TF.Vehicles.list.map(v => ({ ...v, ai: null }))
    };
  },

  save() {
    try { localStorage.setItem(this.SAVE_KEY, JSON.stringify(this.buildSavePayload())); } catch (e) {}
  },

  exportSaveFile() {
    const blob = new Blob([JSON.stringify(this.buildSavePayload())], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `tavria-farmer-save-d${this.totalDays}.json`;
    a.click();
    TF.UI.toast('Файл сохранения скачан!');
  },

  migrateSave(data, rawStr) {
    if (!data || typeof data !== 'object') return null;
    const fromVer = Number(data.saveVersion) || 1;
    // Если сейв от старой версии — сначала делаем резервную копию
    if (fromVer < this.SAVE_VERSION && rawStr) {
      try { localStorage.setItem(this.BACKUP_KEY, rawStr); } catch (e) {}
    }

    // Гарантируем безопасные значения по умолчанию для всех полей (совместимость со всеми старыми и будущими версиями)
    const defaultStats = { harvestedLiters: 0, totalEarned: 0, contractsDone: 0 };
    data.stats = { ...defaultStats, ...(data.stats || {}) };
    data.money = typeof data.money === 'number' && isFinite(data.money) ? data.money : 48000;
    data.day = Number(data.day) || 1;
    data.totalDays = Number(data.totalDays) || 1;
    data.seasonIdx = Math.max(0, Math.min(3, Number(data.seasonIdx) || 0));
    data.hour = typeof data.hour === 'number' && isFinite(data.hour) ? data.hour : 8;
    data.weather = data.weather === 'rain' ? 'rain' : 'clear';
    data.soilWetness = typeof data.soilWetness === 'number' && isFinite(data.soilWetness) ? Math.max(0, Math.min(1, data.soilWetness)) : 0;
    data.shopParkingSlots = typeof data.shopParkingSlots === 'number' ? Math.max(0, data.shopParkingSlots) : 0;
    data.hiredWorkerIds = Array.isArray(data.hiredWorkerIds) ? data.hiredWorkerIds : [];
    data.strawSegments = Array.isArray(data.strawSegments) ? data.strawSegments : [];

    // Гарантируем актуальную репутацию по всем сёлам
    const defaultRep = { 'Любимо-Павловка': 0, 'Дудчино': 0, 'Тавричанка': 0, 'Любимо-Марьевка': 0, 'Марьяновка': 0, 'Заозёрное': 0 };
    data.villageRep = { ...defaultRep, ...(data.villageRep || {}) };

    // Миграция контрактов
    data.contracts = Array.isArray(data.contracts) ? data.contracts.map(c => ({
      expectedLiters: 0, deliveredLiters: 0, isUrgent: false, usedLoaner: false, accepted: false,
      ...c
    })) : [];

    // Миграция техники: проверяем, что модель есть в каталоге, и дописываем недостающие поля
    if (Array.isArray(data.vehicles)) {
      data.vehicles = data.vehicles
        .filter(v => v && v.modelId && TF.DATA.getItem(v.modelId))
        .map(v => {
          const def = TF.DATA.getItem(v.modelId);
          return {
            uid: v.uid,
            modelId: v.modelId,
            category: def.category,
            role: def.role || def.category,
            x: Number(v.x) || 1660,
            y: Number(v.y) || 5840,
            angle: Number(v.angle) || 0,
            speed: 0,
            steerAngle: 0,
            fuel: typeof v.fuel === 'number' ? v.fuel : (def.fuelCap || 100),
            wear: typeof v.wear === 'number' ? v.wear : 0,
            broken: !!v.broken,
            working: false,
            cargo: Number(v.cargo) || 0,
            cargoCrop: v.cargoCrop || null,
            cargoContractId: v.cargoContractId || null,
            selectedCrop: v.selectedCrop || 'wheat',
            attachment: v.attachment || null,
            frontAttachment: v.frontAttachment || null,
            attachedTo: v.attachedTo || null,
            loanerForContractId: v.loanerForContractId || null,
            ai: null
          };
        });
    } else {
      data.vehicles = [];
    }

    data.saveVersion = this.SAVE_VERSION;
    return data;
  },

  load() {
    try {
      const raw = localStorage.getItem(this.SAVE_KEY); if (!raw) return false;
      const parsed = JSON.parse(raw);
      const data = this.migrateSave(parsed, raw);
      if (!data) return false;

      this.money = data.money; this.day = data.day; this.totalDays = data.totalDays;
      this.seasonIdx = data.seasonIdx; this.hour = data.hour;
      if (data.prices) TF.World.prices = { ...TF.World.prices, ...data.prices };
      TF.World.weather = data.weather;
      TF.World.soilWetness = data.soilWetness;
      TF.World.strawSegments = data.strawSegments.map(s => ({ x: s[0], y: s[1], angle: s[2], len: 20, type: s[3] ? 'swath' : 'chopped' }));
      this.stats = data.stats;
      this.contracts = data.contracts;
      this.villageRep = data.villageRep;
      this.shopParkingSlots = data.shopParkingSlots;
      TF.AI.hiredWorkerIds = data.hiredWorkerIds;

      const cropKeys = Object.keys(TF.DATA.CROPS);
      if (Array.isArray(data.fields)) {
        for (const sf of data.fields) {
          const f = TF.World.fields.find(x => x.id === sf.id);
          if (!f || !Array.isArray(sf.tiles) || sf.tiles.length !== f.tiles.length) continue;
          f.owned = !!sf.owned;
          for (let i = 0; i < f.tiles.length; i++) {
            const row = sf.tiles[i];
            if (!Array.isArray(row)) continue;
            f.tiles[i] = {
              state: row[0] === 0 ? 'stubble' : row[0] === 1 ? 'plowed' : row[0] === 2 ? 'seeded' : 'ready',
              crop: row[1] ? (cropKeys.find(k => k.startsWith(row[1])) || null) : null,
              growth: (row[2] || 0) / 100,
              fertilized: !!row[3]
            };
          }
        }
      }
      if (data.vehicles.length) {
        TF.Vehicles.list = data.vehicles;
        TF.Vehicles.nextUid = Math.max(...data.vehicles.map(v => v.uid)) + 1;
        const drivables = TF.Vehicles.getDrivables();
        const savedActive = drivables.find(v => v.uid === data.activeVehicleUid);
        this.activeVehicleUid = savedActive ? savedActive.uid : (drivables[0]?.uid || null);
        const active = this.getActiveVehicle();
        if (active) { this.cam.x = active.x; this.cam.y = active.y; }
        return true;
      }
      return false;
    } catch (e) { return false; }
  }
};

window.addEventListener('DOMContentLoaded', () => TF.Game.init());
