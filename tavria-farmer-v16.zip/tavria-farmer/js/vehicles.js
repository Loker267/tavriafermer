window.TF = window.TF || {};

TF.Vehicles = {
  list: [],
  particles: [],
  activeGrainStreams: [],
  nextUid: 1,
  bumpCooldown: 0,
  wrongHeaderToastCooldown: 0,
  rainToastCooldown: 0,
  trackTimer: 0,

  reset() {
    this.list = [];
    this.particles = [];
    this.nextUid = 1;
  },

  spawn(modelId, x, y, angle = 0) {
    const def = TF.DATA.getItem(modelId);
    if (!def) return null;
    const obj = {
      uid: this.nextUid++,
      modelId: def.id,
      category: def.category,
      role: def.role || def.category,
      x, y, angle,
      speed: 0,
      steerAngle: 0,
      braking: false,
      reversing: false,
      fuel: def.role === 'fuel_trailer' ? def.capacity : (def.fuelCap || 0),
      wear: 0,
      broken: false,
      cargo: 0,
      cargoCrop: null,
      cargoContractId: null,
      loanerForContractId: null,
      working: false,
      attachedTo: null,
      attachment: null,
      frontAttachment: null,
      selectedCrop: 'wheat',
      ai: null
    };
    this.list.push(obj);
    return obj;
  },

  getByUid(uid) { return this.list.find(v => v.uid === uid) || null; },
  getDrivables() { return this.list.filter(v => v.category === 'tractor' || v.category === 'combine'); },

  spawnParticle(x, y, vx, vy, color, size, life) {
    if (this.particles.length > 300) this.particles.shift();
    this.particles.push({ x, y, vx, vy, color, size, life, maxLife: life });
  },

  triggerBreakdown(v) {
    if (v.broken) return;
    v.broken = true;
    v.working = false;
    if (v.ai) TF.AI.stopVehicle(v, true);
    const def = TF.DATA.getItem(v.modelId);
    TF.Audio.playBreakdown();
    for (let i = 0; i < 24; i++) {
      const a = Math.random() * Math.PI * 2, sp = 35 + Math.random() * 90;
      this.spawnParticle(v.x, v.y, Math.cos(a) * sp, Math.sin(a) * sp, i % 2 === 0 ? '#ff9f1c' : '#ff4d2e', 4 + Math.random() * 4, 0.7 + Math.random() * 0.5);
    }
    for (let i = 0; i < 14; i++) {
      this.spawnParticle(v.x + (Math.random() - 0.5) * 18, v.y + (Math.random() - 0.5) * 18, (Math.random() - 0.5) * 20, -25 - Math.random() * 35, 'rgba(35,35,35,0.82)', 10 + Math.random() * 10, 1.5);
    }
    TF.UI.toast(`💥 ПОЛОМКА! ${def.name} заглох намертво! Вызови техпомощь (🛠)!`);
  },

  isBayOccupied(bay) {
    for (const v of this.list) {
      if (Math.hypot(v.x - bay.x, v.y - bay.y) < 50) return true;
    }
    return false;
  },

  // Точные координаты фаркопа трактора (сзади), наклонной камеры комбайна (спереди), дышла прицепа/орудия (спереди) и крепления жатки (сзади)
  getHitchPoint(v) {
    const def = TF.DATA.getItem(v.modelId);
    if (v.category === 'tractor') {
      return { x: v.x - Math.cos(v.angle) * (def.length * 0.52), y: v.y - Math.sin(v.angle) * (def.length * 0.52) };
    }
    if (v.category === 'combine') {
      return { x: v.x + Math.cos(v.angle) * (def.length * 0.52), y: v.y + Math.sin(v.angle) * (def.length * 0.52) };
    }
    if (v.category === 'header') {
      // Крепление жатки к наклонной камере — сзади по центру её корпуса!
      return { x: v.x - Math.cos(v.angle) * (def.length * 0.45), y: v.y - Math.sin(v.angle) * (def.length * 0.45) };
    }
    if (v.category === 'implement') {
      return { x: v.x + Math.cos(v.angle) * (def.length * 0.52), y: v.y + Math.sin(v.angle) * (def.length * 0.52) };
    }
    // trailer: переднее дышло
    return { x: v.x + Math.cos(v.angle) * (def.length * 0.58), y: v.y + Math.sin(v.angle) * (def.length * 0.58) };
  },

  findExactHitchTarget(v) {
    if (!v) return null;
    const myPt = this.getHitchPoint(v);
    let best = null;
    const maxDist = v.category === 'combine' ? 62 : 52;
    for (const item of this.list) {
      if (item.attachedTo) continue;
      const compat = (v.category === 'combine' && item.category === 'header') ||
                     (v.category === 'tractor' && (item.category === 'implement' || item.category === 'trailer'));
      if (!compat) continue;
      const tPt = this.getHitchPoint(item);
      const d = Math.hypot(myPt.x - tPt.x, myPt.y - tPt.y);
      if (d <= maxDist) { best = item; break; }
    }
    return best;
  },

  toggleHitch(v) {
    if (!v) return false;
    if (v.category === 'combine') {
      if (v.frontAttachment) {
        const hdr = this.getByUid(v.frontAttachment);
        if (hdr) { hdr.attachedTo = null; hdr.working = false; }
        v.frontAttachment = null; v.working = false;
        TF.Audio.playHitch(); TF.UI.toast('Жатка отцеплена.');
        return true;
      }
      const best = this.findExactHitchTarget(v);
      if (!best) { TF.UI.toast('Подъедь передом комбайна вплотную к жатке (до зелёного кружка)!'); return false; }
      const cDef = TF.DATA.getItem(v.modelId), hDef = TF.DATA.getItem(best.modelId);
      if (hDef.reqHp && cDef.hp < hDef.reqHp) { TF.UI.toast(`Нужно ${hDef.reqHp} л.с., у комбайна ${cDef.hp} л.с.`); return false; }
      v.frontAttachment = best.uid; best.attachedTo = v.uid;
      TF.Audio.playHitch(); TF.UI.toast(`Прицеплена жатка: ${hDef.name}`);
      return true;
    }
    if (v.category === 'tractor') {
      if (v.attachment) {
        const imp = this.getByUid(v.attachment);
        if (imp) { imp.attachedTo = null; imp.working = false; }
        v.attachment = null; v.working = false;
        TF.Audio.playHitch(); TF.UI.toast('Прицепное отцеплено.');
        return true;
      }
      const best = this.findExactHitchTarget(v);
      if (!best) { TF.UI.toast('Подъедь задом трактора (фаркопом) точно к дышлу (до зелёного кружка)!'); return false; }
      const tDef = TF.DATA.getItem(v.modelId), iDef = TF.DATA.getItem(best.modelId);
      if (iDef.reqHp && tDef.hp < iDef.reqHp) { TF.UI.toast(`Нужно ${iDef.reqHp} л.с., у трактора ${tDef.hp} л.с.`); return false; }
      v.attachment = best.uid; best.attachedTo = v.uid;
      if (iDef && iDef.role === 'seeder' && !TF.DATA.canSeederSow(iDef, v.selectedCrop || 'wheat')) {
        const allowed = TF.DATA.getSeederAllowedCrops(iDef);
        if (allowed.length) v.selectedCrop = allowed[0];
      }
      TF.Audio.playHitch(); TF.UI.toast(`Сцеплено: ${iDef.name}`);
      return true;
    }
    return false;
  },

  toggleWork(v) {
    if (!v) return;
    if (v.broken) { TF.UI.toast('Техника сломана! Вызови техпомощь (🛠).'); return; }
    if (v.category === 'combine') {
      if (!v.frontAttachment) { TF.UI.toast('Сначала прицепи жатку спереди (🔗 Сцепка / Q)!'); return; }
      v.working = !v.working;
      const hdr = this.getByUid(v.frontAttachment);
      if (hdr) hdr.working = v.working;
      TF.UI.toast(v.working ? 'Жатка комбайна включена' : 'Жатка выключена');
      return;
    }
    if (v.category === 'tractor') {
      if (!v.attachment) { TF.UI.toast('Сначала прицепи плуг, сеялку или разбрасыватель (🔗).'); return; }
      const imp = this.getByUid(v.attachment);
      if (imp.category === 'trailer') { TF.UI.toast('Прицеп не нужно включать.'); return; }
      imp.working = !imp.working; v.working = imp.working;
      TF.UI.toast(imp.working ? `${TF.DATA.getItem(imp.modelId).name}: работа ВКЛ` : 'Работа ВЫКЛ');
    }
  },

  performContextAction(v) {
    if (!v) return;
    const def = TF.DATA.getItem(v.modelId);
    const att = v.attachment ? this.getByUid(v.attachment) : null;

    if (att && att.role === 'fuel_trailer' && att.fuel > 10) {
      for (const other of this.list) {
        if (other !== v && (other.category === 'tractor' || other.category === 'combine')) {
          const oDef = TF.DATA.getItem(other.modelId);
          if (other.fuel < oDef.fuelCap * 0.98 && Math.hypot(other.x - att.x, other.y - att.y) < 165) {
            const transfer = Math.min(att.fuel, oDef.fuelCap - other.fuel);
            other.fuel += transfer; att.fuel -= transfer;
            TF.Audio.playHitch();
            TF.UI.toast(`⛽ Заправлено ${Math.round(transfer)} л ДТ в ${oDef.name} прямо в поле!`);
            return;
          }
        }
      }
    }

    const station = TF.World.getStationAt(v.x, v.y, 110);
    if (station) {
      if (station.type === 'elevator') {
        const carrier = (v.category === 'combine' && v.cargo > 0) ? v : (att && att.role === 'trailer' && att.cargo > 0 ? att : null);
        if (carrier && carrier.cargo > 0) {
          const dPit = Math.hypot(carrier.x - station.pitX, carrier.y - station.pitY);
          if (dPit <= 82) TF.UI.toast('Идёт плавная выгрузка зерна в приёмную решётку!');
          else TF.UI.toast('Заедь прицепом точно на решётку «▼ ВЫГРУЗКА» у элеватора!');
          return;
        }
      }
      if (station.type === 'repair' || station.type === 'supply') {
        let did = false;
        if (att && att.role === 'fuel_trailer') {
          const fCap = TF.DATA.getItem(att.modelId).capacity;
          if (att.fuel < fCap * 0.99) {
            const need = fCap - att.fuel, cost = Math.max(20, Math.round(need * 0.95));
            if (TF.Game.money >= cost) { TF.Game.addMoney(-cost); att.fuel = fCap; TF.UI.toast(`⛽ Бочка пополнена (-$${cost})`); did = true; }
          }
        }
        if (def.fuelCap && v.fuel < def.fuelCap * 0.99) {
          const need = def.fuelCap - v.fuel, cost = Math.max(10, Math.round(need * 1.1));
          if (TF.Game.money >= cost) { TF.Game.addMoney(-cost); v.fuel = def.fuelCap; TF.UI.toast(`⛽ Бак заправлен (-$${cost})`); did = true; }
          else TF.UI.toast(`Не хватает денег на заправку ($${cost})`);
        }
        if (station.type === 'repair' && (v.wear > 5 || v.broken)) {
          const repMult = 1 - TF.Game.getVillageDiscount(station.village);
          const cost = Math.max(30, Math.round(v.wear * (def.price * 0.00045 + 6) * repMult));
          if (TF.Game.money >= cost) {
            TF.Game.addMoney(-cost); v.wear = 0; v.broken = false;
            TF.Audio.playHitch();
            TF.UI.toast(`🔧 Проведено полное ТО и ремонт (-$${cost})`);
            did = true;
          } else TF.UI.toast(`Не хватает денег на ТО ($${cost})`);
        }
        if (did) return;
      }
      if (station.type === 'shop') { TF.UI.openModal('shop'); return; }
    }

    if (v.category === 'combine' && v.cargo > 0) {
      const tr = this.findNearbyTrailer(v, 165);
      if (tr) { TF.UI.toast('Шнек уже выгружает зерно в прицеп — подожди пару секунд!'); return; }
    }
    if (v.category === 'tractor' && att && att.role === 'trailer') {
      const comb = this.findNearbyCombineWithGrain(att, 175);
      if (comb) { TF.UI.toast('Идёт выгрузка зерна из комбайна — стой рядом!'); return; }
    }
    TF.UI.toast('Подъедь к элеватору (продажа), СТО/АЗС (ТО и заправка) или комбайну (выгрузка).');
  },

  findNearbyTrailer(combine, radius) {
    for (const v of this.list) {
      if (v.role === 'trailer') {
        const def = TF.DATA.getItem(v.modelId);
        if (v.cargo < def.capacity && (!v.cargoCrop || v.cargoCrop === combine.cargoCrop)) {
          if (Math.hypot(v.x - combine.x, v.y - combine.y) <= radius) return v;
        }
      }
    }
    return null;
  },

  findNearbyCombineWithGrain(trailer, radius) {
    for (const v of this.list) {
      if (v.category === 'combine' && v.cargo > 10 && (!trailer.cargoCrop || trailer.cargoCrop === v.cargoCrop)) {
        if (Math.hypot(v.x - trailer.x, v.y - trailer.y) <= radius) return v;
      }
    }
    return null;
  },

  transferGrain(combine, trailer, maxAmount) {
    const tDef = TF.DATA.getItem(trailer.modelId);
    const amt = Math.min(combine.cargo, tDef.capacity - trailer.cargo, maxAmount);
    if (amt <= 0) return 0;
    trailer.cargo += amt; trailer.cargoCrop = combine.cargoCrop;
    if (combine.cargoContractId) trailer.cargoContractId = combine.cargoContractId;
    combine.cargo -= amt;
    if (combine.cargo <= 1) { combine.cargo = 0; combine.cargoCrop = null; combine.cargoContractId = null; }
    if (maxAmount > 500) TF.UI.toast(`Выгружено ${Math.round(amt)} л в ${tDef.name}`);
    return amt;
  },

  update(dt, input, activeUid) {
    this.bumpCooldown = Math.max(0, this.bumpCooldown - dt);
    this.wrongHeaderToastCooldown = Math.max(0, this.wrongHeaderToastCooldown - dt);
    this.rainToastCooldown = Math.max(0, this.rainToastCooldown - dt);
    this.trackTimer += dt;
    this.activeGrainStreams = [];

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }

    const wetness = TF.World.soilWetness || 0;

    for (const v of this.list) {
      if (v.category === 'tractor' || v.category === 'combine') {
        const def = TF.DATA.getItem(v.modelId);
        const att = v.attachment ? this.getByUid(v.attachment) : null;
        const hdr = v.frontAttachment ? this.getByUid(v.frontAttachment) : null;

        // Живые признаки скрытого износа: дымок при >68%, гуще при >84%, чёрный дым при поломке!
        if (v.broken && Math.random() < dt * 8) {
          this.spawnParticle(v.x + Math.cos(v.angle) * (def.length * 0.25), v.y + Math.sin(v.angle) * (def.length * 0.25), (Math.random() - 0.5) * 14, -24 - Math.random() * 18, 'rgba(38,38,38,0.72)', 7 + Math.random() * 8, 1.3);
        } else if (!v.broken && v.wear >= 68 && Math.abs(v.speed) > 10 && Math.random() < dt * (v.wear >= 84 ? 6.5 : 3.2)) {
          const dark = v.wear >= 84 ? 'rgba(65,65,65,0.62)' : 'rgba(130,130,130,0.45)';
          this.spawnParticle(v.x + Math.cos(v.angle) * (def.length * 0.22), v.y + Math.sin(v.angle) * (def.length * 0.22), (Math.random() - 0.5) * 12, -18 - Math.random() * 14, dark, 5 + Math.random() * 5, 0.9);
        }

        let throttle = 0, steerInput = 0, aiSpeedMult = 1.0;
        v.braking = false;
        v.reversing = false;

        if (v.broken || v.fuel <= 0) {
          throttle = 0; steerInput = 0;
        } else if (v.ai) {
          const ctrl = TF.AI.updateVehicle(v, dt);
          throttle = ctrl.throttle; steerInput = ctrl.steer; aiSpeedMult = ctrl.speedMult || 1.0;
        } else if (v.uid === activeUid) {
          if (input.dirMode && input.mag > 0.1) {
            let diff = input.targetAngle - v.angle;
            while (diff > Math.PI) diff -= Math.PI * 2;
            while (diff < -Math.PI) diff += Math.PI * 2;

            // ЗАДНИЙ ХОД НА ДЖОЙСТИКЕ: если резко увёл прямо назад (>142° и сильный наклон), сдаём назад!
            if (Math.abs(diff) > 2.48 && input.mag > 0.45 && v.speed <= 26) {
              throttle = -input.mag * 0.65;
              const backDiff = diff > 0 ? (Math.PI - diff) : (-Math.PI - diff);
              steerInput = Math.max(-0.8, Math.min(0.8, -backDiff * 1.4));
            } else {
              steerInput = Math.max(-1, Math.min(1, diff * 1.95));
              throttle = input.mag * Math.max(0.38, Math.cos(diff * 0.45));
            }
          } else {
            throttle = input.throttle;
            steerInput = input.steer;
          }
        }

        const surf = TF.World.getSurfaceAt(v.x, v.y);
        const isTracked = !!def.tracks;
        const isHeavy4WD = (def.hp || 0) >= 240;
        let surfSpeedMult = 1.0;
        let surfTracMult = 1.0;
        if (surf === 'dirt') {
          surfSpeedMult = 0.89 - wetness * (isTracked ? 0.04 : 0.16);
          surfTracMult = 0.90 - wetness * (isTracked ? 0.05 : 0.22);
        } else if (surf === 'stubble' || surf === 'grass') {
          surfSpeedMult = (isTracked ? 0.92 : 0.80) - wetness * (isTracked ? 0.05 : 0.18);
          surfTracMult = (isTracked ? 0.94 : 0.82) - wetness * (isTracked ? 0.06 : 0.24);
        } else if (surf === 'plowed') {
          const baseDry = isTracked ? 0.90 : (isHeavy4WD ? 0.74 : 0.67);
          const wetPen = isTracked ? 0.06 : (isHeavy4WD ? 0.15 : 0.23);
          surfSpeedMult = baseDry - wetness * wetPen;
          surfTracMult = (isTracked ? 0.90 : 0.68) - wetness * (isTracked ? 0.08 : 0.26);
        }
        v.currentSurface = surf;

        const cargoMass = ((v.cargo || 0) + (att ? att.cargo || 0 : 0)) / 18000;
        const totalMass = (def.mass || 1.5) + (att ? 0.5 : 0) + cargoMass;
        const accelRate = (115 / Math.pow(totalMass, 0.55)) * surfTracMult;
        const brakeRate = (215 / Math.pow(totalMass, 0.45)) * Math.max(0.6, surfTracMult);
        const dragRate = 75 + (surf === 'plowed' ? 18 : 0);

        let wearPower = 1.0;
        if (v.wear > 65) wearPower = Math.max(0.52, 1.0 - ((v.wear - 65) / 35) * 0.48);
        const isWorking = v.working || (att && att.working);
        const topSpeed = (isWorking ? def.workSpeed : def.maxSpeed) * wearPower * aiSpeedMult * surfSpeedMult;
        const targetSpeed = throttle * topSpeed;

        if (Math.abs(throttle) < 0.04) {
          if (Math.abs(v.speed) <= dragRate * dt) v.speed = 0;
          else v.speed -= Math.sign(v.speed) * dragRate * dt;
        } else if (Math.sign(targetSpeed) !== Math.sign(v.speed) && Math.abs(v.speed) > 10) {
          v.braking = true;
          v.speed += Math.sign(targetSpeed) * brakeRate * dt;
        } else {
          if (v.speed < targetSpeed) v.speed = Math.min(targetSpeed, v.speed + accelRate * dt);
          else if (v.speed > targetSpeed) v.speed = Math.max(targetSpeed, v.speed - accelRate * dt);
        }
        v.reversing = v.speed < -4;

        v.steerAngle += (steerInput - v.steerAngle) * Math.min(1, 5.5 * dt);
        if (Math.abs(v.speed) > 2.5) {
          const turnDir = v.speed >= 0 ? 1 : -1;
          const baseTurn = v.category === 'combine' ? 1.45 : (def.tracks ? 1.85 : 2.1);
          const speedFactor = Math.min(1, Math.abs(v.speed) / 36);
          const highSpeedDamp = 1 - Math.min(0.32, (Math.abs(v.speed) / 220) * 0.32);
          v.angle += v.steerAngle * baseTurn * speedFactor * highSpeedDamp * turnDir * dt;
        }

        const speedRatio = Math.abs(v.speed) / Math.max(1, def.maxSpeed);
        if (!v.broken && v.fuel > 0 && speedRatio > 0.04) {
          v.fuel = Math.max(0, v.fuel - def.fuelBurn * (isWorking ? 1.35 : 0.6) * speedRatio * dt * 0.15);
          v.wear = Math.min(100, v.wear + (isWorking ? 0.105 : 0.03) * speedRatio * dt);
          if (v.wear >= 100) this.triggerBreakdown(v);
          else if (v.fuel <= 0 && v.uid === activeUid) TF.UI.toast(`⛽ В ${def.name} кончилось топливо! Вызови техпомощь (🛠) или подвези бочку ДТ.`);
        }

        const prevX = v.x, prevY = v.y;
        const nextX = v.x + Math.cos(v.angle) * v.speed * dt;
        const nextY = v.y + Math.sin(v.angle) * v.speed * dt;
        const colR = Math.max(def.width, def.length) * 0.36;
        const res = TF.World.resolveCollision(nextX, nextY, colR, prevX, prevY);
        v.x = res.x; v.y = res.y;
        if (res.hit) {
          if (v.uid === activeUid && Math.abs(v.speed) > 45 && this.bumpCooldown <= 0) {
            TF.Audio.playBump(); this.bumpCooldown = 0.45;
          }
          v.speed *= 0.45;
        }

        // Коллизии техники друг с другом (ТОЛЬКО для ручного управления — у ботов ИИ отключены!)
        if (!v.ai) {
          for (const other of this.list) {
            if (other === v || other.ai) continue;
            if (other.uid === v.attachment || other.uid === v.frontAttachment || other.attachedTo === v.uid) continue;
            const oDef = TF.DATA.getItem(other.modelId);
            // Для широких жаток и навесного считаем компактный хитбокс по глубине корпуса (а не по 15-метровой ширине!),
            // чтобы можно было спокойно подъехать вплотную для сцепки!
            const isAttachable = (other.category === 'header' || other.category === 'implement');
            const oRad = isAttachable ? Math.max(12, oDef.length * 0.45) : (Math.min(oDef.width, oDef.length) * 0.48);
            const myBodyRad = Math.min(def.width, def.length) * 0.48;

            // Для жатки проверяем 2-3 точки вдоль её реальной балки (реалистичный прямоугольный хитбокс!)
            let hitPtX = other.x, hitPtY = other.y;
            if (other.category === 'header' && !other.attachedTo) {
              // Проецируем технику на линию балки жатки, но оставляем центр свободным для сцепки комбайна!
              const px = -Math.sin(other.angle), py = Math.cos(other.angle);
              const halfSpan = Math.max(10, (oDef.workWidth * 0.42) - 18);
              const proj = Math.max(-halfSpan, Math.min(halfSpan, (v.x - other.x) * px + (v.y - other.y) * py));
              hitPtX = other.x + px * proj;
              hitPtY = other.y + py * proj;
            }

            const dx = v.x - hitPtX, dy = v.y - hitPtY;
            const dist = Math.hypot(dx, dy);
            const canHitchThis = !other.attachedTo && (
              (v.category === 'combine' && !v.frontAttachment && other.category === 'header') ||
              (v.category === 'tractor' && !v.attachment && (other.category === 'implement' || other.category === 'trailer'))
            );
            const minD = canHitchThis ? Math.max(18, (myBodyRad + oRad) * 0.55) : (myBodyRad + oRad);

            if (dist < minD && dist > 0.001) {
              const push = minD - dist;
              v.x += (dx / dist) * push;
              v.y += (dy / dist) * push;
              if (!canHitchThis && v.uid === activeUid && Math.abs(v.speed) > 35 && this.bumpCooldown <= 0) {
                TF.Audio.playBump(); this.bumpCooldown = 0.45;
              }
              v.speed *= canHitchThis ? 0.65 : 0.35;
            }
          }
        }

        // Плавная анимированная выгрузка в приёмную решётку элеватора (для игрока И для ботов-возчиков!)
        const pitCarrier = (att && att.role === 'trailer' && att.cargo > 0) ? att : ((v.category === 'combine' && v.cargo > 0) ? v : null);
        if (pitCarrier && pitCarrier.cargo > 0 && pitCarrier.cargoCrop && Math.abs(v.speed) < 28) {
          for (const st of TF.DATA.STATIONS) {
            if (st.type === 'elevator' && st.pitX && Math.hypot(pitCarrier.x - st.pitX, pitCarrier.y - st.pitY) <= 82) {
              const dumpRate = 750; // л/сек (~6-10 сек на прицеп!)
              const amt = Math.min(pitCarrier.cargo, dumpRate * dt);
              if (pitCarrier.cargoContractId) {
                TF.Game.recordContractGrainDelivery(pitCarrier.cargoContractId, st.id, amt);
              } else {
                const earned = (amt / 1000) * TF.World.getSellPrice(pitCarrier.cargoCrop, st);
                TF.Game.addMoney(earned, true);
              }
              pitCarrier.cargo -= amt;
              // Анимация ссыпающегося зерна в решётку + звук!
              this.activeGrainStreams.push({ x1: pitCarrier.x, y1: pitCarrier.y, x2: st.pitX, y2: st.pitY, crop: pitCarrier.cargoCrop });
              if (Math.random() < dt * 16) {
                const col = TF.DATA.CROPS[pitCarrier.cargoCrop]?.colorRipe || '#f0c419';
                this.spawnParticle(st.pitX + (Math.random() - 0.5) * 26, st.pitY + (Math.random() - 0.5) * 16, (Math.random() - 0.5) * 18, (Math.random() - 0.5) * 18, col, 3.5, 0.45);
              }
              if (pitCarrier.cargo <= 1) {
                const wasC = pitCarrier.cargoContractId;
                pitCarrier.cargo = 0; pitCarrier.cargoCrop = null; pitCarrier.cargoContractId = null;
                TF.Audio.playCash();
                TF.UI.toast(wasC ? `📋 Зерно сдано заказчику на «${st.name}»!` : `💰 Разгрузка на «${st.name}» завершена!`);
              }
              break;
            }
          }
        }

        if (this.trackTimer > 0.14 && Math.abs(v.speed) > 15 && TF.World.getFieldAt(v.x, v.y)) {
          TF.World.addTrack(v.x, v.y, v.angle, def.width);
        }
        v.onRoad = TF.World.isOnRoad(v.x, v.y);

        // Пыль из-под задних колёс (на асфальте нет пыли, в грязь летят тёмные брызги)
        if (Math.abs(v.speed) > 18 && surf !== 'asphalt' && Math.random() < dt * (wetness > 0.3 ? 14 : 11)) {
          const isRain = TF.World.weather === 'rain';
          const isMud = wetness > 0.3;
          const perpX = -Math.sin(v.angle), perpY = Math.cos(v.angle);
          const backX = v.x - Math.cos(v.angle) * (def.length * 0.42);
          const backY = v.y - Math.sin(v.angle) * (def.length * 0.42);
          const col = isMud ? 'rgba(62, 44, 28, 0.62)' : (isRain ? 'rgba(170, 210, 240, 0.42)' : 'rgba(155, 130, 92, 0.36)');
          for (const side of [-1, 1]) {
            this.spawnParticle(backX + perpX * (def.width * 0.44 * side), backY + perpY * (def.width * 0.44 * side), (Math.random() - 0.5) * (isMud ? 26 : 16), (Math.random() - 0.5) * (isMud ? 26 : 16), col, isMud ? (3 + Math.random() * 3.5) : (5 + Math.random() * 4), isMud ? 0.38 : 0.55);
          }
        }

        // Солома из комбайна / пыль из-под плуга и сеялки
        if (isWorking && Math.abs(v.speed) > 10 && Math.random() < dt * 10) {
          const dustCol = v.category === 'combine' ? 'rgba(224, 194, 108, 0.52)' : 'rgba(135, 108, 76, 0.42)';
          this.spawnParticle(v.x - Math.cos(v.angle) * (def.length * 0.52), v.y - Math.sin(v.angle) * (def.length * 0.52), (Math.random() - 0.5) * 24, (Math.random() - 0.5) * 24, dustCol, 7 + Math.random() * 6, 0.85);
        }

        if (v.category === 'combine' && v.cargo > 0) {
          const tr = this.findNearbyTrailer(v, 148);
          if (tr) {
            const unloadRate = def.tier === 1 ? 460 : (def.tier === 2 ? 720 : (def.tier === 3 ? 1100 : 1450));
            const moved = this.transferGrain(v, tr, unloadRate * dt);
            if (moved > 0) {
              const pipeX = v.x + Math.sin(v.angle) * (def.width * 0.55);
              const pipeY = v.y - Math.cos(v.angle) * (def.width * 0.55);
              this.activeGrainStreams.push({ x1: pipeX, y1: pipeY, x2: tr.x, y2: tr.y, crop: tr.cargoCrop || 'wheat' });
            }
          }
        }

        if (hdr) {
          const hDef = TF.DATA.getItem(hdr.modelId);
          const frontDist = (def.length / 2) + (hDef.length / 2) + 4;
          hdr.angle = v.angle;
          hdr.x = v.x + Math.cos(v.angle) * frontDist;
          hdr.y = v.y + Math.sin(v.angle) * frontDist;
          hdr.working = v.working && !v.broken && v.fuel > 0;
          if (hdr.working && Math.abs(v.speed) > 3) this.applyCombineHarvest(v, hdr);
        }

        if (att) {
          const iDef = TF.DATA.getItem(att.modelId);
          const hitchDist = (def.length / 2) + (iDef.length / 2) + 8;
          att.angle = Math.atan2(v.y - att.y, v.x - att.x);
          att.x = v.x - Math.cos(att.angle) * hitchDist;
          att.y = v.y - Math.sin(att.angle) * hitchDist;
          att.selectedCrop = v.selectedCrop;
          if (att.working && !v.broken && v.fuel > 0 && Math.abs(v.speed) > 5) this.applyFieldWork(att, v);
        }
      }
    }
    if (this.trackTimer > 0.14) this.trackTimer = 0;
  },

  applyFieldWork(imp, tractor) {
    const iDef = TF.DATA.getItem(imp.modelId);
    const halfW = iDef.workWidth / 2;
    const perpX = -Math.sin(imp.angle), perpY = Math.cos(imp.angle);
    const steps = Math.max(4, Math.ceil(iDef.workWidth / 18));

    for (let s = 0; s <= steps; s++) {
      const frac = (s / steps) * 2 - 1;
      const wx = imp.x + perpX * halfW * frac, wy = imp.y + perpY * halfW * frac;
      const field = TF.World.getFieldAt(wx, wy);
      if (!field || (!field.owned && !TF.Game.isContractField(field.id))) continue;
      const hit = TF.World.getTileAt(field, wx, wy);
      if (!hit) continue;
      const tile = hit.tile;

      if (imp.role === 'plow' && tile.state === 'stubble') {
        tile.state = 'plowed'; tile.crop = null; tile.growth = 0;
        if (Math.random() < 0.32) {
          const isMud = (TF.World.soilWetness || 0) > 0.35;
          this.spawnParticle(wx + (Math.random() - 0.5) * 8, wy + (Math.random() - 0.5) * 8, -Math.cos(imp.angle) * 22 + (Math.random() - 0.5) * 16, -Math.sin(imp.angle) * 22 + (Math.random() - 0.5) * 16, isMud ? 'rgba(54, 38, 22, 0.7)' : 'rgba(110, 82, 52, 0.55)', 3 + Math.random() * 3, 0.42);
        }
      } else if (imp.role === 'seeder' && TF.Game.seasonIdx !== 3 && tile.state === 'plowed') {
        const activeC = TF.Game.getContractForField(field.id);
        const cropId = activeC && activeC.cropId ? activeC.cropId : (tractor.selectedCrop || 'wheat');
        const cDef = TF.DATA.CROPS[cropId];
        if (!TF.DATA.canSeederSow(iDef, cropId)) {
          if (tractor.uid === TF.Game.activeVehicleUid && this.wrongHeaderToastCooldown <= 0) {
            this.wrongHeaderToastCooldown = 4.0;
            const need = (cropId === 'corn' || cropId === 'sunflower')
              ? 'пропашная сажалка (СУПН-8 / Maestro / JD 1775NT)'
              : 'зерновая сеялка (СЗ-3.6 / Rapid / Citan)';
            TF.UI.toast(`Для культуры «${cDef.name}» нужна ${need}!`);
          }
          continue;
        }
        if (activeC) {
          tile.state = 'seeded'; tile.crop = cropId; tile.growth = 0.05;
        } else if (TF.Game.money >= cDef.seedCostPerTile) {
          TF.Game.money -= cDef.seedCostPerTile;
          tile.state = 'seeded'; tile.crop = cropId; tile.growth = 0.05;
        }
      } else if (imp.role === 'spreader' && !tile.fertilized && (tile.state === 'plowed' || tile.state === 'seeded')) {
        const activeC = TF.Game.getContractForField(field.id);
        if (activeC) { tile.fertilized = true; }
        else if (TF.Game.money >= 3) { TF.Game.money -= 3; tile.fertilized = true; }
      }
    }
    if (imp.role === 'plow') {
      TF.World.clearStrawInArea(imp.x, imp.y, iDef.workWidth * 0.55);
    }
  },

  applyCombineHarvest(combine, hdr) {
    if (TF.World.weather === 'rain') {
      if (combine.uid === TF.Game.activeVehicleUid && this.rainToastCooldown <= 0) {
        this.rainToastCooldown = 5.0;
        TF.UI.toast('🌧 Идёт дождь — комбайн не может косить мокрое зерно!');
      }
      return;
    }
    const cDef = TF.DATA.getItem(combine.modelId), hDef = TF.DATA.getItem(hdr.modelId);
    if (combine.cargo >= cDef.capacity) return;

    const halfW = hDef.workWidth / 2;
    const perpX = -Math.sin(hdr.angle), perpY = Math.cos(hdr.angle);
    const steps = Math.max(5, Math.ceil(hDef.workWidth / 16));
    let cutCrop = null;
    let cutCount = 0;

    for (let s = 0; s <= steps; s++) {
      const frac = (s / steps) * 2 - 1;
      const wx = hdr.x + perpX * halfW * frac, wy = hdr.y + perpY * halfW * frac;
      const field = TF.World.getFieldAt(wx, wy);
      if (!field || (!field.owned && !TF.Game.isContractField(field.id))) continue;
      const hit = TF.World.getTileAt(field, wx, wy);
      if (!hit) continue;
      const tile = hit.tile;

      if (tile.state === 'ready' && tile.crop) {
        const cropDef = TF.DATA.CROPS[tile.crop];
        if (cropDef.headerType !== hDef.headerType) {
          if (combine.uid === TF.Game.activeVehicleUid && this.wrongHeaderToastCooldown <= 0) {
            this.wrongHeaderToastCooldown = 4.0;
            const need = cropDef.headerType === 'corn' ? 'пропашная жатка (КМС-6 / Geringhoff)' : 'зерновая жатка (ЖЗ-4.1 / Convio)';
            TF.UI.toast(`Для культуры «${cropDef.name}» нужна ${need}!`);
          }
          continue;
        }
        if (combine.cargoCrop && combine.cargoCrop !== tile.crop) continue;
        const gain = cropDef.yieldPerTile * (tile.fertilized ? 1.5 : 1.0);
        const activeC = TF.Game.getContractForField(field.id);
        combine.cargoCrop = tile.crop;
        if (activeC) combine.cargoContractId = activeC.id;
        combine.cargo = Math.min(cDef.capacity, combine.cargo + gain);
        TF.Game.stats.harvestedLiters += gain;
        cutCrop = tile.crop;
        cutCount++;
        tile.state = 'stubble'; tile.crop = null; tile.growth = 0; tile.fertilized = false;
        // Эффект среза прямо на жатке
        if (Math.random() < 0.45) {
          this.spawnParticle(
            wx + (Math.random() - 0.5) * 10,
            wy + (Math.random() - 0.5) * 10,
            (Math.random() - 0.5) * 24,
            (Math.random() - 0.5) * 24,
            cropDef.colorRipe || '#e6c55c',
            2.5 + Math.random() * 2.5,
            0.35
          );
        }
        if (combine.cargo >= cDef.capacity) break;
      }
    }

    // Выброс валка соломы и половы прямо из кормы комбайна!
    if (cutCount > 0 && cutCrop) {
      const rearDist = cDef.length * 0.54;
      const rx = combine.x - Math.cos(combine.angle) * rearDist;
      const ry = combine.y - Math.sin(combine.angle) * rearDist;
      const isStraw = (cutCrop === 'wheat' || cutCrop === 'barley');
      TF.World.addStrawSegment(rx, ry, combine.angle, 20, isStraw ? 'swath' : 'chopped');

      const burst = isStraw ? 3 : 4;
      for (let k = 0; k < burst; k++) {
        if (Math.random() > 0.72) continue;
        const spread = (Math.random() - 0.5) * 0.75;
        const outAng = combine.angle + Math.PI + spread;
        const spd = 28 + Math.random() * 34;
        this.spawnParticle(
          rx + (Math.random() - 0.5) * 10,
          ry + (Math.random() - 0.5) * 10,
          Math.cos(outAng) * spd,
          Math.sin(outAng) * spd,
          isStraw ? 'rgba(235, 205, 112, 0.72)' : 'rgba(176, 146, 78, 0.62)',
          2.5 + Math.random() * 3.5,
          0.48
        );
      }
    }
  },

  punchNightLights(lctx, cam, vw, vh, hour) {
    const isNight = hour >= 19.0 || hour <= 6.5;
    if (!isNight) return;

    lctx.save();
    lctx.translate(vw / 2, vh / 2);
    lctx.scale(cam.zoom, cam.zoom);
    lctx.translate(-cam.x, -cam.y);
    lctx.globalCompositeOperation = 'destination-out';

    for (const v of this.list) {
      if ((v.category === 'tractor' || v.category === 'combine') && !v.broken && v.fuel > 0) {
        const def = TF.DATA.getItem(v.modelId);
        lctx.save();
        lctx.translate(v.x, v.y);
        lctx.rotate(v.angle);

        const fGrad = lctx.createRadialGradient(def.length * 0.45, 0, 12, def.length * 0.45 + 170, 0, 320);
        fGrad.addColorStop(0, 'rgba(0,0,0,0.96)');
        fGrad.addColorStop(0.6, 'rgba(0,0,0,0.72)');
        fGrad.addColorStop(1, 'rgba(0,0,0,0)');
        lctx.fillStyle = fGrad;
        lctx.beginPath();
        lctx.moveTo(def.length * 0.38, -def.width * 0.34);
        lctx.lineTo(def.length * 0.38 + 340, -155);
        lctx.lineTo(def.length * 0.38 + 340, 155);
        lctx.lineTo(def.length * 0.38, def.width * 0.34);
        lctx.closePath();
        lctx.fill();

        const aura = lctx.createRadialGradient(0, 0, 10, 0, 0, 95);
        aura.addColorStop(0, 'rgba(0,0,0,0.65)');
        aura.addColorStop(1, 'rgba(0,0,0,0)');
        lctx.fillStyle = aura;
        lctx.beginPath(); lctx.arc(0, 0, 95, 0, Math.PI * 2); lctx.fill();

        const rearLen = v.reversing ? 170 : 75;
        const rGrad = lctx.createRadialGradient(-def.length * 0.48, 0, 6, -def.length * 0.48 - rearLen * 0.5, 0, rearLen);
        rGrad.addColorStop(0, v.reversing ? 'rgba(0,0,0,0.9)' : 'rgba(0,0,0,0.55)');
        rGrad.addColorStop(1, 'rgba(0,0,0,0)');
        lctx.fillStyle = rGrad;
        lctx.beginPath();
        lctx.moveTo(-def.length * 0.45, -def.width * 0.35);
        lctx.lineTo(-def.length * 0.45 - rearLen, -rearLen * 0.55);
        lctx.lineTo(-def.length * 0.45 - rearLen, rearLen * 0.55);
        lctx.lineTo(-def.length * 0.45, def.width * 0.35);
        lctx.closePath();
        lctx.fill();

        lctx.restore();
      }
    }

    for (const s of TF.DATA.STATIONS) {
      const cx = s.x + s.w / 2, cy = s.y + s.h / 2;
      const sg = lctx.createRadialGradient(cx, cy, 20, cx, cy, 220);
      sg.addColorStop(0, 'rgba(0,0,0,0.72)');
      sg.addColorStop(1, 'rgba(0,0,0,0)');
      lctx.fillStyle = sg;
      lctx.beginPath(); lctx.arc(cx, cy, 220, 0, Math.PI * 2); lctx.fill();
    }

    lctx.restore();
  },

  draw(ctx, activeUid, hour) {
    const isNight = hour >= 19.0 || hour <= 6.5;

    const sorted = [...this.list].sort((a, b) => {
      const pa = (a.category === 'tractor' || a.category === 'combine') ? 1 : 0;
      const pb = (b.category === 'tractor' || b.category === 'combine') ? 1 : 0;
      return pa - pb;
    });

    for (const v of sorted) {
      const def = TF.DATA.getItem(v.modelId);
      ctx.save();
      ctx.translate(v.x, v.y);
      ctx.rotate(v.angle);
      const L = def.length, W = def.width;

      if (v.ai) {
        ctx.strokeStyle = 'rgba(79, 220, 110, 0.78)';
        ctx.lineWidth = 2.5; ctx.setLineDash([6, 4]);
        ctx.beginPath(); ctx.arc(0, 0, Math.max(L, W) * 0.7, 0, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]);
      }

      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      ctx.fillRect(-L / 2 + 4, -W / 2 + 5, L, W);

      if (v.category === 'tractor') TF.VehicleModels.drawTractor(ctx, def, v, L, W, isNight);
      else if (v.category === 'combine') TF.VehicleModels.drawCombineBody(ctx, def, v, L, W, isNight);
      else if (v.category === 'header') TF.VehicleModels.drawHeader(ctx, def, v);
      else if (v.category === 'trailer') TF.VehicleModels.drawTrailer(ctx, def, v, L, W);
      else TF.VehicleModels.drawImplement(ctx, def, v, L, W);

      ctx.restore();

      if ((v.category === 'combine' || v.role === 'trailer') && v.cargo > 0) {
        const pct = v.cargo / def.capacity;
        ctx.save();
        ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(v.x - 24, v.y - 44, 48, 7);
        ctx.fillStyle = pct > 0.9 ? '#ff5959' : '#f5c71a'; ctx.fillRect(v.x - 23, v.y - 43, 46 * pct, 5);
        ctx.restore();
      }
      if (v.broken) {
        ctx.save();
        ctx.font = 'bold 12px system-ui, sans-serif'; ctx.textAlign = 'center';
        ctx.fillStyle = 'rgba(140, 20, 20, 0.92)'; ctx.fillRect(v.x - 42, v.y - 62, 84, 18);
        ctx.fillStyle = '#ffd5d5'; ctx.fillText('💥 СЛОМАН', v.x, v.y - 49);
        ctx.restore();
      } else if (v.ai) {
        ctx.save();
        ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'center';
        const wObj = TF.AI.getWorkerById(v.ai.workerId);
        const txt = `👷 ${wObj ? wObj.name.split(' ')[0] : 'ИИ'}: ${TF.AI.getTaskLabel(v.ai.task)}`;
        const tw = ctx.measureText(txt).width + 12;
        ctx.fillStyle = 'rgba(15, 36, 20, 0.9)'; ctx.fillRect(v.x - tw / 2, v.y - 62, tw, 18);
        ctx.fillStyle = '#8df097'; ctx.fillText(txt, v.x, v.y - 49);
        ctx.restore();
      }
    }

    // Визуальный индикатор точной сцепки (подъезжай задом трактором / передом комбайном до ЗЕЛЁНОГО кружка!)
    const activeV = this.getByUid(activeUid);
    if (activeV && !activeV.ai && ((activeV.category === 'tractor' && !activeV.attachment) || (activeV.category === 'combine' && !activeV.frontAttachment))) {
      const myPt = this.getHitchPoint(activeV);
      const maxD = activeV.category === 'combine' ? 62 : 52;
      for (const item of this.list) {
        if (item.attachedTo) continue;
        const compat = (activeV.category === 'combine' && item.category === 'header') ||
                       (activeV.category === 'tractor' && (item.category === 'implement' || item.category === 'trailer'));
        if (!compat) continue;
        const tPt = this.getHitchPoint(item);
        const d = Math.hypot(myPt.x - tPt.x, myPt.y - tPt.y);
        if (d < 160) {
          const ready = d <= maxD;
          ctx.save();
          ctx.strokeStyle = ready ? '#5cff72' : 'rgba(255, 220, 90, 0.75)';
          ctx.lineWidth = ready ? 3.5 : 2;
          ctx.beginPath(); ctx.arc(tPt.x, tPt.y, ready ? 16 : 12, 0, Math.PI * 2); ctx.stroke();
          ctx.beginPath(); ctx.arc(myPt.x, myPt.y, 7, 0, Math.PI * 2); ctx.stroke();
          if (ready) {
            ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'center';
            ctx.fillStyle = '#5cff72'; ctx.fillText('🔗 СЦЕПИТЬ', tPt.x, tPt.y - 20);
          }
          ctx.restore();
        }
      }
    }

    // Оранжевый проблесковый маячок на крыше техники при движении по дорогам!
    const beaconFlash = Math.sin(performance.now() * 0.015) > 0;
    for (const v of this.list) {
      if ((v.category === 'tractor' || v.category === 'combine') && !v.broken && v.fuel > 0 && v.onRoad) {
        ctx.save();
        if (beaconFlash) {
          const g = ctx.createRadialGradient(v.x, v.y, 2, v.x, v.y, 28);
          g.addColorStop(0, 'rgba(255, 165, 0, 0.95)');
          g.addColorStop(0.5, 'rgba(255, 140, 0, 0.45)');
          g.addColorStop(1, 'rgba(255, 140, 0, 0)');
          ctx.fillStyle = g;
          ctx.beginPath(); ctx.arc(v.x, v.y, 28, 0, Math.PI * 2); ctx.fill();
        }
        ctx.fillStyle = beaconFlash ? '#ffae00' : '#7a4b00';
        ctx.beginPath(); ctx.arc(v.x, v.y, 4.5, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
    }

    // Золотой поток зерна из шнека комбайна в прицеп!
    for (const gs of this.activeGrainStreams) {
      ctx.save();
      ctx.strokeStyle = TF.DATA.CROPS[gs.crop]?.colorRipe || '#f0c419';
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(gs.x1, gs.y1); ctx.lineTo(gs.x2, gs.y2); ctx.stroke();
      ctx.restore();
    }

    for (const p of this.particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }
  },

  drawTailLights(ctx, v, L, W, isNight) {
    if (isNight || v.braking || v.reversing) {
      ctx.fillStyle = v.braking ? '#ff2a2a' : 'rgba(255, 50, 50, 0.85)';
      ctx.fillRect(-L * 0.48, -W * 0.34, 4, 6);
      ctx.fillRect(-L * 0.48,  W * 0.34 - 6, 4, 6);
    }
    if (v.reversing) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-L * 0.49, -W * 0.16, 4, 5);
      ctx.fillRect(-L * 0.49,  W * 0.16 - 5, 4, 5);
    }
  },

  drawTractor(ctx, def, v, L, W, isNight) {
    ctx.fillStyle = '#1c1f1d';
    if (def.tracks) {
      ctx.fillRect(-L * 0.44, -W * 0.56, L * 0.36, 9); ctx.fillRect(-L * 0.44,  W * 0.56 - 9, L * 0.36, 9);
      ctx.fillRect( L * 0.08, -W * 0.56, L * 0.36, 9); ctx.fillRect( L * 0.08,  W * 0.56 - 9, L * 0.36, 9);
    } else {
      ctx.fillRect(-L * 0.42, -W * 0.56, L * 0.32, 8); ctx.fillRect(-L * 0.42,  W * 0.56 - 8, L * 0.32, 8);
      ctx.fillRect( L * 0.14, -W * 0.52, L * 0.24, 6); ctx.fillRect( L * 0.14,  W * 0.52 - 6, L * 0.24, 6);
    }
    ctx.fillStyle = def.color; ctx.fillRect(-L * 0.45, -W * 0.36, L * 0.9, W * 0.72);
    ctx.fillStyle = '#25333d'; ctx.fillRect(-L * 0.34, -W * 0.31, L * 0.42, W * 0.62);
    ctx.strokeStyle = def.accent; ctx.lineWidth = 2; ctx.strokeRect(-L * 0.34, -W * 0.31, L * 0.42, W * 0.62);
    ctx.fillStyle = def.accent; ctx.fillRect(L * 0.35, -W * 0.28, 5, W * 0.56);
    ctx.fillStyle = isNight ? '#ffffff' : '#fff5b8';
    ctx.fillRect(L * 0.43, -W * 0.24, 4, 5); ctx.fillRect(L * 0.43,  W * 0.24 - 5, 4, 5);
    this.drawTailLights(ctx, v, L, W, isNight);
  },

  drawCombineBody(ctx, def, v, L, W, isNight) {
    ctx.fillStyle = '#1c1f1d';
    ctx.fillRect(L * 0.05, -W * 0.56, L * 0.3, 9); ctx.fillRect(L * 0.05,  W * 0.56 - 9, L * 0.3, 9);
    ctx.fillRect(-L * 0.42, -W * 0.48, L * 0.22, 7); ctx.fillRect(-L * 0.42,  W * 0.48 - 7, L * 0.22, 7);
    ctx.fillStyle = '#333835'; ctx.fillRect(L * 0.42, -W * 0.22, 10, W * 0.44);
    ctx.fillStyle = def.color; ctx.fillRect(-L * 0.48, -W * 0.42, L * 0.94, W * 0.84);
    ctx.fillStyle = v.cargo > 0 ? '#e8c451' : '#2d332f'; ctx.fillRect(-L * 0.26, -W * 0.30, L * 0.42, W * 0.60);
    ctx.fillStyle = '#25333d'; ctx.fillRect(L * 0.18, -W * 0.28, L * 0.24, W * 0.56);
    ctx.fillStyle = def.accent; ctx.fillRect(-L * 0.12, -W * 0.42 - 14, 7, 18);
    this.drawTailLights(ctx, v, L, W, isNight);
  },

  drawHeader(ctx, def, v) {
    const hw = def.workWidth;
    ctx.fillStyle = def.color; ctx.fillRect(-10, -hw / 2, 18, hw);
    ctx.strokeStyle = v.working ? '#ffe07d' : def.accent; ctx.lineWidth = v.working ? 3 : 2; ctx.strokeRect(-10, -hw / 2, 18, hw);
    if (def.headerType === 'corn') {
      ctx.fillStyle = def.accent;
      const rows = Math.max(4, Math.round(hw / 18));
      for (let i = 0; i < rows; i++) {
        const ry = -hw / 2 + (i + 0.5) * (hw / rows);
        ctx.beginPath(); ctx.moveTo(8, ry - 4); ctx.lineTo(22, ry); ctx.lineTo(8, ry + 4); ctx.closePath(); ctx.fill();
      }
    } else {
      ctx.strokeStyle = '#181a19'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(3, -hw / 2 + 4); ctx.lineTo(3, hw / 2 - 4); ctx.stroke();
    }
  },

  drawTrailer(ctx, def, v, L, W) {
    ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(L * 0.45, 0); ctx.lineTo(L * 0.66, 0); ctx.stroke();
    if (def.role === 'fuel_trailer') {
      ctx.fillStyle = def.color;
      ctx.beginPath(); ctx.roundRect(-L * 0.45, -W * 0.42, L * 0.88, W * 0.84, 10); ctx.fill();
      ctx.strokeStyle = def.accent; ctx.lineWidth = 3; ctx.stroke();
      ctx.fillStyle = '#c43a2b'; ctx.fillRect(-6, -6, 12, 12);
    } else {
      ctx.fillStyle = def.color; ctx.fillRect(-L * 0.46, -W * 0.46, L * 0.92, W * 0.92);
      ctx.strokeStyle = def.accent; ctx.lineWidth = 2; ctx.strokeRect(-L * 0.46, -W * 0.46, L * 0.92, W * 0.92);
      if (v.cargo > 0) {
        const pct = Math.max(0.18, v.cargo / def.capacity);
        ctx.fillStyle = v.cargoCrop ? TF.DATA.CROPS[v.cargoCrop].colorRipe : '#e8c451';
        ctx.fillRect(-L * 0.4, -W * 0.38, L * 0.8 * pct, W * 0.76);
      }
    }
  },

  drawImplement(ctx, def, v, L, W) {
    const ww = def.workWidth;
    ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(L * 0.7, 0); ctx.stroke();
    ctx.fillStyle = def.color; ctx.fillRect(-10, -ww / 2, 20, ww);
    ctx.strokeStyle = v.working ? '#ffe07d' : def.accent; ctx.lineWidth = v.working ? 3 : 2; ctx.strokeRect(-10, -ww / 2, 20, ww);
    if (def.role === 'seeder' || def.role === 'spreader') {
      ctx.fillStyle = def.accent; ctx.fillRect(-14, -Math.min(ww * 0.35, 24), 24, Math.min(ww * 0.7, 48));
    }
  }
};
