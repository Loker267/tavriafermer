window.TF = window.TF || {};

TF.AI = {
  hiredWorkerIds: [],

  reset() { this.hiredWorkerIds = []; },
  getWorkerById(id) { return TF.DATA.WORKER_POOL.find(w => w.id === id) || null; },
  isHired(id) { return this.hiredWorkerIds.includes(id); },
  getAssignedVehicle(workerId) { return TF.Vehicles.list.find(v => v.ai && v.ai.workerId === workerId) || null; },
  getFreeWorkers() { return this.hiredWorkerIds.map(id => this.getWorkerById(id)).filter(w => w && !this.getAssignedVehicle(w.id)); },

  recruitWorker(workerId) {
    const w = this.getWorkerById(workerId);
    if (!w || this.isHired(workerId)) return false;
    if (TF.Game.money < w.hireCost) { TF.UI.toast(`Не хватает денег ($${w.hireCost.toLocaleString('ru-RU')}).`); return false; }
    TF.Game.addMoney(-w.hireCost);
    this.hiredWorkerIds.push(workerId);
    TF.Audio.playCash();
    TF.UI.toast(`👷 ${w.name} принят в штат!`);
    TF.Game.save();
    return true;
  },

  getTaskLabel(task) {
    return { harvest: 'Косит', plow: 'Пашет', seed: 'Сеет', fertilize: 'Удобр.', haul: 'Возит' }[task] || 'ИИ';
  },

  getRecommendedTask(vehicle) {
    if (!vehicle) return 'harvest';
    if (vehicle.category === 'combine') return 'harvest';
    if (vehicle.attachment) {
      const att = TF.Vehicles.getByUid(vehicle.attachment);
      if (att) {
        if (att.role === 'trailer') return 'haul';
        if (att.role === 'plow') return 'plow';
        if (att.role === 'seeder') return 'seed';
        if (att.role === 'spreader') return 'fertilize';
      }
    }
    return 'plow';
  },

  projectOnSegment(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const lenSq = dx * dx + dy * dy;
    let t = lenSq === 0 ? 0 : ((px - x1) * dx + (py - y1) * dy) / lenSq;
    t = Math.max(0, Math.min(1, t));
    const qx = x1 + t * dx, qy = y1 + t * dy;
    return { x: qx, y: qy, dist: Math.hypot(px - qx, py - qy), t };
  },

  findNearestRoadEdgePoint(px, py) {
    const nodes = TF.DATA.ROAD_NODES;
    let best = null;
    for (let ei = 0; ei < TF.DATA.ROAD_EDGES.length; ei++) {
      const [a, b] = TF.DATA.ROAD_EDGES[ei];
      const na = nodes[a], nb = nodes[b];
      const pr = this.projectOnSegment(px, py, na.x, na.y, nb.x, nb.y);
      if (!best || pr.dist < best.dist) best = { x: pr.x, y: pr.y, dist: pr.dist, a, b, ei };
    }
    return best;
  },

  buildRoadPath(x1, y1, x2, y2, exitField = null, enterField = null) {
    const wps = [];
    let curX = x1, curY = y1;
    if (exitField) {
      wps.push({ x: exitField.entrance.x, y: exitField.entrance.y });
      wps.push({ x: exitField.entrance.gx, y: exitField.entrance.gy });
      curX = exitField.entrance.gx; curY = exitField.entrance.gy;
    }

    const goalX = enterField ? enterField.entrance.gx : x2;
    const goalY = enterField ? enterField.entrance.gy : y2;
    const crossesCanal = (curY - TF.DATA.CANAL.y) * (goalY - TF.DATA.CANAL.y) < 0;
    const directDist = Math.hypot(goalX - curX, goalY - curY);

    if (directDist > 340 || crossesCanal) {
      const baseNodes = TF.DATA.ROAD_NODES.map(n => ({ x: n.x, y: n.y }));
      const N = baseNodes.length;
      const startP = this.findNearestRoadEdgePoint(curX, curY);
      const endP = this.findNearestRoadEdgePoint(goalX, goalY);
      const allNodes = [...baseNodes, { x: startP.x, y: startP.y }, { x: endP.x, y: endP.y }];
      const startId = N, endId = N + 1;
      const adj = Array.from({ length: N + 2 }, () => []);
      const addEdge = (u, v) => {
        const d = Math.hypot(allNodes[u].x - allNodes[v].x, allNodes[u].y - allNodes[v].y);
        adj[u].push({ to: v, w: d }); adj[v].push({ to: u, w: d });
      };
      for (const [a, b] of TF.DATA.ROAD_EDGES) addEdge(a, b);
      addEdge(startId, startP.a); addEdge(startId, startP.b);
      addEdge(endId, endP.a); addEdge(endId, endP.b);
      if (startP.ei === endP.ei) addEdge(startId, endId);

      const dist = new Array(N + 2).fill(Infinity), prev = new Array(N + 2).fill(-1), used = new Array(N + 2).fill(false);
      dist[startId] = 0;
      for (let iter = 0; iter < N + 2; iter++) {
        let u = -1;
        for (let i = 0; i < N + 2; i++) if (!used[i] && (u === -1 || dist[i] < dist[u])) u = i;
        if (u === -1 || dist[u] === Infinity) break;
        used[u] = true;
        for (const e of adj[u]) if (dist[u] + e.w < dist[e.to]) { dist[e.to] = dist[u] + e.w; prev[e.to] = u; }
      }
      const roadPts = [];
      for (let cur = endId; cur !== -1; cur = prev[cur]) roadPts.push(allNodes[cur]);
      roadPts.reverse();
      for (const pt of roadPts) {
        if (wps.length === 0 || Math.hypot(pt.x - wps[wps.length - 1].x, pt.y - wps[wps.length - 1].y) > 45) wps.push({ x: pt.x, y: pt.y });
      }
    }

    if (enterField) {
      wps.push({ x: enterField.entrance.gx, y: enterField.entrance.gy });
      wps.push({ x: enterField.entrance.x, y: enterField.entrance.y });
    }
    wps.push({ x: x2, y: y2 });

    // Убираем лишний крюк (если точка [0] ведёт назад относительно пути к точке [1] и не пересекает канал)
    if (wps.length >= 2) {
      const d01 = Math.hypot(wps[1].x - wps[0].x, wps[1].y - wps[0].y);
      const dStart1 = Math.hypot(wps[1].x - x1, wps[1].y - y1);
      const crossC = (y1 - TF.DATA.CANAL.y) * (wps[1].y - TF.DATA.CANAL.y) < 0;
      if (!exitField && !crossC && dStart1 < d01 * 0.95 && dStart1 < 550) {
        wps.shift();
      }
    }
    return wps;
  },

  isPointBlocked(x, y, rad) {
    if (Math.abs(y - TF.DATA.CANAL.y) < TF.DATA.CANAL.w / 2 + rad + 4 && !TF.World.isOnBridge(x, y)) return true;
    for (let i = 0; i < TF.World.trees.length; i++) {
      const tr = TF.World.trees[i];
      if (Math.abs(x - tr.x) < rad + tr.r && Math.abs(y - tr.y) < rad + tr.r) {
        if (Math.hypot(x - tr.x, y - tr.y) < rad + tr.r * 0.8) return true;
      }
    }
    for (let i = 0; i < TF.World.houses.length; i++) {
      const h = TF.World.houses[i];
      if (x >= h.x - rad && x <= h.x + h.w + rad && y >= h.y - rad && y <= h.y + h.h + rad) return true;
    }
    for (let i = 0; i < TF.DATA.STATIONS.length; i++) {
      const s = TF.DATA.STATIONS[i];
      if (x >= s.x - rad && x <= s.x + s.w + rad && y >= s.y - rad && y <= s.y + s.h + rad) return true;
    }
    return false;
  },

  computeAvoidance(v) {
    const def = TF.DATA.getItem(v.modelId);
    const rad = Math.max(def.width, def.length) * 0.36;
    const probeDists = [64, 118];
    let leftHit = false, rightHit = false, centerHit = false;
    for (const d of probeDists) {
      if (this.isPointBlocked(v.x + Math.cos(v.angle) * d, v.y + Math.sin(v.angle) * d, rad)) centerHit = true;
      if (this.isPointBlocked(v.x + Math.cos(v.angle - 0.55) * d, v.y + Math.sin(v.angle - 0.55) * d, rad)) leftHit = true;
      if (this.isPointBlocked(v.x + Math.cos(v.angle + 0.55) * d, v.y + Math.sin(v.angle + 0.55) * d, rad)) rightHit = true;
    }
    if (!centerHit && !leftHit && !rightHit) return { steerBias: 0, speedScale: 1.0, blocked: false };
    if (leftHit && !rightHit) return { steerBias: 0.95, speedScale: 0.65, blocked: centerHit };
    if (rightHit && !leftHit) return { steerBias: -0.95, speedScale: 0.65, blocked: centerHit };
    const farL = this.isPointBlocked(v.x + Math.cos(v.angle - 1.05) * 95, v.y + Math.sin(v.angle - 1.05) * 95, rad);
    return { steerBias: farL ? 1.0 : -1.0, speedScale: 0.45, blocked: true };
  },

  assign(workerId, vehicle, fieldId, task, cropId) {
    if (!vehicle) return false;
    if (vehicle.broken) { TF.UI.toast('Эта техника сломана! Сначала вызови техпомощь.'); return false; }
    const worker = this.getWorkerById(workerId);
    if (!worker || !this.isHired(workerId)) { TF.UI.toast('Сначала наймите работника на Бирже труда!'); return false; }

    const prevVeh = this.getAssignedVehicle(workerId);
    if (prevVeh) this.stopVehicle(prevVeh, true);
    if (vehicle.ai) this.stopVehicle(vehicle, true);

    const field = TF.World.fields.find(f => f.id === Number(fieldId));
    if (!field || (!field.owned && !TF.Game.isContractField(field.id))) {
      TF.UI.toast('Выберите своё поле или поле с активным контрактом.'); return false;
    }

    if (task === 'harvest') {
      if (vehicle.category !== 'combine') { TF.UI.toast('Для уборки нужен комбайн.'); return false; }
      if (!vehicle.frontAttachment) { TF.UI.toast('Прицепите жатку к комбайну (🔗)!'); return false; }
      const hDef = TF.DATA.getItem(TF.Vehicles.getByUid(vehicle.frontAttachment).modelId);
      const sum = TF.World.getFieldSummary(field);
      if (sum.mainCrop && TF.DATA.CROPS[sum.mainCrop].headerType !== hDef.headerType) {
        TF.UI.toast(`На поле ${TF.DATA.CROPS[sum.mainCrop].name} — нужна другая жатка!`); return false;
      }
    } else if (task === 'haul') {
      const att = vehicle.attachment ? TF.Vehicles.getByUid(vehicle.attachment) : null;
      if (vehicle.category !== 'tractor' || !att || att.role !== 'trailer') { TF.UI.toast('Возчику нужен трактор с зерновым прицепом!'); return false; }
    } else {
      const att = vehicle.attachment ? TF.Vehicles.getByUid(vehicle.attachment) : null;
      const expected = task === 'fertilize' ? 'spreader' : (task === 'seed' ? 'seeder' : task);
      if (vehicle.category !== 'tractor' || !att || att.role !== expected) {
        const needName = task === 'seed' ? 'сеялка или сажалка' : (task === 'fertilize' ? 'разбрасыватель или опрыскиватель' : 'плуг или культиватор');
        TF.UI.toast(`Для задачи «${this.getTaskLabel(task)}» к трактору нужен ${needName}!`);
        return false;
      }
      if (task === 'seed') {
        const attDef = TF.DATA.getItem(att.modelId);
        const activeC = TF.Game.getContractForField(field.id);
        let chosenCrop = (activeC && activeC.cropId) ? activeC.cropId : (cropId || vehicle.selectedCrop || 'wheat');
        if (!TF.DATA.canSeederSow(attDef, chosenCrop)) {
          if (activeC && activeC.cropId) {
            const needType = (chosenCrop === 'corn' || chosenCrop === 'sunflower') ? 'пропашная сажалка' : 'зерновая сеялка';
            TF.UI.toast(`Для посева «${TF.DATA.CROPS[chosenCrop].name}» нужна ${needType}!`);
            return false;
          }
          const allowed = TF.DATA.getSeederAllowedCrops(attDef);
          if (allowed.length) chosenCrop = allowed[0];
        }
        vehicle.selectedCrop = chosenCrop;
      }
    }

    const fieldWps = task === 'haul' ? [] : this.buildFieldWaypoints(vehicle, field);
    let routeWps = [];
    const curField = TF.World.getFieldAt(vehicle.x, vehicle.y);
    const insideTarget = curField && curField.id === field.id;
    if (task !== 'haul' && fieldWps.length > 0 && !insideTarget) {
      const distGate = Math.hypot(vehicle.x - field.entrance.x, vehicle.y - field.entrance.y);
      const crossesCanal = (vehicle.y - TF.DATA.CANAL.y) * (field.entrance.y - TF.DATA.CANAL.y) < 0;
      if (!curField && distGate < 560 && !crossesCanal) {
        routeWps = [{ x: field.entrance.gx, y: field.entrance.gy }, { x: field.entrance.x, y: field.entrance.y }];
      } else {
        routeWps = this.buildRoadPath(vehicle.x, vehicle.y, fieldWps[0].x, fieldWps[0].y, curField, field);
      }
    }

    vehicle.ai = {
      workerId, task, fieldId: field.id, cropId: cropId || vehicle.selectedCrop || 'wheat',
      routeWps, routeIdx: 0, waypoints: fieldWps, wpIdx: 0,
      state: routeWps.length > 0 ? 'travel' : 'work',
      notifiedFull: false,
      stuckTimer: 0, lastX: vehicle.x, lastY: vehicle.y, unstuckTimer: 0, unstuckDir: 1, stuckCount: 0
    };

    TF.UI.toast(`👷 ${worker.name} выехал на ${TF.DATA.getItem(vehicle.modelId).name} → ${field.name}`);
    return true;
  },

  stopVehicle(vehicle, silent = false) {
    if (!vehicle || !vehicle.ai) return;
    vehicle.ai = null; vehicle.working = false;
    if (vehicle.attachment) { const a = TF.Vehicles.getByUid(vehicle.attachment); if (a) a.working = false; }
    if (vehicle.frontAttachment) { const h = TF.Vehicles.getByUid(vehicle.frontAttachment); if (h) h.working = false; }
    if (!silent) TF.UI.toast(`Работник на ${TF.DATA.getItem(vehicle.modelId).name} остановлен.`);
  },

  // ЧЕСТНЫЙ УЧЁТ ШИРИНЫ ЖАТКИ / ОРУДИЯ:
  // Малая жатка 4.1м (78px) делает узкие проходы, гигантская Convio 13.8м (230px) — широкие проходы!
  // Отступ margin = ~44% ширины жатки, чтобы гигантская жатка не вылезала в деревья, а шаг 86% даёт 100% покрытие без полос!
  buildFieldWaypoints(vehicle, field) {
    let wWidth = 72;
    if (vehicle.category === 'combine' && vehicle.frontAttachment) {
      wWidth = TF.DATA.getItem(TF.Vehicles.getByUid(vehicle.frontAttachment).modelId).workWidth;
    } else if (vehicle.attachment) {
      wWidth = TF.DATA.getItem(TF.Vehicles.getByUid(vehicle.attachment).modelId).workWidth;
    }
    const step = Math.max(36, wWidth * 0.86);
    const marginY = Math.min(field.h * 0.42, Math.max(24, wWidth * 0.44));
    // Комбайны разворачиваются строго ВНУТРИ коридора поля (без вылета в лесополосу!)
    const padX = vehicle.category === 'combine' ? 18 : 16;
    const rowsY = [];
    let y = field.y + marginY;
    const maxY = field.y + field.h - marginY;
    while (true) {
      rowsY.push(Math.min(field.y + field.h - 22, y));
      if (y >= maxY - 4) break;
      y = Math.min(maxY, y + step);
    }
    // Если въезд снизу — косим снизу вверх, чтобы сразу начинать работу у ворот без кругов!
    if (field.entrance && field.entrance.side === 'bottom') rowsY.reverse();

    const wps = [];
    let dir = 1;
    for (const cy of rowsY) {
      if (dir === 1) {
        wps.push({ x: field.x + padX, y: cy });
        wps.push({ x: field.x + field.w - padX, y: cy });
      } else {
        wps.push({ x: field.x + field.w - padX, y: cy });
        wps.push({ x: field.x + padX, y: cy });
      }
      dir *= -1;
    }
    return wps;
  },

  steerTowards(v, tx, ty, slowNear = false, avoidObstacles = true) {
    const dx = tx - v.x, dy = ty - v.y, dist = Math.hypot(dx, dy);
    const desired = Math.atan2(dy, dx);
    let diff = desired - v.angle;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;

    let steer = Math.max(-1, Math.min(1, diff * 2.2));
    let throttle = Math.abs(diff) > 1.35 ? 0.42 : 1.0;
    if (slowNear && dist < 110) throttle *= 0.55;

    if (avoidObstacles && dist > 55) {
      const av = this.computeAvoidance(v);
      if (av.steerBias !== 0) {
        steer = Math.max(-1, Math.min(1, steer * 0.3 + av.steerBias * 0.9));
        throttle *= av.speedScale;
      }
    }
    return { throttle, steer, dist };
  },

  setWorkingState(v, on) {
    v.working = on;
    if (v.attachment) { const a = TF.Vehicles.getByUid(v.attachment); if (a && a.category === 'implement') a.working = on; }
    if (v.frontAttachment) { const h = TF.Vehicles.getByUid(v.frontAttachment); if (h) h.working = on; }
  },

  updateVehicle(v, dt) {
    const ai = v.ai;
    if (!ai) return { throttle: 0, steer: 0, speedMult: 1 };
    const worker = this.getWorkerById(ai.workerId);
    const wage = worker ? worker.wagePerSec : 0.4;
    const speedMult = worker ? worker.speedBonus : 1.0;

    TF.Game.money = Math.max(0, TF.Game.money - wage * dt);
    if (v.fuel <= 1 || v.broken) { this.stopVehicle(v, true); return { throttle: 0, steer: 0, speedMult }; }

    // Уверенный задний ход при застревании (с выкрученным рулём, чтобы гарантированно отъехать от дерева!)
    if (ai.unstuckTimer > 0) {
      ai.unstuckTimer -= dt;
      return { throttle: -0.85, steer: ai.unstuckDir, speedMult: 1.0 };
    }

    let ctrl = { throttle: 0, steer: 0 };
    if (ai.task === 'haul') ctrl = this.updateHauler(v, dt);
    else ctrl = this.updateFieldWorker(v, dt, worker);

    // ФИКС: снижен порог до > 0.05, чтобы замедлившийся перед деревом комбайн ГАРАНТИРОВАННО срабатывал на реверс!
    if (Math.abs(ctrl.throttle) > 0.05) {
      ai.stuckTimer += dt;
      if (ai.stuckTimer >= 1.1) {
        const moved = Math.hypot(v.x - ai.lastX, v.y - ai.lastY);
        ai.lastX = v.x; ai.lastY = v.y; ai.stuckTimer = 0;
        if (moved < 16) {
          ai.stuckCount = (ai.stuckCount || 0) + 1;
          const av = this.computeAvoidance(v);
          ai.unstuckTimer = 1.6;
          ai.unstuckDir = av.steerBias !== 0 ? -Math.sign(av.steerBias) : (ai.stuckCount % 2 === 0 ? 1 : -1);
          // Если упёрлись дважды подряд возле текущей точки маршрута — переходим к следующей!
          if (ai.stuckCount >= 2) {
            ai.stuckCount = 0;
            if (ai.state === 'travel' && ai.routeIdx < ai.routeWps.length - 1) ai.routeIdx++;
            else if (ai.state === 'work' && ai.wpIdx < ai.waypoints.length - 1) ai.wpIdx++;
          }
        } else {
          ai.stuckCount = 0;
        }
      }
    } else {
      ai.stuckTimer = 0; ai.lastX = v.x; ai.lastY = v.y;
    }

    return { ...ctrl, speedMult };
  },

  updateFieldWorker(v, dt, worker) {
    const ai = v.ai;
    if (ai.state === 'travel') {
      this.setWorkingState(v, false);
      if (ai.routeIdx >= ai.routeWps.length) {
        ai.state = 'work';
      } else {
        const wp = ai.routeWps[ai.routeIdx];
        const res = this.steerTowards(v, wp.x, wp.y, false, true);
        if (res.dist < 72) ai.routeIdx++;
        return { throttle: res.throttle, steer: res.steer };
      }
    }

    if (v.category === 'combine' && TF.World.weather === 'rain') {
      this.setWorkingState(v, false);
      return { throttle: 0, steer: 0 };
    }

    if (v.category === 'combine') {
      const def = TF.DATA.getItem(v.modelId);
      const nearTr = TF.Vehicles.findNearbyTrailer(v, 148);
      // Начинаем ждать выгрузку, если бункер полон ИЛИ рядом уже встал прицеп с местом!
      if (v.cargo >= def.capacity * 0.98) {
        ai.waitingUnload = true;
        if (!ai.notifiedFull) { ai.notifiedFull = true; TF.UI.toast(`🌾 Комбайн ${def.name} полон! Ждёт прицеп для выгрузки.`); }
      } else if (nearTr && v.cargo > 40) {
        ai.waitingUnload = true;
      }

      if (ai.waitingUnload) {
        // Выходим из ожидания, если:
        // 1) бункер полностью пуст (<= 5 л), ИЛИ
        // 2) прицеп рядом заполнился на 100% (nearTr стал null, т.к. findNearbyTrailer ищет только с местом!) и в комбайне ещё есть место косить!
        if (v.cargo <= 5) {
          ai.waitingUnload = false;
          ai.notifiedFull = false;
        } else if (!nearTr && v.cargo < def.capacity * 0.95) {
          ai.waitingUnload = false;
          ai.notifiedFull = false;
        } else {
          this.setWorkingState(v, false);
          return { throttle: 0, steer: 0 };
        }
      }
    }
    this.setWorkingState(v, true);

    // Если на поле уже не осталось работы по этой задаче — сразу отключаем бота, не катаемся впустую!
    const fObj = TF.World.fields.find(f => f.id === ai.fieldId);
    if (fObj) {
      const s = TF.World.getFieldSummary(fObj);
      const taskDone =
        (ai.task === 'harvest' && s.pctReady === 0) ||
        (ai.task === 'plow' && s.pctStubble === 0) ||
        (ai.task === 'seed' && s.pctPlowed === 0) ||
        (ai.task === 'fertilize' && s.pctFert >= 99);
      if (taskDone) {
        TF.UI.toast(`✅ ${worker ? worker.name : 'Работник'} закончил Поле №${ai.fieldId} и остановился.`);
        this.stopVehicle(v, true);
        return { throttle: 0, steer: 0 };
      }
    }

    if (ai.wpIdx >= ai.waypoints.length) {
      TF.UI.toast(`✅ ${worker ? worker.name : 'Работник'} закончил Поле №${ai.fieldId} и остановился.`);
      this.stopVehicle(v, true);
      return { throttle: 0, steer: 0 };
    }

    const wp = ai.waypoints[ai.wpIdx];
    const isFinalWp = ai.wpIdx === ai.waypoints.length - 1;
    const res = this.steerTowards(v, wp.x, wp.y, isFinalWp, false);
    if (res.dist < (isFinalWp ? 62 : 50)) {
      ai.wpIdx++;
      if (ai.wpIdx >= ai.waypoints.length) {
        TF.UI.toast(`✅ ${worker ? worker.name : 'Работник'} закончил Поле №${ai.fieldId} и остановился.`);
        this.stopVehicle(v, true);
        return { throttle: 0, steer: 0 };
      }
    }
    return { throttle: res.throttle, steer: res.steer };
  },

  updateHauler(v, dt) {
    const ai = v.ai;
    const trailer = v.attachment ? TF.Vehicles.getByUid(v.attachment) : null;
    if (!trailer) { this.stopVehicle(v, false); return { throttle: 0, steer: 0 }; }
    const tDef = TF.DATA.getItem(trailer.modelId);
    const field = TF.World.fields.find(f => f.id === ai.fieldId);

    const startTripToElevator = () => {
      const elev = this.getBestElevator(trailer.cargoCrop);
      const curField = TF.World.getFieldAt(v.x, v.y);
      ai.targetElevId = elev.id;
      // Едем строго на координаты приёмной решётки (pitX, pitY) со смещением вперёд, чтобы сам ПРИЦЕП встал на решётку!
      ai.routeWps = this.buildRoadPath(v.x, v.y, elev.pitX + 42, elev.pitY, curField, null);
      ai.routeIdx = 0; ai.state = 'to_elevator';
    };

    if (trailer.cargo >= tDef.capacity * 0.99 && ai.state !== 'to_elevator' && ai.state !== 'unloading_pit') startTripToElevator();

    if (ai.state === 'to_elevator') {
      if (ai.routeIdx < ai.routeWps.length) {
        const wp = ai.routeWps[ai.routeIdx], isLast = ai.routeIdx === ai.routeWps.length - 1;
        // ФИКС КРУГОВ: пока выезжаем изнутри поля через ворота, отключаем панику от лесополосы!
        const insideAnyField = !!TF.World.getFieldAt(v.x, v.y);
        const res = this.steerTowards(v, wp.x, wp.y, isLast, !insideAnyField);
        if (res.dist < (isLast ? 48 : 74)) ai.routeIdx++;
        return { throttle: res.throttle, steer: res.steer };
      }
      ai.state = 'unloading_pit';
      return { throttle: 0, steer: 0 };
    }

    // Стоим на приёмной решётке элеватора: проверяем позицию САМОГО ПРИЦЕПА!
    if (ai.state === 'unloading_pit') {
      if (trailer.cargo > 1) {
        const elev = TF.DATA.STATIONS.find(s => s.id === ai.targetElevId) || this.getBestElevator(trailer.cargoCrop);
        const dTrailer = Math.hypot(trailer.x - elev.pitX, trailer.y - elev.pitY);
        if (dTrailer > 68) {
          // Если прицеп чуть не дотянул до решётки — подтягиваем трактор вперёд, чтобы прицеп заехал ровно на яму!
          const pullX = elev.pitX + (elev.pitX >= v.x ? 55 : -55);
          const pullY = elev.pitY;
          const res = this.steerTowards(v, pullX, pullY, true, false);
          return { throttle: Math.max(0.35, res.throttle * 0.65), steer: res.steer };
        }
        return { throttle: 0, steer: 0 };
      }
      if (field) {
        ai.routeWps = this.buildRoadPath(v.x, v.y, field.entrance.gx, field.entrance.gy, null, null);
        ai.routeIdx = 0; ai.state = 'return_field';
      } else ai.state = 'work';
      return { throttle: 0.4, steer: 0 };
    }

    if (ai.state === 'return_field') {
      if (ai.routeIdx < ai.routeWps.length) {
        const wp = ai.routeWps[ai.routeIdx];
        const res = this.steerTowards(v, wp.x, wp.y, ai.routeIdx === ai.routeWps.length - 1, true);
        if (res.dist < 76) ai.routeIdx++;
        return { throttle: res.throttle, steer: res.steer };
      }
      ai.state = 'work';
    }

    let bestComb = null, bestScore = -1;
    for (const c of TF.Vehicles.list) {
      if (c.category === 'combine' && c.cargo > 350 && (!trailer.cargoCrop || c.cargoCrop === trailer.cargoCrop)) {
        const fill = c.cargo / TF.DATA.getItem(c.modelId).capacity;
        const bonus = (c.ai && c.ai.fieldId === ai.fieldId) ? 1.5 : 1.0;
        if (fill * bonus > bestScore) { bestScore = fill * bonus; bestComb = c; }
      }
    }

    if (bestComb) {
      // Если прицеп уже полон на 98% — сразу едем на элеватор!
      if (trailer.cargo >= tDef.capacity * 0.99) {
        startTripToElevator();
        return { throttle: 0.5, steer: 0 };
      }
      const combField = TF.World.getFieldAt(bestComb.x, bestComb.y);
      const myField = TF.World.getFieldAt(v.x, v.y);
      if (combField && (!myField || myField.id !== combField.id) && Math.hypot(v.x - combField.entrance.x, v.y - combField.entrance.y) > 95) {
        const res = this.steerTowards(v, combField.entrance.x, combField.entrance.y, false, true);
        return { throttle: res.throttle, steer: res.steer };
      }
      // Проверяем расстояние именно от ПРИЦЕПА до комбайна!
      const dTrailerToComb = Math.hypot(trailer.x - bestComb.x, trailer.y - bestComb.y);
      if (dTrailerToComb <= 125) {
        return { throttle: 0, steer: 0 }; // Прицеп точно под шнеком — стоим и грузимся!
      }
      // Целимся чуть вперёд сбоку от комбайна, чтобы ПРИЦЕП встал ровно рядом с трубой!
      const sideX = bestComb.x - Math.sin(bestComb.angle) * 64 + Math.cos(bestComb.angle) * 48;
      const sideY = bestComb.y + Math.cos(bestComb.angle) * 64 + Math.sin(bestComb.angle) * 48;
      const insideField = !!myField;
      const res = this.steerTowards(v, sideX, sideY, true, !insideField);
      return { throttle: Math.max(0.35, res.throttle), steer: res.steer };
    }

    // Не уезжаем полупустыми — ждём у поля, пока прицеп не забьётся на 100%!
    if (field) {
      // Если на поле уже всё убрано и ни в одном комбайне нет зерна — сдаём остаток (если есть) или отключаемся!
      const fSum = TF.World.getFieldSummary(field);
      const anyCombineWorking = TF.Vehicles.list.some(c => c.category === 'combine' && (c.cargo > 50 || (c.ai && c.ai.fieldId === field.id)));
      if (fSum.pctReady === 0 && !anyCombineWorking) {
        if (trailer.cargo > 50) {
          startTripToElevator();
          return { throttle: 0.4, steer: 0 };
        }
        TF.UI.toast(`✅ Возчик закончил вывоз с Поля №${field.id} и остановился.`);
        this.stopVehicle(v, true);
        return { throttle: 0, steer: 0 };
      }
      const dGate = Math.hypot(v.x - field.entrance.gx, v.y - field.entrance.gy);
      if (dGate < 95) return { throttle: 0, steer: 0 };
      const res = this.steerTowards(v, field.entrance.gx, field.entrance.gy, true, true);
      return { throttle: res.throttle, steer: res.steer };
    }
    return { throttle: 0, steer: 0 };
  },

  getBestElevator(cropId) {
    const elevs = TF.DATA.STATIONS.filter(s => s.type === 'elevator');
    let best = elevs[0], bestP = -1;
    for (const e of elevs) { const p = TF.World.getSellPrice(cropId || 'wheat', e); if (p > bestP) { bestP = p; best = e; } }
    return best;
  }
};
