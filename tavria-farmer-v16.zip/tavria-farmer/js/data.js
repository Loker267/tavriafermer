window.TF = window.TF || {};

TF.DATA = {
  WORLD_W: 9600,
  WORLD_H: 7200,
  TILE_SIZE: 40,

  SEASONS: [
    { id: 'spring', name: 'Весна', icon: '🌱', skyTint: 'rgba(130, 210, 140, 0.04)', growthMult: 1.15 },
    { id: 'summer', name: 'Лето',  icon: '☀',  skyTint: 'rgba(255, 220, 120, 0.05)', growthMult: 1.35 },
    { id: 'autumn', name: 'Осень', icon: '🍂', skyTint: 'rgba(210, 140, 60, 0.07)',  growthMult: 0.90 },
    { id: 'winter', name: 'Зима',  icon: '❄',  skyTint: 'rgba(160, 205, 240, 0.16)', growthMult: 0.0  }
  ],
  DAYS_PER_SEASON: 3,
  TIME_SPEEDS: [1, 5, 15, 60, 120],

  // 6 культур (headerType: 'grain' — зерновая жатка, 'corn' — пропашная жатка!)
  CROPS: {
    wheat: {
      id: 'wheat', name: 'Пшеница', icon: '🌾', headerType: 'grain',
      yieldPerTile: 34, basePrice: 410, seedCostPerTile: 3, growDays: 1.6,
      colorYoung: '#5a8f3d', colorMid: '#8db343', colorRipe: '#e2bc54'
    },
    barley: {
      id: 'barley', name: 'Ячмень', icon: '🌿', headerType: 'grain',
      yieldPerTile: 38, basePrice: 360, seedCostPerTile: 2.5, growDays: 1.3,
      colorYoung: '#619645', colorMid: '#9ec25b', colorRipe: '#d4b86a'
    },
    corn: {
      id: 'corn', name: 'Кукуруза', icon: '🌽', headerType: 'corn',
      yieldPerTile: 52, basePrice: 345, seedCostPerTile: 4, growDays: 2.1,
      colorYoung: '#3f7d32', colorMid: '#4f9937', colorRipe: '#d89b2b'
    },
    sunflower: {
      id: 'sunflower', name: 'Подсолнечник', icon: '🌻', headerType: 'corn',
      yieldPerTile: 26, basePrice: 740, seedCostPerTile: 4.5, growDays: 1.9,
      colorYoung: '#4a8538', colorMid: '#689e3c', colorRipe: '#f0c419'
    },
    canola: {
      id: 'canola', name: 'Рапс', icon: '🌼', headerType: 'grain',
      yieldPerTile: 27, basePrice: 670, seedCostPerTile: 4, growDays: 1.7,
      colorYoung: '#4c8c42', colorMid: '#d9d43b', colorRipe: '#b8942e'
    },
    soybean: {
      id: 'soybean', name: 'Соя', icon: '🫘', headerType: 'grain',
      yieldPerTile: 29, basePrice: 640, seedCostPerTile: 4, growDays: 1.8,
      colorYoung: '#518c48', colorMid: '#78ab52', colorRipe: '#c2a765'
    }
  },

  TIERS: {
    1: { label: 'СССР / Старт', cls: 'tier-1' },
    2: { label: 'Мидгейм',      cls: 'tier-2' },
    3: { label: 'Флагман',      cls: 'tier-3' },
    4: { label: 'Ультрафлагман', cls: 'tier-4' }
  },

  WORKER_POOL: [
    { id: 'w1', name: 'Василий Иванович', role: 'Универсал (комбайн / трактор)', hireCost: 2200, wagePerSec: 0.35, speedBonus: 1.0 },
    { id: 'w2', name: 'Петро Мельник',    role: 'Опытный комбайнёр (+10% скорость)', hireCost: 3400, wagePerSec: 0.45, speedBonus: 1.1 },
    { id: 'w3', name: 'Сергей Коваленко', role: 'Водитель-возчик / Тракторист', hireCost: 2800, wagePerSec: 0.38, speedBonus: 1.05 },
    { id: 'w4', name: 'Николай Бондарь',  role: 'Мастер вспашки и посева (+12%)', hireCost: 4200, wagePerSec: 0.50, speedBonus: 1.12 },
    { id: 'w5', name: 'Андрей Степной',   role: 'Профи-механизатор (+18% скорость)', hireCost: 6500, wagePerSec: 0.65, speedBonus: 1.18 },
    { id: 'w6', name: 'Дмитрий Таврийский', role: 'Элитный оператор флагманов (+25%)', hireCost: 9500, wagePerSec: 0.85, speedBonus: 1.25 }
  ],

  // 27 единиц реальной техники — КАЖДАЯ со своей уникальной сжатой фото-миниатюрой!
  CATALOG: [
    // ================= ТРАКТОРЫ =================
    {
      id: 't25', category: 'tractor', tier: 1,
      name: 'Т-25 «Владимирец»', brand: 'ВТЗ (СССР)',
      price: 8500, hp: 25, maxSpeed: 108, workSpeed: 74, mass: 1.0,
      fuelCap: 55, fuelBurn: 0.7,
      width: 28, length: 46, color: '#c43a2b', accent: '#2c2c2c',
      img: 'assets/shop/t25.jpg',
      desc: 'Лёгкий советский трактор для малых участков, прицепа и посева.'
    },
    {
      id: 'mtz82', category: 'tractor', tier: 1,
      name: 'МТЗ-82 «Беларус»', brand: 'МТЗ (СССР)',
      price: 22000, hp: 82, maxSpeed: 138, workSpeed: 90, mass: 1.4,
      fuelCap: 130, fuelBurn: 1.2,
      width: 32, length: 54, color: '#2b78b8', accent: '#d8e4ed',
      img: 'assets/shop/mtz82.jpg',
      desc: 'Легенда полей. Тянет плуги, сеялки, удобрения и прицепы.'
    },
    {
      id: 'k700a', category: 'tractor', tier: 2,
      name: 'К-700А «Кировец»', brand: 'ПТЗ',
      price: 68000, hp: 235, maxSpeed: 148, workSpeed: 112, mass: 2.8,
      fuelCap: 320, fuelBurn: 2.3,
      width: 42, length: 70, color: '#e0b12a', accent: '#363228',
      img: 'assets/shop/k700a.jpg',
      desc: 'Мощный шарнирный степной богатырь для широких культиваторов.'
    },
    {
      id: 'jd6155m', category: 'tractor', tier: 2,
      name: 'John Deere 6155M', brand: 'John Deere',
      price: 125000, hp: 155, maxSpeed: 175, workSpeed: 122, mass: 1.9,
      fuelCap: 270, fuelBurn: 1.6,
      width: 36, length: 58, color: '#2e8b3c', accent: '#f0c419',
      img: 'assets/shop/jd6155m.jpg',
      desc: 'Быстрый, экономичный и надёжный западный трактор для мидгейма.'
    },
    {
      id: 'fendt942', category: 'tractor', tier: 3,
      name: 'Fendt 942 Vario', brand: 'Fendt',
      price: 340000, hp: 415, maxSpeed: 215, workSpeed: 150, mass: 2.5,
      fuelCap: 620, fuelBurn: 2.6,
      width: 42, length: 66, color: '#4c9932', accent: '#d63031',
      img: 'assets/shop/fendt942.jpg',
      desc: 'Флагманский трактор с бесступенчатой трансмиссией и высокой скоростью.'
    },
    {
      id: 'jd9rx', category: 'tractor', tier: 4,
      name: 'John Deere 9RX 640', brand: 'John Deere',
      price: 780000, hp: 640, maxSpeed: 190, workSpeed: 178, mass: 3.8,
      fuelCap: 1490, fuelBurn: 4.2, tracks: true,
      width: 50, length: 80, color: '#2b8236', accent: '#f5c71a',
      img: 'assets/shop/jd9rx.jpg',
      desc: 'Ультрафлагман на 4 гусеницах. Тянет гигантские комплексы без просадки.'
    },
    {
      id: 'xerion12', category: 'tractor', tier: 4,
      name: 'Claas Xerion 12.650', brand: 'CLAAS',
      price: 890000, hp: 653, maxSpeed: 200, workSpeed: 185, mass: 3.7,
      fuelCap: 1400, fuelBurn: 4.0, tracks: true,
      width: 50, length: 82, color: '#8ac926', accent: '#e03c31',
      img: 'assets/shop/xerion12.jpg',
      desc: 'Король глубокого лейтгейма. Максимальная тяга и скорость на степных гигантах.'
    },

    // ================= КОМБАЙНЫ (ТЕПЕРЬ СО СЪЁМНЫМИ ЖАТКАМИ!) =================
    {
      id: 'sk5_niva', category: 'combine', tier: 1,
      name: 'СК-5 «Нива»', brand: 'Ростсельмаш (СССР)',
      price: 26000, hp: 120, maxSpeed: 98, workSpeed: 72, mass: 2.2,
      fuelCap: 200, fuelBurn: 1.8, capacity: 3000,
      width: 40, length: 68, color: '#c43e2b', accent: '#e5dcd0',
      img: 'assets/shop/sk5_niva.jpg',
      desc: 'Легендарный стартовый комбайн (бункер 3 000 л). Требует съёмную жатку!'
    },
    {
      id: 'don1500', category: 'combine', tier: 2,
      name: 'Дон-1500Б', brand: 'Ростсельмаш',
      price: 72000, hp: 235, maxSpeed: 114, workSpeed: 88, mass: 2.7,
      fuelCap: 380, fuelBurn: 2.5, capacity: 6000,
      width: 44, length: 76, color: '#2b7a4b', accent: '#c9412e',
      img: 'assets/shop/don1500.jpg',
      desc: 'Проверенный степной комбайн (бункер 6 000 л). Работает с зерновыми и пропашными жатками.'
    },
    {
      id: 'jds790', category: 'combine', tier: 3,
      name: 'John Deere S790', brand: 'John Deere',
      price: 395000, hp: 543, maxSpeed: 142, workSpeed: 122, mass: 3.4,
      fuelCap: 1150, fuelBurn: 4.1, capacity: 14100,
      width: 50, length: 84, color: '#2c8234', accent: '#f2c724',
      img: 'assets/shop/jds790.jpg',
      desc: 'Флагманский роторный комбайн (бункер 14 100 л). Совместим с широкими жатками.'
    },
    {
      id: 'lexion8900', category: 'combine', tier: 4,
      name: 'Claas Lexion 8900', brand: 'CLAAS',
      price: 820000, hp: 790, maxSpeed: 158, workSpeed: 148, mass: 4.0,
      fuelCap: 1150, fuelBurn: 5.0, tracks: true, capacity: 18000,
      width: 54, length: 90, color: '#90cc2b', accent: '#f2f4f0',
      img: 'assets/shop/lexion8900.jpg',
      desc: 'Ультрафлагман с бункером 18 000 л. Раскрывается с жатками Convio и Geringhoff.'
    },
    {
      id: 'nh_cr11', category: 'combine', tier: 4,
      name: 'New Holland CR11', brand: 'New Holland',
      price: 940000, hp: 775, maxSpeed: 162, workSpeed: 155, mass: 4.2,
      fuelCap: 1500, fuelBurn: 5.2, tracks: true, capacity: 20000,
      width: 56, length: 92, color: '#f0b818', accent: '#1d4c8c',
      img: 'assets/shop/nh_cr11.jpg',
      desc: 'Абсолютный монстр уборки с бункером 20 000 л!'
    },

    // ================= СЪЁМНЫЕ ЖАТКИ (ЗЕРНОВЫЕ И ПРОПАШНЫЕ) =================
    {
      id: 'header_niva', category: 'header', role: 'header', headerType: 'grain', tier: 1,
      name: 'Жатка зерновая ЖЗ-4.1', brand: 'Ростсельмаш (СССР)',
      price: 4500, reqHp: 100, workWidth: 78,
      width: 78, length: 20, color: '#c43e2b', accent: '#e5dcd0',
      img: 'assets/shop/header_niva.jpg',
      desc: 'Зерновая жатка 4.1 м: убирает Пшеницу, Ячмень, Рапс и Сою.'
    },
    {
      id: 'header_don6', category: 'header', role: 'header', headerType: 'grain', tier: 2,
      name: 'Жатка зерновая ЖУ-6 (Дон)', brand: 'Ростсельмаш',
      price: 15500, reqHp: 180, workWidth: 126,
      width: 126, length: 22, color: '#b83226', accent: '#f0ece4',
      img: 'assets/shop/header_don6.jpg',
      desc: 'Зерновая жатка 6 м для «Дон-1500Б» и средних комбайнов: Пшеница, Ячмень, Рапс, Соя.'
    },
    {
      id: 'header_convio', category: 'header', role: 'header', headerType: 'grain', tier: 4,
      name: 'Claas Convio Flex 1380', brand: 'CLAAS',
      price: 86000, reqHp: 450, workWidth: 230,
      width: 230, length: 24, color: '#2b2e2c', accent: '#90cc2b',
      img: 'assets/shop/header_convio.jpg',
      desc: 'Флагманская зерновая жатка 13.8 м: Пшеница, Ячмень, Рапс, Соя.'
    },
    {
      id: 'header_corn_sm', category: 'header', role: 'header', headerType: 'corn', tier: 2,
      name: 'Жатка пропашная КМС-6', brand: 'Бердянск / СССР',
      price: 14500, reqHp: 110, workWidth: 96,
      width: 96, length: 24, color: '#c43a2b', accent: '#f2c929',
      img: 'assets/shop/header_corn_sm.jpg',
      desc: 'Пропашная 6-рядная жатка: убирает Кукурузу и Подсолнечник!'
    },
    {
      id: 'header_corn_lg', category: 'header', role: 'header', headerType: 'corn', tier: 4,
      name: 'Geringhoff Rota Disc 1200', brand: 'Geringhoff',
      price: 94000, reqHp: 450, workWidth: 215,
      width: 215, length: 26, color: '#222222', accent: '#f0b818',
      img: 'assets/shop/header_corn_lg.jpg',
      desc: 'Гигантская 12-рядная пропашная жатка для Кукурузы и Подсолнечника.'
    },

    // ================= НАВЕСНОЕ (ПЛУГИ / СЕЯЛКИ / УДОБРЕНИЯ) =================
    {
      id: 'pln335', category: 'implement', role: 'plow', tier: 1,
      name: 'Плуг ПЛН-3-35', brand: 'СССР',
      price: 3800, reqHp: 25, workWidth: 70,
      width: 48, length: 34, color: '#b53c2e', accent: '#4a4a4a',
      img: 'assets/shop/pln335.jpg',
      desc: 'Классический 3-корпусный плуг (3.2 м). Запахивает стерню и солому.'
    },
    {
      id: 'kps4', category: 'implement', role: 'plow', tier: 1,
      name: 'Культиватор КПС-4', brand: 'СССР',
      price: 5400, reqHp: 55, workWidth: 88,
      width: 68, length: 36, color: '#2c6b9e', accent: '#c43e2b',
      img: 'assets/shop/kps4.jpg',
      desc: 'Прицепной сплошной культиватор 4 м под МТЗ-82. Быстро рыхлит стерню.'
    },
    {
      id: 'bdt7', category: 'implement', role: 'plow', tier: 2,
      name: 'Борона дисковая БДТ-7', brand: 'СССР',
      price: 18500, reqHp: 130, workWidth: 122,
      width: 92, length: 42, color: '#c84b28', accent: '#3c3f42',
      img: 'assets/shop/bdt7.jpg',
      desc: 'Тяжёлая дисковая борона 7 м для К-700А и мощных тракторов.'
    },
    {
      id: 'lemken_karat', category: 'implement', role: 'plow', tier: 2,
      name: 'Lemken Karat 9', brand: 'LEMKEN',
      price: 29000, reqHp: 140, workWidth: 134,
      width: 96, length: 42, color: '#2171b5', accent: '#d93829',
      img: 'assets/shop/cultivator.jpg',
      desc: 'Интенсивный культиватор 6 м для средних и крупных полей.'
    },
    {
      id: 'topdown700', category: 'implement', role: 'plow', tier: 3,
      name: 'Väderstad TopDown 700', brand: 'Väderstad',
      price: 68000, reqHp: 280, workWidth: 178,
      width: 124, length: 48, color: '#d42c24', accent: '#f2c929',
      img: 'assets/shop/topdown700.jpg',
      desc: 'Флагманский комбинированный культиватор 7 м с дисками, лапами и катком.'
    },
    {
      id: 'horsch_tiger', category: 'implement', role: 'plow', tier: 4,
      name: 'Horsch Tiger 8 MT', brand: 'HORSCH',
      price: 115000, reqHp: 400, workWidth: 220,
      width: 150, length: 50, color: '#cc2929', accent: '#222222',
      img: 'assets/shop/horsch_tiger.jpg',
      desc: 'Гигантский 10.5-метровый культиватор под ультрафлагманские тракторы.'
    },
    {
      id: 'sz36', category: 'implement', role: 'seeder', seederType: 'grain', tier: 1,
      name: 'Сеялка зерновая СЗ-3.6', brand: 'Красная Звезда',
      price: 4800, reqHp: 25, workWidth: 76,
      width: 56, length: 34, color: '#c43b2b', accent: '#e5b832',
      img: 'assets/shop/sz36.jpg',
      desc: 'Зерновая сеялка 3.6 м: сеет Пшеницу, Ячмень, Рапс и Сою.'
    },
    {
      id: 'vaderstad_600', category: 'implement', role: 'seeder', seederType: 'grain', tier: 2,
      name: 'Vaderstad Rapid 600S', brand: 'Väderstad',
      price: 44000, reqHp: 150, workWidth: 140,
      width: 105, length: 46, color: '#d1342a', accent: '#f2c929',
      img: 'assets/shop/seeder.jpg',
      desc: 'Скоростная зерновая сеялка 6.5 м: Пшеница, Ячмень, Рапс, Соя.'
    },
    {
      id: 'citan12001', category: 'implement', role: 'seeder', seederType: 'grain', tier: 3,
      name: 'Amazone Citan 12001-C', brand: 'AMAZONE',
      price: 124000, reqHp: 260, workWidth: 225,
      width: 158, length: 52, color: '#2b7a38', accent: '#e6781e',
      img: 'assets/shop/citan12001.jpg',
      desc: 'Широкозахватная зерновая сеялка 12 м: Пшеница, Ячмень, Рапс, Соя.'
    },
    {
      id: 'supn8', category: 'implement', role: 'seeder', seederType: 'planter', tier: 1,
      name: 'Сажалка пропашная СУПН-8', brand: 'СССР',
      price: 7400, reqHp: 65, workWidth: 96,
      width: 72, length: 36, color: '#2a6f9e', accent: '#c43e2b',
      img: 'assets/shop/supn8.jpg',
      desc: '8-рядная пневматическая сажалка: Кукуруза, Подсолнечник и Соя.'
    },
    {
      id: 'horsch_maestro', category: 'implement', role: 'seeder', seederType: 'planter', tier: 4,
      name: 'Horsch Maestro 24 SX', brand: 'HORSCH',
      price: 172000, reqHp: 350, workWidth: 235,
      width: 162, length: 54, color: '#cc2929', accent: '#f2c929',
      img: 'assets/shop/horsch_maestro.jpg',
      desc: '24-рядная пропашная сажалка точного высева: Кукуруза, Подсолнечник, Соя.'
    },
    {
      id: 'jd1775nt', category: 'implement', role: 'seeder', seederType: 'planter', tier: 4,
      name: 'John Deere 1775NT', brand: 'John Deere',
      price: 196000, reqHp: 380, workWidth: 258,
      width: 175, length: 56, color: '#2e7d32', accent: '#f5c71a',
      img: 'assets/shop/jd1775nt.jpg',
      desc: 'Флагманская 16/24-рядная сажалка John Deere: Кукуруза, Подсолнечник, Соя.'
    },
    {
      id: 'rum5', category: 'implement', role: 'spreader', tier: 1,
      name: 'Разбрасыватель РУМ-5', brand: 'СССР',
      price: 6800, reqHp: 50, workWidth: 145,
      width: 36, length: 42, color: '#2b6da3', accent: '#8e969c',
      img: 'assets/shop/rum5.jpg',
      desc: 'Прицепной разбрасыватель минеральных удобрений (захват 8 м, +50% урожая).'
    },
    {
      id: 'amazone_zats', category: 'implement', role: 'spreader', tier: 2,
      name: 'Amazone ZA-TS 4200', brand: 'AMAZONE',
      price: 24000, reqHp: 60, workWidth: 210,
      width: 40, length: 30, color: '#2f8a36', accent: '#e67e22',
      img: 'assets/shop/spreader.jpg',
      desc: 'Навесной разбрасыватель удобрений (разброс 11 м). Даёт +50% к урожаю!'
    },
    {
      id: 'amazone_ux5201', category: 'implement', role: 'spreader', tier: 3,
      name: 'Опрыскиватель Amazone UX 5201', brand: 'AMAZONE',
      price: 64000, reqHp: 160, workWidth: 275,
      width: 48, length: 54, color: '#2b7a38', accent: '#e6781e',
      img: 'assets/shop/amazone_ux5201.jpg',
      desc: 'Прицепной штанговый опрыскиватель 15 м для быстрой подкормки больших полей.'
    },
    {
      id: 'bredal_k165', category: 'implement', role: 'spreader', tier: 4,
      name: 'Разбрасыватель Bredal K165', brand: 'Bredal',
      price: 98000, reqHp: 220, workWidth: 320,
      width: 46, length: 62, color: '#c42424', accent: '#f0f0ec',
      img: 'assets/shop/bredal_k165.jpg',
      desc: 'Тандемный разбрасыватель премиум-класса (захват 18 м, +50% к урожаю).'
    },

    // ================= ПРИЦЕПЫ И ТОПЛИВОЗАПРАВЩИК =================
    {
      id: 'pts4', category: 'trailer', role: 'trailer', tier: 1,
      name: 'Прицеп 2ПТС-4', brand: 'СССР',
      price: 4200, reqHp: 25, capacity: 4500,
      width: 30, length: 52, color: '#5d7d4b', accent: '#333',
      img: 'assets/shop/pts4.jpg',
      desc: 'Надёжный советский самосвальный прицеп на 4 500 л.'
    },
    {
      id: 'fliegl_271', category: 'trailer', role: 'trailer', tier: 2,
      name: 'Fliegl ASW 271', brand: 'Fliegl',
      price: 39000, reqHp: 140, capacity: 22000,
      width: 36, length: 74, color: '#2f7a3e', accent: '#d9d9d9',
      img: 'assets/shop/trailer.jpg',
      desc: 'Вместительный тандемный прицеп на 22 000 л для средних и крупных ферм.'
    },
    {
      id: 'krampe_bandit750', category: 'trailer', role: 'trailer', tier: 3,
      name: 'Krampe Bandit 750', brand: 'Krampe',
      price: 74000, reqHp: 220, capacity: 36000,
      width: 40, length: 82, color: '#c82424', accent: '#cfd4d8',
      img: 'assets/shop/krampe_bandit750.jpg',
      desc: 'Тяжёлый немецкий тандемный зерновоз на 36 000 л.'
    },
    {
      id: 'hawe_ulw4000', category: 'trailer', role: 'trailer', tier: 4,
      name: 'Hawe ULW 4000', brand: 'HAWE',
      price: 128000, reqHp: 320, capacity: 50000,
      width: 42, length: 88, color: '#2b6e38', accent: '#f2c929',
      img: 'assets/shop/hawe_ulw4000.jpg',
      desc: 'Огромный бункер-перегрузчик на 50 000 л — идеально под Lexion 8900 и CR11.'
    },
    {
      id: 'fuel_trailer', category: 'trailer', role: 'fuel_trailer', tier: 2,
      name: 'Топливозаправщик ДТ-4000', brand: 'АгроСервис',
      price: 16500, reqHp: 50, capacity: 4000,
      width: 32, length: 56, color: '#e6b422', accent: '#454a4d',
      img: 'assets/shop/fuel_trailer.jpg',
      desc: 'Мобильная бочка на 4 000 л дизеля! Подвези к заглохшей технике в поле и заправь (📦).'
    }
  ],

  ROADS: [
    { x1: 1400, y1: 1200, x2: 1400, y2: 5800, w: 64, type: 'asphalt' },
    { x1: 1400, y1: 3500, x2: 9500, y2: 3500, w: 64, type: 'asphalt' },
    { x1: 5600, y1: 1200, x2: 5600, y2: 5800, w: 64, type: 'asphalt' },
    { x1: 1400, y1: 1200, x2: 8400, y2: 1200, w: 44, type: 'dirt' },
    { x1: 1400, y1: 5800, x2: 8400, y2: 5800, w: 44, type: 'dirt' },
    { x1: 8400, y1: 1200, x2: 8400, y2: 5800, w: 44, type: 'dirt' }
  ],

  // Дорожный граф для умной навигации ботов (строго по дорогам и мостам!)
  ROAD_NODES: [
    { id: 0, x: 1400, y: 1200 }, // Любимо-Марьевка
    { id: 1, x: 5600, y: 1200 }, // Марьяновка
    { id: 2, x: 8400, y: 1200 }, // СВ поворот
    { id: 3, x: 1400, y: 3500 }, // Дудчино
    { id: 4, x: 5600, y: 3500 }, // Тавричанка
    { id: 5, x: 8400, y: 3500 }, // Восточный перекрёсток
    { id: 6, x: 1400, y: 4650 }, // Мост Запад
    { id: 7, x: 5600, y: 4650 }, // Мост Центр
    { id: 8, x: 8400, y: 4650 }, // Мост Восток
    { id: 9, x: 1400, y: 5800 }, // Любимо-Павловка
    { id: 10, x: 5600, y: 5800 }, // Заозёрное
    { id: 11, x: 8400, y: 5800 }  // ЮВ поворот
  ],
  ROAD_EDGES: [
    [0, 1], [1, 2],
    [0, 3], [1, 4], [2, 5],
    [3, 4], [4, 5],
    [3, 6], [4, 7], [5, 8],
    [6, 9], [7, 10], [8, 11],
    [9, 10], [10, 11]
  ],

  CANAL: { y: 4650, w: 70 },
  BRIDGES: [
    { x: 1400, y: 4650, w: 80, h: 112, type: 'asphalt', name: 'Мост Любимо-Павловка' },
    { x: 5600, y: 4650, w: 80, h: 112, type: 'asphalt', name: 'Мост Тавричанка' },
    { x: 8400, y: 4650, w: 62, h: 112, type: 'dirt',    name: 'Восточный мост' }
  ],

  VILLAGES: [
    { id: 'lyubimo_pavlovka', name: 'Любимо-Павловка', x: 1020, y: 5860, box: { x: 460,  y: 5260, w: 860, h: 1180 }, rows: 3, cols: 4 },
    { id: 'dudchino',         name: 'Дудчино',         x: 980,  y: 3500, box: { x: 440,  y: 2940, w: 880, h: 1120 }, rows: 3, cols: 4 },
    { id: 'tavrichanka',      name: 'Тавричанка',      x: 5040, y: 3500, box: { x: 4440, y: 2860, w: 1060, h: 1280 }, rows: 4, cols: 5 },
    { id: 'lyubimo_marievka', name: 'Любимо-Марьевка', x: 960,  y: 1180, box: { x: 480,  y: 720,  w: 840, h: 900  }, rows: 3, cols: 3 },
    { id: 'maryanovka',       name: 'Марьяновка',      x: 5060, y: 1180, box: { x: 4540, y: 720,  w: 960, h: 900  }, rows: 3, cols: 4 },
    { id: 'zaozernoe',        name: 'Заозёрное',       x: 5060, y: 5860, box: { x: 4540, y: 5300, w: 960, h: 1060 }, rows: 3, cols: 4 }
  ],

  STATIONS: [
    { id: 'base_repair', type: 'repair',   name: 'База: Ремонт и АЗС (Любимо-Павловка)', x: 1500, y: 5900, w: 260, h: 150, village: 'Любимо-Павловка' },
    { id: 'dud_elev',    type: 'elevator', name: 'Элеватор «Дудчино»',                   x: 1520, y: 3120, w: 260, h: 160, pitX: 1650, pitY: 3325, village: 'Дудчино', priceMult: 0.99 },
    { id: 'dud_fert',    type: 'supply',   name: 'Агросклад и АЗС (Дудчино)',            x: 1520, y: 3620, w: 220, h: 130, village: 'Дудчино' },
    { id: 'tav_shop',    type: 'shop',     name: 'Дилерский центр «Тавричанка»',         x: 5720, y: 3100, w: 320, h: 180, village: 'Тавричанка' },
    { id: 'tav_elev',    type: 'elevator', name: 'Главный элеватор «Тавричанка»',        x: 6160, y: 3100, w: 300, h: 180, pitX: 6310, pitY: 3325, village: 'Тавричанка', priceMult: 1.08 },
    { id: 'tav_service', type: 'repair',   name: 'СТО и АЗС (Тавричанка)',               x: 5720, y: 3620, w: 240, h: 140, village: 'Тавричанка' },
    { id: 'mar_elev',    type: 'elevator', name: 'ХПП «Марьяновка»',                     x: 5720, y: 880,  w: 240, h: 150, pitX: 5840, pitY: 1075, village: 'Марьяновка', priceMult: 1.03 },
    { id: 'zao_fuel',    type: 'repair',   name: 'АЗС и СТО (Заозёрное)',                x: 5720, y: 5900, w: 220, h: 140, village: 'Заозёрное' }
  ],

  // Размеченные бетонные парковки выдачи техники (4 слота на базе + докупаемые слоты в Тавричанке!)
  PARKING_LOTS: {
    base: {
      name: 'Парковка базы (Любимо-Павловка)',
      x: 1470, y: 5560, w: 390, h: 210,
      bays: [
        { x: 1525, y: 5625, angle: 0 },
        { x: 1645, y: 5625, angle: 0 },
        { x: 1765, y: 5625, angle: 0 },
        { x: 1525, y: 5725, angle: 0 }
      ]
    },
    shop: {
      name: 'Парковка дилера (Тавричанка)',
      x: 5710, y: 3320, w: 380, h: 160,
      slotPrice: 12000, // цена покупки +2 слотов
      bays: [
        { x: 5765, y: 3365, angle: 0 },
        { x: 5865, y: 3365, angle: 0 },
        { x: 5965, y: 3365, angle: 0 },
        { x: 6055, y: 3365, angle: 0 },
        { x: 5765, y: 3440, angle: 0 },
        { x: 5865, y: 3440, angle: 0 },
        { x: 5965, y: 3440, angle: 0 },
        { x: 6055, y: 3440, angle: 0 }
      ]
    }
  },

  FIELDS_DEF: [
    { id: 1,  name: 'Поле №1 (Любимо-Павловка)', x: 1920, y: 4960, w: 720,  h: 640,  price: 26000,  owned: true,  initState: 'ready',  initCrop: 'wheat' },
    { id: 2,  name: 'Поле №2 (Любимо-Павловка)', x: 1920, y: 6040, w: 720,  h: 640,  price: 24000,  owned: true,  initState: 'plowed', initCrop: null },
    { id: 3,  name: 'Поле №3 (Юг Павловки)',     x: 2800, y: 4960, w: 800,  h: 640,  price: 46000,  owned: false, initState: 'stubble' },
    { id: 4,  name: 'Поле №4 (У канала)',        x: 3760, y: 4960, w: 680,  h: 640,  price: 44000,  owned: false, initState: 'stubble' },
    { id: 5,  name: 'Поле №5 (Южная степь)',     x: 2800, y: 6040, w: 840,  h: 840,  price: 68000,  owned: false, initState: 'stubble' },
    { id: 6,  name: 'Поле №6 (Заозёрное Запад)', x: 3800, y: 6040, w: 600,  h: 840,  price: 54000,  owned: false, initState: 'stubble' },
    { id: 7,  name: 'Поле №7 (Дудчино Юг)',      x: 1920, y: 3840, w: 1080, h: 640,  price: 76000,  owned: false, initState: 'stubble' },
    { id: 8,  name: 'Поле №8 (Таврийский канал)',x: 3160, y: 3840, w: 1120, h: 640,  price: 82000,  owned: false, initState: 'stubble' },
    { id: 9,  name: 'Поле №9 (Дудчино Восток)',  x: 1920, y: 2240, w: 1040, h: 760,  price: 92000,  owned: false, initState: 'stubble' },
    { id: 10, name: 'Поле №10 (Дудчино Север)',  x: 1920, y: 1400, w: 1040, h: 680,  price: 86000,  owned: false, initState: 'stubble' },
    { id: 11, name: 'Поле №11 (Центр Таврии)',   x: 3120, y: 1400, w: 1160, h: 760,  price: 118000, owned: false, initState: 'stubble' },
    { id: 12, name: 'Поле №12 (Тавричанка Запад)',x: 3120, y: 2320, w: 1160, h: 760, price: 124000, owned: false, initState: 'stubble' },
    { id: 13, name: 'Поле №13 (Дудчино Запад)',  x: 280,  y: 1840, w: 920,  h: 880,  price: 94000,  owned: false, initState: 'stubble' },
    { id: 14, name: 'Поле №14 (Любимо-Марьевка)',x: 1760, y: 280,  w: 1320, h: 720,  price: 115000, owned: false, initState: 'stubble' },
    { id: 15, name: 'Поле №15 (Марьяновка Запад)',x: 3240, y: 280, w: 1160, h: 720,  price: 110000, owned: false, initState: 'stubble' },
    { id: 16, name: 'Поле №16 (Марьяновка Север)',x: 6160, y: 280, w: 1960, h: 720,  price: 175000, owned: false, initState: 'stubble' },
    { id: 17, name: 'Поле №17 (Тавричанка Север)',x: 5960, y: 1400, w: 1080, h: 1400, price: 195000, owned: false, initState: 'stubble' },
    { id: 18, name: 'Поле №18 (Марьяновка Массив)',x: 7200, y: 1400, w: 1000, h: 1840, price: 245000, owned: false, initState: 'stubble' },
    { id: 19, name: 'Поле №19 (Восточная Степь)', x: 8640, y: 1400, w: 760,  h: 1840, price: 210000, owned: false, initState: 'stubble' },
    { id: 20, name: 'Поле №20 (Тавричанка Юг)',   x: 6160, y: 3840, w: 2040, h: 640,  price: 188000, owned: false, initState: 'stubble' },
    { id: 21, name: 'Поле №21 (Заозёрное Орошение)',x: 6120, y: 4920, w: 2080, h: 680, price: 235000, owned: false, initState: 'stubble' },
    { id: 22, name: 'Поле №22 (Заозёрное Гигант)',  x: 6120, y: 6040, w: 2120, h: 920, price: 320000, owned: false, initState: 'stubble' }
  ]
};

TF.DATA.getItem = function(id) {
  return TF.DATA.CATALOG.find(c => c.id === id);
};

TF.DATA.canSeederSow = function(seederDef, cropId) {
  if (!seederDef || seederDef.role !== 'seeder') return false;
  const crop = TF.DATA.CROPS[cropId];
  if (!crop) return false;
  if (seederDef.seederType === 'grain') {
    return cropId === 'wheat' || cropId === 'barley' || cropId === 'canola' || cropId === 'soybean';
  }
  if (seederDef.seederType === 'planter') {
    return cropId === 'corn' || cropId === 'sunflower' || cropId === 'soybean';
  }
  return true;
};

TF.DATA.getSeederAllowedCrops = function(seederDef) {
  return Object.keys(TF.DATA.CROPS).filter(cid => TF.DATA.canSeederSow(seederDef, cid));
};

// Подставляем встроенные фото из js/shop_images.js (чтобы картинки не попадали в галерею)
if (window.TF_SHOP_IMAGES) {
  for (const item of TF.DATA.CATALOG) {
    if (window.TF_SHOP_IMAGES[item.img]) item.img = window.TF_SHOP_IMAGES[item.img];
  }
}
