window.TF = window.TF || {};

TF.Radio = {
  tracks: [],
  currentIdx: 0,
  playing: false,
  volume: 0.45,
  shuffle: false,
  audio: null,

  init() {
    this.audio = new Audio();
    this.audio.preload = 'metadata';
    try {
      const savedVol = localStorage.getItem('tavria_radio_vol');
      if (savedVol !== null) this.volume = Math.max(0, Math.min(1, parseFloat(savedVol) || 0.45));
    } catch (e) {}
    this.audio.volume = this.volume;

    // Загружаем плейлист из assets/radio/playlist.js
    const baseList = Array.isArray(window.TF_RADIO_PLAYLIST) ? window.TF_RADIO_PLAYLIST : [];
    this.tracks = baseList.map(t => ({ title: t.title || t.file, src: t.file, custom: false }));

    this.audio.addEventListener('ended', () => {
      if (this.tracks.length === 0) return;
      this.next(true);
    });
    this.audio.addEventListener('error', () => {
      if (!this.playing) return;
      const cur = this.tracks[this.currentIdx];
      if (cur && TF.UI) TF.UI.toast(`Радио: не удалось открыть «${cur.title}»`);
      if (this.tracks.length > 1) this.next(true);
      else { this.playing = false; this.updateButton(); }
    });
    this.updateButton();
  },

  getCurrentTrack() {
    return this.tracks[this.currentIdx] || null;
  },

  playIndex(idx) {
    if (!this.tracks.length) {
      if (TF.UI) TF.UI.toast('В радио пока нет треков — добавь MP3!');
      return;
    }
    this.currentIdx = ((idx % this.tracks.length) + this.tracks.length) % this.tracks.length;
    const tr = this.tracks[this.currentIdx];
    this.audio.src = tr.src;
    this.audio.volume = this.volume;
    const p = this.audio.play();
    this.playing = true;
    if (p && p.catch) {
      p.catch(() => {
        this.playing = false;
        this.updateButton();
      });
    }
    this.updateButton();
    if (TF.UI && TF.UI.currentModal === 'radio') TF.UI.renderModal();
  },

  togglePlay() {
    if (!this.tracks.length) {
      if (TF.UI) TF.UI.toast('Добавь треки в assets/radio/ или кнопкой «+ Выбрать MP3»');
      return;
    }
    if (this.playing) {
      this.audio.pause();
      this.playing = false;
    } else {
      if (!this.audio.src) {
        this.playIndex(this.currentIdx);
        return;
      }
      const p = this.audio.play();
      this.playing = true;
      if (p && p.catch) p.catch(() => { this.playing = false; this.updateButton(); });
    }
    this.updateButton();
    if (TF.UI && TF.UI.currentModal === 'radio') TF.UI.renderModal();
  },

  next(auto = false) {
    if (!this.tracks.length) return;
    let nextIdx = (this.currentIdx + 1) % this.tracks.length;
    if (this.shuffle && this.tracks.length > 1) {
      do { nextIdx = Math.floor(Math.random() * this.tracks.length); } while (nextIdx === this.currentIdx);
    }
    if (this.playing || auto) this.playIndex(nextIdx);
    else {
      this.currentIdx = nextIdx;
      this.audio.src = this.tracks[this.currentIdx].src;
      if (TF.UI && TF.UI.currentModal === 'radio') TF.UI.renderModal();
    }
  },

  prev() {
    if (!this.tracks.length) return;
    const prevIdx = (this.currentIdx - 1 + this.tracks.length) % this.tracks.length;
    if (this.playing) this.playIndex(prevIdx);
    else {
      this.currentIdx = prevIdx;
      this.audio.src = this.tracks[this.currentIdx].src;
      if (TF.UI && TF.UI.currentModal === 'radio') TF.UI.renderModal();
    }
  },

  setVolume(v) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.audio) this.audio.volume = this.volume;
    try { localStorage.setItem('tavria_radio_vol', String(this.volume)); } catch (e) {}
  },

  toggleShuffle() {
    this.shuffle = !this.shuffle;
    if (TF.UI && TF.UI.currentModal === 'radio') TF.UI.renderModal();
  },

  addLocalFiles(fileList) {
    if (!fileList || !fileList.length) return;
    const firstNewIdx = this.tracks.length;
    let added = 0;
    for (const file of fileList) {
      const url = URL.createObjectURL(file);
      const cleanName = file.name.replace(/\.[^.]+$/, '');
      this.tracks.push({ title: cleanName, src: url, custom: true });
      added++;
    }
    if (added > 0) {
      if (TF.UI) TF.UI.toast(`📻 Добавлено треков: ${added}`);
      this.playIndex(firstNewIdx);
    }
  },

  removeTrack(idx) {
    if (idx < 0 || idx >= this.tracks.length) return;
    const wasCur = idx === this.currentIdx;
    this.tracks.splice(idx, 1);
    if (this.tracks.length === 0) {
      this.audio.pause();
      this.audio.src = '';
      this.playing = false;
      this.currentIdx = 0;
    } else {
      if (idx < this.currentIdx) this.currentIdx--;
      if (this.currentIdx >= this.tracks.length) this.currentIdx = 0;
      if (wasCur && this.playing) this.playIndex(this.currentIdx);
    }
    this.updateButton();
    if (TF.UI && TF.UI.currentModal === 'radio') TF.UI.renderModal();
  },

  updateButton() {
    const btn = document.getElementById('btnRadio');
    if (!btn) return;
    btn.classList.toggle('radio-on', this.playing);
    btn.title = this.playing ? `Радио играет: ${this.getCurrentTrack()?.title || ''}` : 'Радио (своя музыка)';
  }
};
