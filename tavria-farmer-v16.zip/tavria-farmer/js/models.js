// Детальные персональные 2D-модели (вид сверху) с РЕАЛИСТИЧНЫМ поворотом колёс и шарниром!
// - Т-25, МТЗ-82, JD 6155M, Fendt 942: поворачиваются ПЕРЕДНИЕ колёса
// - Все комбайны (СК-5, Дон, S790, Lexion, CR11): поворачиваются ЗАДНИЕ колёса (в противофазе!)
// - К-700А «Кировец» и John Deere 9RX 640: СКЛАДЫВАЕТСЯ ШАРНИРНАЯ РАМА по центру!
// - Claas Xerion 12.650: подруливают ВСЕ 4 ГУСЕНИЦЫ в противофазе!
window.TF = window.TF || {};

TF.VehicleModels = {
  // Уникальная текстура зерна в прицепе и бункере для КАЖДОЙ из 6 культур!
  drawCropCargo(ctx, x, y, w, h, cropId) {
    const c = cropId || 'wheat';
    if (c === 'sunflower') {
      // Подсолнечник: тёмно-угольные семечки со светлыми полосками!
      ctx.fillStyle = '#1e1f22'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#757a82';
      for (let py = y + 3; py < y + h - 2; py += 6) {
        for (let px = x + 3; px < x + w - 2; px += 6) {
          ctx.fillRect(px + ((py * 7) % 3), py, 3, 2);
        }
      }
    } else if (c === 'corn') {
      // Кукуруза: насыщенно-оранжевая база + крупные ярко-жёлтые зёрна!
      ctx.fillStyle = '#c97a16'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#ffd43b';
      for (let py = y + 3; py < y + h - 3; py += 7) {
        for (let px = x + 3; px < x + w - 3; px += 7) {
          ctx.beginPath(); ctx.arc(px + ((py * 5) % 3), py, 2.3, 0, Math.PI * 2); ctx.fill();
        }
      }
    } else if (c === 'canola') {
      // Рапс: мелкие глянцевые чёрно-бурые горошины!
      ctx.fillStyle = '#2b241d'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#5e4c36';
      for (let py = y + 2; py < y + h - 2; py += 5) {
        for (let px = x + 2; px < x + w - 2; px += 5) {
          ctx.fillRect(px, py, 2, 2);
        }
      }
    } else if (c === 'soybean') {
      // Соя: кремово-бежевые округлые бобы!
      ctx.fillStyle = '#bda575'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#e6d5ab';
      for (let py = y + 3; py < y + h - 2; py += 6) {
        for (let px = x + 3; px < x + w - 2; px += 6) {
          ctx.beginPath(); ctx.arc(px, py, 2, 0, Math.PI * 2); ctx.fill();
        }
      }
    } else if (c === 'barley') {
      // Ячмень: светло-песочные вытянутые зёрна!
      ctx.fillStyle = '#c7ac63'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#ebd99e';
      for (let py = y + 3; py < y + h - 2; py += 5) {
        for (let px = x + 2; px < x + w - 3; px += 8) {
          ctx.fillRect(px + (py % 3), py, 4, 1.8);
        }
      }
    } else {
      // Пшеница: тёплое золотистое зерно с янтарными вкраплениями!
      ctx.fillStyle = '#d9ab38'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#f7d974';
      for (let py = y + 2; py < y + h - 2; py += 5) {
        for (let px = x + 2; px < x + w - 2; px += 6) {
          ctx.fillRect(px + ((py * 3) % 3), py, 2.5, 2);
        }
      }
    }
  },

  drawWheel(ctx, x, y, w, h, rimColor, steerRad = 0) {
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    if (steerRad) ctx.rotate(steerRad);
    ctx.fillStyle = '#181b1a';
    ctx.beginPath(); ctx.roundRect(-w / 2, -h / 2, w, h, 2); ctx.fill();
    ctx.fillStyle = '#2d3230';
    for (let sx = -w / 2 + 2; sx < w / 2 - 2; sx += 4) ctx.fillRect(sx, -h / 2 + 1, 2, h - 2);
    if (rimColor) {
      ctx.fillStyle = rimColor;
      ctx.fillRect(-w * 0.25, -h * 0.2, w * 0.5, h * 0.4);
    }
    ctx.restore();
  },

  drawTrack(ctx, x, y, w, h, hubColor, steerRad = 0) {
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    if (steerRad) ctx.rotate(steerRad);
    ctx.fillStyle = '#171918';
    ctx.beginPath(); ctx.roundRect(-w / 2, -h / 2, w, h, 3); ctx.fill();
    ctx.strokeStyle = '#333836'; ctx.lineWidth = 1.2;
    for (let sx = -w / 2 + 3; sx < w / 2 - 2; sx += 5) {
      ctx.beginPath(); ctx.moveTo(sx, -h / 2 + 1); ctx.lineTo(sx, h / 2 - 1); ctx.stroke();
    }
    if (hubColor) {
      ctx.fillStyle = hubColor;
      ctx.fillRect(-w * 0.15, -h * 0.25, w * 0.3, h * 0.5);
    }
    ctx.restore();
  },

  drawTailLights(ctx, v, L, W, isNight) {
    if (isNight || v.braking || v.reversing) {
      ctx.fillStyle = v.braking ? '#ff2424' : 'rgba(255, 50, 50, 0.88)';
      ctx.fillRect(-L * 0.49, -W * 0.34, 4, 6);
      ctx.fillRect(-L * 0.49,  W * 0.34 - 6, 4, 6);
    }
    if (v.reversing) {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-L * 0.50, -W * 0.15, 4, 5);
      ctx.fillRect(-L * 0.50,  W * 0.15 - 5, 4, 5);
    }
  },

  drawTractor(ctx, def, v, L, W, isNight) {
    const id = def.id;
    const hl = isNight ? '#ffffff' : '#fff4b0';
    const st = (v.steerAngle || 0);

    if (id === 't25') {
      // Передний поворот колёс
      this.drawWheel(ctx, -L * 0.44, -W * 0.58, 17, 7, '#a83226', 0);
      this.drawWheel(ctx, -L * 0.44,  W * 0.58 - 7, 17, 7, '#a83226', 0);
      this.drawWheel(ctx,  L * 0.18, -W * 0.48, 11, 5, '#a83226', st * 0.55);
      this.drawWheel(ctx,  L * 0.18,  W * 0.48 - 5, 11, 5, '#a83226', st * 0.55);
      ctx.fillStyle = '#9e2b1f';
      ctx.fillRect(-L * 0.42, -W * 0.44, 16, 4); ctx.fillRect(-L * 0.42, W * 0.40, 16, 4);
      ctx.fillStyle = '#c93c2b';
      ctx.beginPath(); ctx.roundRect(-L * 0.1, -W * 0.24, L * 0.54, W * 0.48, 3); ctx.fill();
      ctx.fillStyle = '#333638'; ctx.fillRect(-L * 0.38, -W * 0.26, L * 0.30, W * 0.52);
      ctx.fillStyle = '#5a3a26'; ctx.fillRect(-L * 0.34, -5, 8, 10);
      ctx.strokeStyle = '#111'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(-L * 0.16, 0, 4, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#252525'; ctx.fillRect(L * 0.08, -W * 0.32, 4, 4);
      ctx.fillStyle = hl; ctx.fillRect(L * 0.38, -W * 0.32, 3, 4); ctx.fillRect(L * 0.38, W * 0.28, 3, 4);
    }

    else if (id === 'mtz82') {
      this.drawWheel(ctx, -L * 0.45, -W * 0.58, 20, 8, '#2b78b8', 0);
      this.drawWheel(ctx, -L * 0.45,  W * 0.58 - 8, 20, 8, '#2b78b8', 0);
      this.drawWheel(ctx,  L * 0.16, -W * 0.52, 13, 6, '#9c3b2e', st * 0.52);
      this.drawWheel(ctx,  L * 0.16,  W * 0.52 - 6, 13, 6, '#9c3b2e', st * 0.52);
      ctx.fillStyle = '#2474b5'; ctx.fillRect(-L * 0.05, -W * 0.26, L * 0.50, W * 0.52);
      ctx.fillStyle = '#184e7a'; ctx.fillRect(L * 0.28, -W * 0.20, 10, W * 0.40);
      ctx.fillStyle = '#1f2d36'; ctx.fillRect(-L * 0.38, -W * 0.36, L * 0.36, W * 0.72);
      ctx.fillStyle = '#e5ecef'; ctx.fillRect(-L * 0.34, -W * 0.30, L * 0.28, W * 0.60);
      ctx.fillStyle = '#1e1e1e'; ctx.beginPath(); ctx.arc(L * 0.05, -W * 0.28, 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hl; ctx.fillRect(L * 0.42, -W * 0.26, 3, 5); ctx.fillRect(L * 0.42, W * 0.21, 3, 5);
    }

    else if (id === 'k700a') {
      // К-700А «Кировец»: ШАРНИРНО-СОЧЛЕНЁННАЯ РАМА (передняя полурама складывается в шарнире!)
      // Задняя полурама
      this.drawWheel(ctx, -L * 0.46, -W * 0.58, 24, 11, '#c99c1e', 0);
      this.drawWheel(ctx, -L * 0.46,  W * 0.58 - 11, 24, 11, '#c99c1e', 0);
      ctx.fillStyle = '#d4a322'; ctx.fillRect(-L * 0.46, -W * 0.34, L * 0.44, W * 0.68);
      // Центральный шарнир
      ctx.fillStyle = '#2d2b26'; ctx.beginPath(); ctx.arc(0, 0, 9, 0, Math.PI * 2); ctx.fill();

      // Передняя полурама поворачивается вокруг шарнира (0,0)!
      ctx.save();
      ctx.rotate(st * 0.28);
      this.drawWheel(ctx, L * 0.12, -W * 0.58, 24, 11, '#c99c1e', 0);
      this.drawWheel(ctx, L * 0.12,  W * 0.58 - 11, 24, 11, '#c99c1e', 0);
      ctx.fillStyle = '#e3b42b'; ctx.fillRect(L * 0.02, -W * 0.38, L * 0.46, W * 0.76);
      ctx.fillStyle = '#403b2c'; ctx.fillRect(L * 0.43, -W * 0.30, 5, W * 0.60);
      ctx.fillStyle = '#222d33'; ctx.fillRect(-L * 0.06, -W * 0.34, L * 0.22, W * 0.68);
      ctx.fillStyle = '#e8bd3a'; ctx.fillRect(-L * 0.03, -W * 0.28, L * 0.16, W * 0.56);
      ctx.fillStyle = '#2b241d';
      ctx.beginPath(); ctx.arc(L * 0.18, -W * 0.26, 3.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(L * 0.18,  W * 0.26, 3.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hl; ctx.fillRect(L * 0.45, -W * 0.28, 3, 5); ctx.fillRect(L * 0.45, W * 0.23, 3, 5);
      ctx.restore();
    }

    else if (id === 'jd6155m') {
      this.drawWheel(ctx, -L * 0.44, -W * 0.58, 22, 9, '#f2c71a', 0);
      this.drawWheel(ctx, -L * 0.44,  W * 0.58 - 9, 22, 9, '#f2c71a', 0);
      this.drawWheel(ctx,  L * 0.12, -W * 0.54, 16, 7, '#f2c71a', st * 0.52);
      this.drawWheel(ctx,  L * 0.12,  W * 0.54 - 7, 16, 7, '#f2c71a', st * 0.52);
      ctx.fillStyle = '#216b2c'; ctx.fillRect(L * 0.44, -W * 0.24, 6, W * 0.48);
      ctx.fillStyle = '#2b8738'; ctx.beginPath(); ctx.roundRect(-L * 0.06, -W * 0.29, L * 0.52, W * 0.58, 5); ctx.fill();
      ctx.fillStyle = '#f2c71a'; ctx.fillRect(L * 0.02, -W * 0.29, L * 0.36, 3); ctx.fillRect(L * 0.02, W * 0.26, L * 0.36, 3);
      ctx.fillStyle = '#1b2c36'; ctx.fillRect(-L * 0.38, -W * 0.36, L * 0.36, W * 0.72);
      ctx.fillStyle = '#2b8738'; ctx.beginPath(); ctx.roundRect(-L * 0.34, -W * 0.29, L * 0.28, W * 0.58, 4); ctx.fill();
      ctx.fillStyle = hl; ctx.fillRect(L * 0.43, -W * 0.22, 3, 5); ctx.fillRect(L * 0.43, W * 0.17, 3, 5);
    }

    else if (id === 'fendt942') {
      this.drawWheel(ctx, -L * 0.45, -W * 0.58, 25, 10, '#d92b2b', 0);
      this.drawWheel(ctx, -L * 0.45,  W * 0.58 - 10, 25, 10, '#d92b2b', 0);
      this.drawWheel(ctx,  L * 0.12, -W * 0.55, 19, 8, '#d92b2b', st * 0.50);
      this.drawWheel(ctx,  L * 0.12,  W * 0.55 - 8, 19, 8, '#d92b2b', st * 0.50);
      ctx.fillStyle = '#4da132';
      ctx.beginPath();
      ctx.moveTo(-L * 0.04, -W * 0.32); ctx.lineTo(L * 0.46, -W * 0.24);
      ctx.lineTo(L * 0.48,  W * 0.24); ctx.lineTo(-L * 0.04,  W * 0.32);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#2b2e30'; ctx.fillRect(L * 0.30, -W * 0.18, 12, W * 0.36);
      ctx.fillStyle = '#1d2b33'; ctx.fillRect(-L * 0.38, -W * 0.38, L * 0.36, W * 0.76);
      ctx.fillStyle = '#eef2f0'; ctx.beginPath(); ctx.roundRect(-L * 0.34, -W * 0.31, L * 0.28, W * 0.62, 5); ctx.fill();
      ctx.fillStyle = hl; ctx.fillRect(L * 0.44, -W * 0.20, 4, 5); ctx.fillRect(L * 0.44, W * 0.15, 4, 5);
    }

    else if (id === 'jd9rx') {
      // John Deere 9RX 640: ШАРНИРНО-СОЧЛЕНЁННЫЙ 4-ГУСЕНИЧНЫЙ МОНСТР (передняя секция ломается в шарнире!)
      this.drawTrack(ctx, -L * 0.46, -W * 0.58, 30, 12, '#f5c71a', 0);
      this.drawTrack(ctx, -L * 0.46,  W * 0.58 - 12, 30, 12, '#f5c71a', 0);
      ctx.fillStyle = '#232924'; ctx.fillRect(-L * 0.46, -W * 0.34, L * 0.42, W * 0.68);
      ctx.fillStyle = '#182830'; ctx.fillRect(-L * 0.26, -W * 0.36, L * 0.30, W * 0.72);
      ctx.fillStyle = '#298a38'; ctx.beginPath(); ctx.roundRect(-L * 0.22, -W * 0.29, L * 0.22, W * 0.58, 4); ctx.fill();
      ctx.fillStyle = '#f5c71a'; ctx.beginPath(); ctx.arc(-L * 0.05, 0, 4, 0, Math.PI * 2); ctx.fill();

      // Передняя шарнирная секция с 2 передними гусеницами
      ctx.save();
      ctx.translate(L * 0.04, 0);
      ctx.rotate(st * 0.26);
      this.drawTrack(ctx, L * 0.04, -W * 0.58, 30, 12, '#f5c71a', 0);
      this.drawTrack(ctx, L * 0.04,  W * 0.58 - 12, 30, 12, '#f5c71a', 0);
      ctx.fillStyle = '#257d32'; ctx.beginPath(); ctx.roundRect(-L * 0.02, -W * 0.34, L * 0.46, W * 0.68, 5); ctx.fill();
      ctx.fillStyle = '#f5c71a'; ctx.fillRect(L * 0.02, -W * 0.34, L * 0.36, 3.5); ctx.fillRect(L * 0.02, W * 0.305, L * 0.36, 3.5);
      ctx.fillStyle = hl; ctx.fillRect(L * 0.41, -W * 0.26, 4, 6); ctx.fillRect(L * 0.41, W * 0.20, 4, 6);
      ctx.restore();
    }

    else {
      // Claas Xerion 12.650: ЖЁСТКАЯ РАМА, НО ПОДРУЛИВАЮТ ВСЕ 4 ГУСЕНИЦЫ В ПРОТИВОФАЗЕ (+перед, -зад)!
      this.drawTrack(ctx, -L * 0.46, -W * 0.58, 31, 12, '#d93829', -st * 0.32);
      this.drawTrack(ctx, -L * 0.46,  W * 0.58 - 12, 31, 12, '#d93829', -st * 0.32);
      this.drawTrack(ctx,  L * 0.08, -W * 0.58, 31, 12, '#d93829',  st * 0.32);
      this.drawTrack(ctx,  L * 0.08,  W * 0.58 - 12, 31, 12, '#d93829',  st * 0.32);
      ctx.fillStyle = '#4e5452'; ctx.fillRect(L * 0.44, -W * 0.32, 7, W * 0.64);
      ctx.fillStyle = '#8ac926'; ctx.beginPath(); ctx.roundRect(-L * 0.44, -W * 0.34, L * 0.88, W * 0.68, 5); ctx.fill();
      ctx.fillStyle = '#242726'; ctx.fillRect(L * 0.14, -W * 0.18, L * 0.28, W * 0.36);
      ctx.fillStyle = '#1b2830'; ctx.fillRect(-L * 0.22, -W * 0.36, L * 0.34, W * 0.72);
      ctx.fillStyle = '#f2f5f3'; ctx.beginPath(); ctx.roundRect(-L * 0.18, -W * 0.29, L * 0.26, W * 0.58, 4); ctx.fill();
      ctx.fillStyle = '#d93829'; ctx.fillRect(-L * 0.12, -W * 0.34, 14, 3);
      ctx.fillStyle = hl; ctx.fillRect(L * 0.42, -W * 0.24, 4, 6); ctx.fillRect(L * 0.42, W * 0.18, 4, 6);
    }

    this.drawTailLights(ctx, v, L, W, isNight);
  },

  drawCombineBody(ctx, def, v, L, W, isNight) {
    const id = def.id;
    const hl = isNight ? '#ffffff' : '#fff4b0';
    const st = (v.steerAngle || 0);

    // У всех комбайнов передние ведущие стоят прямо, а ЗАДНИЕ УПРАВЛЯЕМЫЕ колёса поворачиваются в противофазе (-st * 0.62)!
    if (def.tracks) {
      this.drawTrack(ctx, L * 0.02, -W * 0.58, 28, 11, id === 'lexion8900' ? '#d93829' : '#1d4c8c', 0);
      this.drawTrack(ctx, L * 0.02,  W * 0.58 - 11, 28, 11, id === 'lexion8900' ? '#d93829' : '#1d4c8c', 0);
    } else {
      this.drawWheel(ctx, L * 0.04, -W * 0.58, 22, 10, def.accent, 0);
      this.drawWheel(ctx, L * 0.04,  W * 0.58 - 10, 22, 10, def.accent, 0);
    }
    this.drawWheel(ctx, -L * 0.42, -W * 0.50, 15, 7, def.accent, -st * 0.62);
    this.drawWheel(ctx, -L * 0.42,  W * 0.50 - 7, 15, 7, def.accent, -st * 0.62);

    ctx.fillStyle = '#2d3230'; ctx.fillRect(L * 0.42, -W * 0.22, 11, W * 0.44);

    if (id === 'sk5_niva') {
      ctx.fillStyle = '#c43b29'; ctx.fillRect(-L * 0.48, -W * 0.40, L * 0.92, W * 0.80);
      if (v.cargo > 0) this.drawCropCargo(ctx, -L * 0.14, -W * 0.30, L * 0.34, W * 0.60, v.cargoCrop); else { ctx.fillStyle = '#3a2a24'; ctx.fillRect(-L * 0.14, -W * 0.30, L * 0.34, W * 0.60); }
      ctx.fillStyle = '#1e2c33'; ctx.fillRect(L * 0.16, -W * 0.34, L * 0.24, W * 0.44);
      ctx.fillStyle = '#e5dcd0'; ctx.fillRect(L * 0.19, -W * 0.30, L * 0.18, W * 0.36);
      ctx.fillStyle = '#a83022'; ctx.fillRect(-L * 0.06, -W * 0.44 - 14, 7, 18);
    } else if (id === 'don1500') {
      ctx.fillStyle = '#2a7848'; ctx.fillRect(-L * 0.48, -W * 0.42, L * 0.94, W * 0.84);
      ctx.fillStyle = '#c9412e'; ctx.fillRect(-L * 0.46, -W * 0.42, L * 0.36, 4); ctx.fillRect(-L * 0.46, W * 0.38, L * 0.36, 4);
      ctx.fillStyle = v.cargo > 0 ? '#e8c451' : '#25382c'; ctx.fillRect(-L * 0.24, -W * 0.32, L * 0.42, W * 0.64);
      ctx.fillStyle = '#1e2c33'; ctx.fillRect(L * 0.18, -W * 0.30, L * 0.24, W * 0.60);
      ctx.fillStyle = '#e5c65c'; ctx.fillRect(L * 0.21, -W * 0.25, L * 0.18, W * 0.50);
      ctx.fillStyle = '#24663d'; ctx.fillRect(-L * 0.12, -W * 0.44 - 16, 8, 20);
    } else if (id === 'jds790') {
      ctx.fillStyle = '#277d30'; ctx.beginPath(); ctx.roundRect(-L * 0.48, -W * 0.42, L * 0.94, W * 0.84, 5); ctx.fill();
      ctx.fillStyle = '#f2c724'; ctx.fillRect(-L * 0.42, -W * 0.42, L * 0.72, 4); ctx.fillRect(-L * 0.42, W * 0.38, L * 0.72, 4);
      ctx.fillStyle = v.cargo > 0 ? '#e8c451' : '#1f3622'; ctx.fillRect(-L * 0.26, -W * 0.34, L * 0.44, W * 0.68);
      ctx.fillStyle = '#1a2930'; ctx.fillRect(L * 0.18, -W * 0.30, L * 0.24, W * 0.60);
      ctx.fillStyle = '#277d30'; ctx.fillRect(L * 0.22, -W * 0.24, L * 0.16, W * 0.48);
      ctx.fillStyle = '#277d30'; ctx.fillRect(-L * 0.14, -W * 0.44 - 20, 8, 24);
    } else if (id === 'lexion8900') {
      ctx.fillStyle = '#8cc928'; ctx.beginPath(); ctx.roundRect(-L * 0.48, -W * 0.43, L * 0.94, W * 0.86, 6); ctx.fill();
      ctx.fillStyle = '#eff2ed'; ctx.fillRect(-L * 0.18, -W * 0.42, L * 0.58, W * 0.84);
      ctx.fillStyle = '#d93829'; ctx.fillRect(-L * 0.10, -W * 0.43, 24, 4); ctx.fillRect(-L * 0.10, W * 0.39, 24, 4);
      if (v.cargo > 0) this.drawCropCargo(ctx, -L * 0.26, -W * 0.34, L * 0.44, W * 0.68, v.cargoCrop); else { ctx.fillStyle = '#2d332f'; ctx.fillRect(-L * 0.26, -W * 0.34, L * 0.44, W * 0.68); }
      ctx.fillStyle = '#19262e'; ctx.fillRect(L * 0.18, -W * 0.31, L * 0.24, W * 0.62);
      ctx.fillStyle = '#eff2ed'; ctx.fillRect(L * 0.22, -W * 0.24, L * 0.16, W * 0.48);
      ctx.fillStyle = '#8cc928'; ctx.fillRect(-L * 0.16, -W * 0.45 - 24, 8, 28);
    } else {
      ctx.fillStyle = '#f2b818'; ctx.beginPath(); ctx.roundRect(-L * 0.48, -W * 0.44, L * 0.94, W * 0.88, 6); ctx.fill();
      ctx.fillStyle = '#18427d'; ctx.fillRect(-L * 0.36, -W * 0.44, L * 0.56, 5); ctx.fillRect(-L * 0.36, W * 0.39, L * 0.56, 5);
      if (v.cargo > 0) this.drawCropCargo(ctx, -L * 0.26, -W * 0.35, L * 0.44, W * 0.70, v.cargoCrop); else { ctx.fillStyle = '#302b1c'; ctx.fillRect(-L * 0.26, -W * 0.35, L * 0.44, W * 0.70); }
      ctx.fillStyle = '#18252e'; ctx.fillRect(L * 0.18, -W * 0.32, L * 0.24, W * 0.64);
      ctx.fillStyle = '#f2b818'; ctx.fillRect(L * 0.22, -W * 0.25, L * 0.16, W * 0.50);
      ctx.fillStyle = '#363b40'; ctx.fillRect(-L * 0.16, -W * 0.46 - 26, 9, 30);
    }

    ctx.fillStyle = hl; ctx.fillRect(L * 0.38, -W * 0.26, 4, 5); ctx.fillRect(L * 0.38, W * 0.21, 4, 5);
    this.drawTailLights(ctx, v, L, W, isNight);
  },

  drawHeader(ctx, def, v) {
    const hw = def.workWidth;
    const t = Date.now() * 0.014;
    if (def.headerType === 'corn') {
      ctx.fillStyle = def.color; ctx.fillRect(-10, -hw / 2, 16, hw);
      ctx.fillStyle = '#222'; ctx.fillRect(-4, -hw / 2 + 4, 5, hw - 8);
      const rows = def.id === 'header_corn_lg' ? 12 : 6, step = hw / rows;
      for (let i = 0; i < rows; i++) {
        const ry = -hw / 2 + (i + 0.5) * step;
        ctx.fillStyle = def.accent;
        ctx.beginPath(); ctx.moveTo(6, ry - step * 0.34); ctx.lineTo(24, ry); ctx.lineTo(6, ry + step * 0.34); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#1c1c1c'; ctx.lineWidth = 1; ctx.stroke();
        if (v.working) {
          const pulse = (Math.sin(t + i) * 0.5 + 0.5) * 10;
          ctx.fillStyle = '#ffe07d';
          ctx.fillRect(8 + pulse, ry - 1.5, 4, 3);
        }
      }
    } else {
      ctx.fillStyle = def.color; ctx.fillRect(-10, -hw / 2, 18, hw);
      ctx.strokeStyle = v.working ? '#ffe07d' : def.accent; ctx.lineWidth = v.working ? 2.5 : 2; ctx.strokeRect(-10, -hw / 2, 18, hw);
      ctx.fillStyle = def.accent; ctx.fillRect(6, -hw / 2 - 2, 12, 4); ctx.fillRect(6, hw / 2 - 2, 12, 4);
      // Вращающееся мотовило при кошении
      const reelOff = v.working ? Math.sin(t) * 3.5 : 0;
      ctx.strokeStyle = def.id === 'header_convio' ? '#d93829' : '#181a19'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(3 + reelOff, -hw / 2 + 4); ctx.lineTo(3 + reelOff, hw / 2 - 4); ctx.stroke();
      if (v.working) {
        ctx.strokeStyle = 'rgba(255, 238, 175, 0.72)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(6 - reelOff * 0.7, -hw / 2 + 5); ctx.lineTo(6 - reelOff * 0.7, hw / 2 - 5); ctx.stroke();
      }
    }
  },

  drawTrailer(ctx, def, v, L, W) {
    ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(L * 0.44, 0); ctx.lineTo(L * 0.68, 0); ctx.stroke();
    if (def.role === 'fuel_trailer') {
      this.drawWheel(ctx, -L * 0.16, -W * 0.56, 14, 6); this.drawWheel(ctx, -L * 0.16, W * 0.56 - 6, 14, 6);
      ctx.fillStyle = '#484d50'; ctx.fillRect(-L * 0.44, -W * 0.42, L * 0.88, W * 0.84);
      ctx.fillStyle = '#e8b824'; ctx.beginPath(); ctx.roundRect(-L * 0.36, -W * 0.38, L * 0.64, W * 0.76, 10); ctx.fill();
      ctx.strokeStyle = '#333'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#d93829'; ctx.fillRect(-4, -5, 10, 10);
      ctx.fillStyle = '#2b2f33'; ctx.fillRect(L * 0.28, -W * 0.34, 9, W * 0.68);
      return;
    }
    if (def.id === 'pts4') {
      this.drawWheel(ctx, -L * 0.36, -W * 0.54, 12, 5); this.drawWheel(ctx, -L * 0.36, W * 0.54 - 5, 12, 5);
      this.drawWheel(ctx,  L * 0.16, -W * 0.54, 12, 5); this.drawWheel(ctx,  L * 0.16, W * 0.54 - 5, 12, 5);
      ctx.fillStyle = '#567844'; ctx.fillRect(-L * 0.46, -W * 0.45, L * 0.92, W * 0.90);
      ctx.strokeStyle = '#2c3d23'; ctx.lineWidth = 2; ctx.strokeRect(-L * 0.46, -W * 0.45, L * 0.92, W * 0.90);
    } else if (def.id === 'fliegl_271') {
      this.drawWheel(ctx, -L * 0.34, -W * 0.55, 14, 6); this.drawWheel(ctx, -L * 0.34, W * 0.55 - 6, 14, 6);
      this.drawWheel(ctx, -L * 0.08, -W * 0.55, 14, 6); this.drawWheel(ctx, -L * 0.08, W * 0.55 - 6, 14, 6);
      ctx.fillStyle = '#2b7a3b'; ctx.fillRect(-L * 0.46, -W * 0.46, L * 0.92, W * 0.92);
      ctx.strokeStyle = '#d9dedc'; ctx.lineWidth = 2; ctx.strokeRect(-L * 0.46, -W * 0.46, L * 0.92, W * 0.92);
      ctx.fillStyle = '#1f2321'; ctx.fillRect(-L * 0.44, -W * 0.46, L * 0.88, 5);
    } else if (def.id === 'krampe_bandit750') {
      for (const ox of [-0.34, -0.06]) { this.drawWheel(ctx, L * ox, -W * 0.56, 15, 7); this.drawWheel(ctx, L * ox, W * 0.56 - 7, 15, 7); }
      ctx.fillStyle = '#c82424'; ctx.fillRect(-L * 0.47, -W * 0.46, L * 0.94, W * 0.92);
      ctx.strokeStyle = '#d5dade'; ctx.lineWidth = 2.5; ctx.strokeRect(-L * 0.47, -W * 0.46, L * 0.94, W * 0.92);
      ctx.fillStyle = '#921818'; ctx.fillRect(-L * 0.44, -W * 0.44, L * 0.88, 5);
      ctx.fillStyle = '#cfd4d8'; ctx.fillRect(L * 0.28, -W * 0.44, 8, W * 0.88);
    } else {
      for (const ox of [-0.36, -0.14, 0.08]) { this.drawWheel(ctx, L * ox, -W * 0.56, 14, 7); this.drawWheel(ctx, L * ox, W * 0.56 - 7, 14, 7); }
      ctx.fillStyle = '#266b34'; ctx.fillRect(-L * 0.47, -W * 0.46, L * 0.94, W * 0.92);
      ctx.strokeStyle = '#f2c929'; ctx.lineWidth = 3; ctx.strokeRect(-L * 0.47, -W * 0.46, L * 0.94, W * 0.92);
      ctx.fillStyle = '#1c4d26'; ctx.fillRect(L * 0.28, -W * 0.44, 10, 26);
    }
    if (v.cargo > 0) {
      const pct = Math.max(0.16, v.cargo / def.capacity);
      this.drawCropCargo(ctx, -L * 0.40, -W * 0.36, L * 0.80 * pct, W * 0.72, v.cargoCrop);
    }
  },

  drawImplement(ctx, def, v, L, W) {
    const ww = def.workWidth;
    ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(L * 0.7, 0); ctx.stroke();
    if (def.id === 'pln335') {
      ctx.strokeStyle = '#b53c2e'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.moveTo(10, -ww * 0.35); ctx.lineTo(-14, ww * 0.38); ctx.stroke();
      ctx.fillStyle = '#6d757a';
      for (let i = -1; i <= 1; i++) ctx.fillRect(-2 - i * 8, i * (ww * 0.25) - 4, 12, 8);
    } else if (def.id === 'kps4') {
      ctx.fillStyle = '#2c6b9e'; ctx.fillRect(-10, -ww / 2, 16, ww);
      ctx.strokeStyle = v.working ? '#ffe07d' : '#c43e2b'; ctx.lineWidth = 2; ctx.strokeRect(-10, -ww / 2, 16, ww);
      this.drawWheel(ctx, 2, -ww * 0.32, 10, 4); this.drawWheel(ctx, 2, ww * 0.32 - 4, 10, 4);
      ctx.fillStyle = '#4e5459';
      for (let y = -ww * 0.42; y <= ww * 0.42; y += 11) ctx.fillRect(-14, y - 2, 6, 4);
    } else if (def.id === 'bdt7') {
      ctx.strokeStyle = '#c84b28'; ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(8, -ww * 0.46); ctx.lineTo(-2, 0); ctx.lineTo(8, ww * 0.46);
      ctx.moveTo(-12, -ww * 0.46); ctx.lineTo(-4, 0); ctx.lineTo(-12, ww * 0.46);
      ctx.stroke();
      ctx.fillStyle = '#52585e';
      for (let y = -ww * 0.44; y <= ww * 0.44; y += 10) {
        ctx.fillRect(1, y - 1.5, 5, 3);
        ctx.fillRect(-14, y - 1.5, 5, 3);
      }
      this.drawWheel(ctx, -4, -ww * 0.22, 12, 5); this.drawWheel(ctx, -4, ww * 0.22 - 5, 12, 5);
    } else if (def.id === 'topdown700') {
      ctx.fillStyle = '#d42c24'; ctx.fillRect(-12, -ww / 2, 22, ww);
      ctx.fillStyle = '#f2c929'; ctx.fillRect(-20, -ww / 2 + 4, 6, ww - 8);
      ctx.strokeStyle = v.working ? '#ffe07d' : '#222'; ctx.lineWidth = 2; ctx.strokeRect(-12, -ww / 2, 22, ww);
      this.drawWheel(ctx, 0, -ww * 0.16, 13, 6); this.drawWheel(ctx, 0, ww * 0.16 - 6, 13, 6);
    } else if (def.id === 'lemken_karat' || def.id === 'horsch_tiger') {
      ctx.fillStyle = def.color; ctx.fillRect(-10, -ww / 2, 16, ww);
      ctx.fillStyle = '#303436'; ctx.fillRect(-18, -ww / 2 + 4, 6, ww - 8);
      ctx.strokeStyle = v.working ? '#ffe07d' : def.accent; ctx.lineWidth = 2; ctx.strokeRect(-10, -ww / 2, 16, ww);
    } else if (def.role === 'seeder' && def.seederType === 'planter') {
      // Пропашная сажалка — отдельные секции и высевающие бачки
      ctx.fillStyle = def.color; ctx.fillRect(-8, -ww / 2, 10, ww);
      const count = Math.max(6, Math.round(ww / 16));
      for (let i = 0; i < count; i++) {
        const sy = -ww * 0.46 + (i / (count - 1)) * (ww * 0.92);
        ctx.fillStyle = def.accent;
        ctx.fillRect(-16, sy - 3, 10, 6);
      }
      ctx.fillStyle = def.color;
      ctx.beginPath(); ctx.roundRect(0, -Math.min(ww * 0.22, 22), 16, Math.min(ww * 0.44, 44), 4); ctx.fill();
      ctx.strokeStyle = v.working ? '#ffe07d' : '#222'; ctx.lineWidth = 2; ctx.stroke();
    } else if (def.role === 'seeder') {
      ctx.fillStyle = def.color; ctx.fillRect(-12, -ww / 2, 14, ww);
      ctx.fillStyle = def.accent; ctx.beginPath(); ctx.roundRect(-10, -Math.min(ww * 0.36, 36), 22, Math.min(ww * 0.72, 72), 4); ctx.fill();
      ctx.strokeStyle = v.working ? '#ffe07d' : '#222'; ctx.lineWidth = 2; ctx.stroke();
    } else if (def.id === 'amazone_ux5201') {
      // Прицепной штанговый опрыскиватель
      this.drawWheel(ctx, -6, -24, 14, 6); this.drawWheel(ctx, -6, 18, 14, 6);
      ctx.fillStyle = '#2b7a38'; ctx.beginPath(); ctx.roundRect(-22, -16, 40, 32, 6); ctx.fill();
      ctx.fillStyle = '#e6781e'; ctx.beginPath(); ctx.roundRect(-14, -12, 24, 24, 5); ctx.fill();
      // Штанги: разложены при работе, сложены по бокам на дороге
      ctx.strokeStyle = '#334d36'; ctx.lineWidth = 4;
      if (v.working) {
        ctx.beginPath(); ctx.moveTo(-20, -ww / 2); ctx.lineTo(-20, ww / 2); ctx.stroke();
        ctx.fillStyle = 'rgba(170, 235, 255, 0.26)';
        ctx.fillRect(-34, -ww / 2, 14, ww);
      } else {
        ctx.beginPath(); ctx.moveTo(-20, -18); ctx.lineTo(18, -18); ctx.moveTo(-20, 18); ctx.lineTo(18, 18); ctx.stroke();
      }
    } else if (def.id === 'rum5' || def.id === 'bredal_k165') {
      const isBig = def.id === 'bredal_k165';
      if (isBig) {
        this.drawWheel(ctx, -18, -22, 14, 6); this.drawWheel(ctx, -18, 16, 14, 6);
        this.drawWheel(ctx, 2, -22, 14, 6); this.drawWheel(ctx, 2, 16, 14, 6);
      } else {
        this.drawWheel(ctx, -4, -19, 12, 5); this.drawWheel(ctx, -4, 14, 12, 5);
      }
      ctx.fillStyle = def.color;
      ctx.beginPath(); ctx.roundRect(isBig ? -26 : -18, isBig ? -16 : -13, isBig ? 48 : 34, isBig ? 32 : 26, 5); ctx.fill();
      ctx.fillStyle = def.accent;
      ctx.fillRect(isBig ? -20 : -12, isBig ? -11 : -9, isBig ? 36 : 22, isBig ? 22 : 18);
      if (v.working) {
        ctx.fillStyle = 'rgba(210, 245, 255, 0.20)';
        ctx.beginPath(); ctx.moveTo(isBig ? -26 : -18, 0); ctx.lineTo(-56, -ww / 2); ctx.lineTo(-56, ww / 2); ctx.closePath(); ctx.fill();
      }
    } else if (def.role === 'spreader') {
      ctx.fillStyle = '#2f8a36'; ctx.beginPath(); ctx.roundRect(-14, -22, 26, 44, 5); ctx.fill();
      ctx.fillStyle = '#e67e22'; ctx.fillRect(-10, -17, 18, 34);
      if (v.working) {
        ctx.fillStyle = 'rgba(210, 245, 255, 0.22)';
        ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(-42, -ww / 2); ctx.lineTo(-42, ww / 2); ctx.closePath(); ctx.fill();
      }
    }
  }
};
