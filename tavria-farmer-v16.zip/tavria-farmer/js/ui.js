window.TF = window.TF || {};

TF.UI = {
  currentModal: null,
  shopFilter: 'all',
  shopTierFilter: 'all',
  shopSort: 'price_asc',
  workerTab: 'assign',
  fullMapOpen: false,
  selectedMapFieldId: null,
  preselectFieldId: null,

  init() {
    document.getElementById('btnShop').onclick = () => this.openModal('shop');
    document.getElementById('btnMap').onclick = () => this.openFullMap();
    document.getElementById('minimapWrap').onclick = () => this.openFullMap();
    document.getElementById('fullMapClose').onclick = () => this.closeFullMap();
    document.getElementById('btnFullMapList').onclick = () => { this.closeFullMap(); this.openModal('map'); };
    document.getElementById('fullMapCanvas').onclick = (e) => this.handleFullMapClick(e);

    document.getElementById('btnWorkers').onclick = () => this.openWorkersModal();
    document.getElementById('btnContracts').onclick = () => this.openModal('contracts');
    document.getElementById('btnMarket').onclick = () => this.openModal('market');
    document.getElementById('btnFleet').onclick = () => this.openModal('fleet');
    document.getElementById('btnMenu').onclick = () => this.openModal('menu');
    document.getElementById('btnRescue').onclick = () => this.openModal('rescue');
    document.getElementById('modalClose').onclick = () => this.closeModal();
    document.getElementById('modalBackdrop').onclick = (e) => { if (e.target.id === 'modalBackdrop') this.closeModal(); };

    const btnRadio = document.getElementById('btnRadio');
    if (btnRadio) btnRadio.onclick = () => this.openModal('radio');
    document.getElementById('btnSound').onclick = () => {
      const m = TF.Audio.toggleMute();
      document.getElementById('btnSound').textContent = m ? '🔇' : '🔊';
      this.toast(m ? 'Звук выключен' : '3D-звук включён');
    };
    document.getElementById('btnTimeSpeed').onclick = () => TF.Game.cycleTimeSpeed();
    document.getElementById('btnSkipDay').onclick = () => TF.Game.skipToMorning();
    document.getElementById('btnSwitchVeh').onclick = () => TF.Game.switchVehicle();
    document.getElementById('btnCropSelect').onclick = () => TF.Game.cycleCrop();
    document.getElementById('btnHitch').onclick = () => TF.Vehicles.toggleHitch(TF.Game.getActiveVehicle());
    document.getElementById('btnWork').onclick = () => TF.Vehicles.toggleWork(TF.Game.getActiveVehicle());
    document.getElementById('btnUnload').onclick = () => TF.Vehicles.performContextAction(TF.Game.getActiveVehicle());
    document.getElementById('btnQuickAI').onclick = () => this.handleQuickAI();
    document.getElementById('btnZoomIn').onclick = () => TF.Game.adjustZoom(1.2);
    document.getElementById('btnZoomOut').onclick = () => TF.Game.adjustZoom(0.83);

    document.getElementById('importSaveInput').onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          JSON.parse(reader.result);
          localStorage.setItem(TF.Game.SAVE_KEY, reader.result);
          location.reload();
        } catch (err) { this.toast('Ошибка: неверный файл сохранения!'); }
      };
      reader.readAsText(file);
    };
  },

  toast(msg) {
    const box = document.getElementById('toastContainer');
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 250); }, 3500);
  },

  openWorkersModal(fieldId = null) {
    this.preselectFieldId = fieldId;
    this.workerTab = TF.AI.hiredWorkerIds.length === 0 ? 'hire' : 'assign';
    this.openModal('workers');
  },

  handleQuickAI() {
    const v = TF.Game.getActiveVehicle();
    if (!v) return;
    if (v.ai) { TF.AI.stopVehicle(v); return; }
    const free = TF.AI.getFreeWorkers();
    if (free.length === 0) { this.workerTab = 'hire'; this.openModal('workers'); this.toast('Сначала найми работника на Бирже труда!'); return; }
    const f = TF.World.getFieldAt(v.x, v.y);
    if (f && (f.owned || TF.Game.isContractField(f.id))) {
      if (TF.AI.assign(free[0].id, v, f.id, TF.AI.getRecommendedTask(v), v.selectedCrop)) return;
    }
    this.openWorkersModal();
  },

  openFullMap() {
    this.fullMapOpen = true;
    document.getElementById('fullMapOverlay').classList.remove('hidden');
    this.drawFullMap();
    this.updateFullMapFooter();
  },

  closeFullMap() {
    this.fullMapOpen = false;
    document.getElementById('fullMapOverlay').classList.add('hidden');
  },

  drawFullMap() {
    if (!this.fullMapOpen) return;
    const canvas = document.getElementById('fullMapCanvas'), wrap = canvas.parentElement;
    const maxW = Math.max(320, wrap.clientWidth - 16), maxH = Math.max(240, wrap.clientHeight - 16);
    const aspect = TF.DATA.WORLD_W / TF.DATA.WORLD_H;
    let w = maxW, h = w / aspect;
    if (h > maxH) { h = maxH; w = h * aspect; }
    canvas.width = Math.round(w); canvas.height = Math.round(h);
    const ctx = canvas.getContext('2d'), sx = w / TF.DATA.WORLD_W, sy = h / TF.DATA.WORLD_H;

    ctx.fillStyle = TF.Game.seasonIdx === 3 ? '#c6d6de' : '#58753c'; ctx.fillRect(0, 0, w, h);
    for (const v of TF.DATA.VILLAGES) {
      const b = v.box;
      ctx.fillStyle = '#475c34'; ctx.fillRect(b.x * sx, b.y * sy, b.w * sx, b.h * sy);
      ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = 1.5; ctx.strokeRect(b.x * sx, b.y * sy, b.w * sx, b.h * sy);
    }
    const cy = TF.DATA.CANAL.y * sy;
    ctx.fillStyle = '#1f6d9c'; ctx.fillRect(0, cy - Math.max(4, TF.DATA.CANAL.w * sy / 2), w, Math.max(8, TF.DATA.CANAL.w * sy));
    for (const r of TF.DATA.ROADS) {
      ctx.strokeStyle = r.type === 'asphalt' ? '#3d4247' : '#a89069'; ctx.lineWidth = Math.max(3, r.w * sx);
      ctx.beginPath(); ctx.moveTo(r.x1 * sx, r.y1 * sy); ctx.lineTo(r.x2 * sx, r.y2 * sy); ctx.stroke();
    }
    for (const br of TF.DATA.BRIDGES) {
      ctx.fillStyle = '#d9dedc'; ctx.fillRect((br.x - 45) * sx, (br.y - 55) * sy, Math.max(6, 90 * sx), Math.max(8, 110 * sy));
    }
    for (const f of TF.World.fields) {
      const sum = TF.World.getFieldSummary(f), isC = TF.Game.isContractField(f.id);
      let fill = f.owned ? '#4d8a42' : (isC ? '#3a6f99' : '#948050');
      if (f.owned && sum.pctReady > 20) fill = '#d9b543';
      else if (f.owned && sum.pctPlowed > 40) fill = '#634832';
      const fx = f.x * sx, fy = f.y * sy, fw = f.w * sx, fh = f.h * sy;
      ctx.fillStyle = fill; ctx.fillRect(fx, fy, fw, fh);
      const isSel = f.id === this.selectedMapFieldId;
      ctx.strokeStyle = isSel ? '#ffffff' : (f.owned ? '#79f284' : (isC ? '#70c4ff' : '#f5c71a'));
      ctx.lineWidth = isSel ? 3 : 1.5; ctx.strokeRect(fx, fy, fw, fh);
      ctx.fillStyle = '#fff'; ctx.font = `bold ${Math.max(10, Math.round(12 * (w / 900)))}px system-ui, sans-serif`; ctx.textAlign = 'center';
      ctx.fillText(`№${f.id}`, fx + fw / 2, fy + fh / 2 + 2);
      if (fw > 48 && fh > 28) {
        ctx.font = `${Math.max(8, Math.round(9 * (w / 900)))}px system-ui, sans-serif`; ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.fillText(`${f.ha} га`, fx + fw / 2, fy + fh / 2 + 13);
      }
    }
    for (const s of TF.DATA.STATIONS) {
      ctx.fillStyle = s.type === 'elevator' ? '#ffe07d' : s.type === 'shop' ? '#4ba3e3' : '#e07b39';
      ctx.beginPath(); ctx.arc((s.x + s.w / 2) * sx, (s.y + s.h / 2) * sy, Math.max(5, 7 * (w / 900)), 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#111'; ctx.lineWidth = 1.5; ctx.stroke();
    }
    for (const v of TF.Vehicles.list) {
      if (v.category === 'tractor' || v.category === 'combine') {
        ctx.fillStyle = v.broken ? '#ff4444' : (v.uid === TF.Game.activeVehicleUid ? '#ffffff' : (v.ai ? '#7dff8b' : '#ff8c69'));
        ctx.beginPath(); ctx.arc(v.x * sx, v.y * sy, v.uid === TF.Game.activeVehicleUid ? 6 : 4, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5; ctx.stroke();
      }
    }
    ctx.textAlign = 'center';
    for (const v of TF.DATA.VILLAGES) {
      const lx = (v.box.x + v.box.w / 2) * sx, ly = (v.box.y + v.box.h / 2) * sy;
      ctx.font = `800 ${Math.max(11, Math.round(14 * (w / 900)))}px system-ui, sans-serif`;
      const tw = ctx.measureText(v.name).width + 10;
      ctx.fillStyle = 'rgba(12, 18, 14, 0.82)'; ctx.fillRect(lx - tw / 2, ly - 10, tw, 19);
      ctx.fillStyle = '#ffffff'; ctx.fillText(v.name, lx, ly + 4);
    }
  },

  handleFullMapClick(e) {
    const canvas = document.getElementById('fullMapCanvas'), rect = canvas.getBoundingClientRect();
    const wx = ((e.clientX - rect.left) / rect.width) * TF.DATA.WORLD_W;
    const wy = ((e.clientY - rect.top) / rect.height) * TF.DATA.WORLD_H;
    const f = TF.World.getFieldAt(wx, wy);
    this.selectedMapFieldId = f ? f.id : null;
    this.drawFullMap(); this.updateFullMapFooter();
  },

  updateFullMapFooter() {
    const el = document.getElementById('fullMapSelection');
    if (!this.selectedMapFieldId) {
      el.innerHTML = 'Нажми на поле · 🟩 Свои · 🟦 Контракт · 🟨 Продаются · 🔵 Магазин · 🟡 Элеваторы · ⚪ Ты';
      return;
    }
    const f = TF.World.fields.find(x => x.id === this.selectedMapFieldId);
    if (!f) return;
    const sum = TF.World.getFieldSummary(f), canWork = f.owned || TF.Game.isContractField(f.id);
    el.innerHTML = `
      <div class="fullmap-action-bar">
        <div><strong style="color:#ffe07d">${f.name}</strong> (${f.ha} га) · ${sum.status} · Удобрено: ${sum.pctFert}%</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <button class="buy-btn secondary" id="fmFocusBtn">👁 Показать</button>
          ${canWork ? `<button class="buy-btn" id="fmHireBtn">👷 Отправить наёмника</button>` : `<button class="buy-btn" id="fmBuyBtn" ${TF.Game.money >= TF.Game.getFieldBuyPrice(f) ? '' : 'disabled'}>Купить ($${TF.Game.getFieldBuyPrice(f).toLocaleString('ru-RU')})</button>`}
        </div>
      </div>
    `;
    document.getElementById('fmFocusBtn').onclick = () => { TF.Game.focusCameraOn(f.x + f.w / 2, f.y + f.h / 2); this.closeFullMap(); };
    const bBuy = document.getElementById('fmBuyBtn'); if (bBuy) bBuy.onclick = () => { TF.Game.buyField(f.id); this.drawFullMap(); this.updateFullMapFooter(); };
    const bHire = document.getElementById('fmHireBtn'); if (bHire) bHire.onclick = () => { this.closeFullMap(); this.openWorkersModal(f.id); };
  },

  updateHUD() {
    const g = TF.Game;
    document.getElementById('hudMoney').textContent = '$' + Math.floor(g.money).toLocaleString('ru-RU');
    const season = TF.DATA.SEASONS[g.seasonIdx];
    const weatherIcon = TF.World.weather === 'rain' ? '🌧' : (g.hour >= 20 || g.hour <= 6 ? '🌙' : season.icon);
    document.getElementById('hudSeason').textContent = `${weatherIcon} ${season.name}`;
    document.getElementById('hudDay').textContent = `Д${g.day}`;
    const hh = String(Math.floor(g.hour)).padStart(2, '0'), mm = String(Math.floor((g.hour % 1) * 60)).padStart(2, '0');
    document.getElementById('hudClock').textContent = `${hh}:${mm}`;
    document.getElementById('btnTimeSpeed').textContent = 'x' + TF.DATA.TIME_SPEEDS[g.timeSpeedIdx];

    const workersCount = TF.Vehicles.list.filter(v => v.ai).length;
    document.getElementById('badgeWorkers').textContent = `${workersCount}/${TF.AI.hiredWorkerIds.length}`;

    const v = g.getActiveVehicle();
    if (!v) return;
    const def = TF.DATA.getItem(v.modelId);
    const att = v.attachment ? TF.Vehicles.getByUid(v.attachment) : null;
    const hdr = v.frontAttachment ? TF.Vehicles.getByUid(v.frontAttachment) : null;

    document.getElementById('vsName').textContent = def.name + (v.broken ? ' 💥' : '');
    document.getElementById('vsLocation').textContent = TF.World.getNearestVillageName(v.x, v.y);
    document.getElementById('vsAiBadge').classList.toggle('hidden', !v.ai);

    const fuelPct = def.fuelCap ? Math.round((v.fuel / def.fuelCap) * 100) : 100;
    document.getElementById('vsFuelBar').style.width = fuelPct + '%';
    document.getElementById('vsFuelTxt').textContent = fuelPct + '%';

    document.getElementById('btnRescue').classList.toggle('hidden', !(v.broken || fuelPct < 12));

    const carrier = v.category === 'combine' ? v : (att && att.role === 'trailer' ? att : null);
    const cargoWrap = document.getElementById('vsCargoWrap');
    if (carrier) {
      cargoWrap.classList.remove('hidden');
      const cCap = TF.DATA.getItem(carrier.modelId).capacity;
      document.getElementById('vsCargoIcon').textContent = carrier.cargoCrop ? TF.DATA.CROPS[carrier.cargoCrop].icon : '🌾';
      document.getElementById('vsCargoBar').style.width = Math.min(100, Math.round((carrier.cargo / cCap) * 100)) + '%';
      document.getElementById('vsCargoTxt').textContent = `${Math.round(carrier.cargo)} / ${cCap}`;
    } else if (att && att.role === 'fuel_trailer') {
      cargoWrap.classList.remove('hidden');
      const fCap = TF.DATA.getItem(att.modelId).capacity;
      document.getElementById('vsCargoIcon').textContent = '🛢';
      document.getElementById('vsCargoBar').style.width = Math.round((att.fuel / fCap) * 100) + '%';
      document.getElementById('vsCargoTxt').textContent = `${Math.round(att.fuel)} / ${fCap} л`;
    } else cargoWrap.classList.add('hidden');

    const kmh = Math.round(Math.abs(v.speed) * 0.34);
    const gear = v.reversing ? ' [R]' : '';
    const attName = hdr ? TF.DATA.getItem(hdr.modelId).name : (att ? TF.DATA.getItem(att.modelId).name : 'нет');
    document.getElementById('vsAttachInfo').textContent = `${v.category === 'combine' ? 'Жатка' : 'Прицепное'}: ${attName} · ${kmh} км/ч${gear}`;

    const cropDef = TF.DATA.CROPS[v.selectedCrop || 'wheat'];
    document.getElementById('btnCropSelect').textContent = `${cropDef.icon} ${cropDef.name}`;
    document.getElementById('btnWork').classList.toggle('active', !!(v.working || (att && att.working)));
    document.getElementById('btnQuickAI').classList.toggle('active', !!v.ai);
  },

  openModal(type) { this.currentModal = type; document.getElementById('modalBackdrop').classList.remove('hidden'); this.renderModal(); },
  closeModal() { this.currentModal = null; document.getElementById('modalBackdrop').classList.add('hidden'); },

  renderModal() {
    const titleEl = document.getElementById('modalTitle'), tabsEl = document.getElementById('modalTabs'), bodyEl = document.getElementById('modalBody');
    tabsEl.innerHTML = ''; bodyEl.innerHTML = '';

    if (this.currentModal === 'rescue') {
      const v = TF.Game.getActiveVehicle(); if (!v) return;
      const def = TF.DATA.getItem(v.modelId), serviceCost = v.broken ? 950 : 550, towCost = 350;
      titleEl.textContent = `🛠 Мобильная техпомощь — ${def.name}`;
      bodyEl.innerHTML = `
        <div class="list-grid">
          <div class="info-card">
            <strong>🚐 Выездная бригада СТО на место</strong>
            <p class="muted">Заправит 45% бака дизелем и переберёт мотор прямо в поле (снимает поломку).</p>
            <div class="row-between" style="margin-top:8px;"><span class="price-tag">$${serviceCost}</span><button class="buy-btn" id="btnCallFieldService" ${TF.Game.money >= serviceCost ? '' : 'disabled'}>Вызвать на место</button></div>
          </div>
          <div class="info-card">
            <strong>🚛 Эвакуатор на базу (Любимо-Павловка)</strong>
            <p class="muted">Доставит технику прямо к твоей ремзоне и АЗС в Любимо-Павловке.</p>
            <div class="row-between" style="margin-top:8px;"><span class="price-tag">$${towCost}</span><button class="buy-btn secondary" id="btnCallTow" ${TF.Game.money >= towCost ? '' : 'disabled'}>Эвакуировать</button></div>
          </div>
        </div>`;
      document.getElementById('btnCallFieldService').onclick = () => {
        if (TF.Game.money < serviceCost) return;
        TF.Game.addMoney(-serviceCost); v.fuel = Math.max(v.fuel, def.fuelCap * 0.45); v.wear = Math.min(v.wear, 15); v.broken = false;
        TF.Audio.playHitch(); this.toast(`🛠 Бригада починила и заправила ${def.name}!`); this.closeModal();
      };
      document.getElementById('btnCallTow').onclick = () => {
        if (TF.Game.money < towCost) return;
        TF.Game.addMoney(-towCost); v.x = 1660; v.y = 5840; v.speed = 0; TF.Game.cam.freeMode = false;
        this.toast(`🚛 ${def.name} эвакуирован на базу! Жми 📦 для ТО и заправки.`); this.closeModal();
      };
      return;
    }

    if (this.currentModal === 'contracts') {
      titleEl.textContent = '📋 Контракты сёл и Репутация';
      const repBar = document.createElement('div');
      repBar.className = 'info-card';
      repBar.style.marginBottom = '12px';
      const repHtml = Object.keys(TF.Game.villageRep).map(vName => {
        const rep = TF.Game.villageRep[vName] || 0;
        const disc = Math.round(TF.Game.getVillageDiscount(vName) * 100);
        return `<span class="vs-tag">${vName}: <b>★${rep}</b>${disc > 0 ? ` (-${disc}%)` : ''}</span>`;
      }).join(' ');
      repBar.innerHTML = `<strong>🏅 Репутация в сёлах (скидка на поля/СТО и дорогие заказы)</strong><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px;">${repHtml}</div>`;
      bodyEl.appendChild(repBar);

      const grid = document.createElement('div'); grid.className = 'list-grid';
      TF.Game.contracts.forEach(c => {
        const f = TF.World.fields.find(x => x.id === c.fieldId);
        if (!f) return;
        const pct = TF.Game.getContractProgress(c);
        const ownReward = c.accepted ? c.reward : Math.round(c.reward * 1.25);
        const card = document.createElement('div');
        card.className = 'info-card' + (c.accepted ? ' owned' : '') + (c.isUrgent ? ' urgent-contract' : '');
        const extraHarvest = (c.accepted && c.type === 'harvest')
          ? `<div class="muted">Сдано на «${c.targetElevName}»: <b>${Math.round(c.deliveredLiters)} / ${c.expectedLiters} л</b></div>` : '';
        card.innerHTML = `
          <div class="row-between"><strong>${c.title}</strong><span class="price-tag">+$${c.reward.toLocaleString('ru-RU')}</span></div>
          <div class="muted">${f.name} (${f.ha} га) · ${c.desc}</div>
          ${extraHarvest}
          ${c.accepted ? `<div class="muted" style="color:#8df097;">Прогресс: <b>${pct}%</b> (нужно 85%)</div>` : `<div class="muted">Своей техникой: <b style="color:#ffe07d">+$${ownReward.toLocaleString('ru-RU')} (+25%)</b></div>`}
          <div class="row-between" style="margin-top:6px;flex-wrap:wrap;gap:6px;">
            <button class="buy-btn secondary" data-cshow="${f.id}">Показать</button>
            ${!c.accepted
              ? `<button class="buy-btn" data-cown="${c.id}">Своей (+25%)</button>
                 <button class="buy-btn secondary" data-cloan="${c.id}">Взять с техникой</button>`
              : (pct >= 85
                ? `<button class="buy-btn" data-cclaim="${c.id}">💰 Забрать награду!</button>`
                : `<button class="buy-btn danger" data-ccancel="${c.id}">Отказаться</button>`)
            }
          </div>`;
        grid.appendChild(card);
      });
      grid.querySelectorAll('[data-cshow]').forEach(b => { b.onclick = () => { const f = TF.World.fields.find(x => x.id === Number(b.dataset.cshow)); if (f) { TF.Game.focusCameraOn(f.x + f.w / 2, f.y + f.h / 2); this.closeModal(); } }; });
      grid.querySelectorAll('[data-cown]').forEach(b => { b.onclick = () => { TF.Game.acceptContract(b.dataset.cown, false); this.renderModal(); }; });
      grid.querySelectorAll('[data-cloan]').forEach(b => { b.onclick = () => { TF.Game.acceptContract(b.dataset.cloan, true); this.renderModal(); }; });
      grid.querySelectorAll('[data-cclaim]').forEach(b => { b.onclick = () => { TF.Game.claimContract(b.dataset.cclaim); this.renderModal(); }; });
      grid.querySelectorAll('[data-ccancel]').forEach(b => { b.onclick = () => { TF.Game.cancelContract(b.dataset.ccancel); this.renderModal(); }; });
      bodyEl.appendChild(grid);
      return;
    }

    if (this.currentModal === 'shop') {
      titleEl.textContent = '🚜 Дилерский центр «Тавричанка» — Магазин техники';
      const cats = [
        { id: 'all', label: 'Всё' },
        { id: 'tractor', label: 'Тракторы' },
        { id: 'combine', label: 'Комбайны' },
        { id: 'header_grain', label: 'Жатки (зерно)' },
        { id: 'header_corn', label: 'Жатки (кукуруза)' },
        { id: 'plow', label: 'Плуги / Культ.' },
        { id: 'seeder_grain', label: 'Сеялки зерн.' },
        { id: 'seeder_planter', label: 'Сажалки проп.' },
        { id: 'spreader', label: 'Удобр. / Опрыск.' },
        { id: 'trailer_grain', label: 'Прицепы' },
        { id: 'fuel_trailer', label: 'Топливо' }
      ];
      cats.forEach(t => {
        const b = document.createElement('button');
        b.className = 'tab-btn' + (this.shopFilter === t.id ? ' active' : '');
        b.textContent = t.label;
        b.onclick = () => { this.shopFilter = t.id; this.renderModal(); };
        tabsEl.appendChild(b);
      });

      // Фильтр по классу (тиру) + сортировка
      const filterRow = document.createElement('div');
      filterRow.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;align-items:center;justify-content:space-between;margin-bottom:10px;';
      const tiersHtml = [
        { id: 'all', label: 'Все классы' },
        { id: '1', label: 'СССР / Старт' },
        { id: '2', label: 'Мидгейм' },
        { id: '3', label: 'Флагман' },
        { id: '4', label: 'Ультрафлагман' }
      ].map(t => `<button class="tab-btn ${this.shopTierFilter === t.id ? 'active' : ''}" data-tier="${t.id}">${t.label}</button>`).join('');
      filterRow.innerHTML = `
        <div style="display:flex;gap:5px;flex-wrap:wrap;">${tiersHtml}</div>
        <select id="shopSortSel" class="ui-select" style="width:auto;min-width:165px;">
          <option value="price_asc" ${this.shopSort === 'price_asc' ? 'selected' : ''}>Цена: по возрастанию</option>
          <option value="price_desc" ${this.shopSort === 'price_desc' ? 'selected' : ''}>Цена: по убыванию</option>
          <option value="hp_desc" ${this.shopSort === 'hp_desc' ? 'selected' : ''}>Мощность / захват</option>
        </select>`;
      bodyEl.appendChild(filterRow);
      filterRow.querySelectorAll('[data-tier]').forEach(b => {
        b.onclick = () => { this.shopTierFilter = b.dataset.tier; this.renderModal(); };
      });
      filterRow.querySelector('#shopSortSel').onchange = (e) => {
        this.shopSort = e.target.value; this.renderModal();
      };

      // Панель парковок
      const baseFree = TF.DATA.PARKING_LOTS.base.bays.filter(b => !TF.Vehicles.isBayOccupied(b)).length;
      const shopLot = TF.DATA.PARKING_LOTS.shop;
      const shopFree = shopLot.bays.slice(0, TF.Game.shopParkingSlots).filter(b => !TF.Vehicles.isBayOccupied(b)).length;
      const pBar = document.createElement('div');
      pBar.className = 'info-card';
      pBar.style.marginBottom = '12px';
      pBar.innerHTML = `
        <div class="row-between" style="flex-wrap:wrap;">
          <div>
            <strong>🅿 Парковки выдачи техники:</strong>
            <span class="muted">Любимо-Павловка: <b>${baseFree}/4</b> свободно · Тавричанка: <b>${shopFree}/${TF.Game.shopParkingSlots}</b> свободно (макс. ${shopLot.bays.length})</span>
          </div>
          ${TF.Game.shopParkingSlots < shopLot.bays.length
            ? `<button class="buy-btn" id="btnBuyShopSlots" ${TF.Game.money >= shopLot.slotPrice ? '' : 'disabled'}>+2 слота в Тавричанке ($${shopLot.slotPrice.toLocaleString('ru-RU')})</button>`
            : `<span style="color:#74e382;font-size:12px;font-weight:700;">✓ Вся парковка Тавричанки куплена</span>`
          }
        </div>`;
      bodyEl.appendChild(pBar);
      const bSlots = pBar.querySelector('#btnBuyShopSlots');
      if (bSlots) bSlots.onclick = () => { TF.Game.buyShopParkingSlots(); this.renderModal(); };

      const matchesCat = (c) => {
        if (this.shopFilter === 'all') return true;
        if (this.shopFilter === 'tractor') return c.category === 'tractor';
        if (this.shopFilter === 'combine') return c.category === 'combine';
        if (this.shopFilter === 'header_grain') return c.category === 'header' && c.headerType === 'grain';
        if (this.shopFilter === 'header_corn') return c.category === 'header' && c.headerType === 'corn';
        if (this.shopFilter === 'plow') return c.role === 'plow';
        if (this.shopFilter === 'seeder_grain') return c.role === 'seeder' && c.seederType === 'grain';
        if (this.shopFilter === 'seeder_planter') return c.role === 'seeder' && c.seederType === 'planter';
        if (this.shopFilter === 'spreader') return c.role === 'spreader';
        if (this.shopFilter === 'trailer_grain') return c.role === 'trailer';
        if (this.shopFilter === 'fuel_trailer') return c.role === 'fuel_trailer';
        return true;
      };

      let filtered = TF.DATA.CATALOG.filter(c => matchesCat(c) && (this.shopTierFilter === 'all' || String(c.tier) === this.shopTierFilter));
      if (this.shopSort === 'price_asc') filtered.sort((a, b) => a.price - b.price);
      else if (this.shopSort === 'price_desc') filtered.sort((a, b) => b.price - a.price);
      else if (this.shopSort === 'hp_desc') filtered.sort((a, b) => (b.hp || b.workWidth || b.capacity || 0) - (a.hp || a.workWidth || a.capacity || 0));

      const grid = document.createElement('div'); grid.className = 'shop-grid';
      if (filtered.length === 0) {
        grid.innerHTML = '<div class="muted">По выбранным фильтрам техники нет.</div>';
      }
      filtered.forEach(item => {
        const tier = TF.DATA.TIERS[item.tier], canBuy = TF.Game.money >= item.price;
        let specs = [];
        if (item.hp) specs.push(`<b>${item.hp} л.с.</b>`);
        if (item.reqHp) specs.push(`От <b>${item.reqHp} л.с.</b>`);
        if (item.workWidth) specs.push(`Захват <b>${(item.workWidth / 17).toFixed(1)} м</b>`);
        if (item.capacity) specs.push(`Объём <b>${item.capacity.toLocaleString('ru-RU')} л</b>`);
        const card = document.createElement('div'); card.className = 'shop-card';
        card.innerHTML = `
          <div class="shop-img-wrap"><img src="${item.img}" alt="${item.name}" loading="lazy" /><span class="tier-pill ${tier.cls}">${tier.label}</span></div>
          <div class="shop-info">
            <div class="shop-title">${item.name}</div><div class="shop-brand">${item.brand}</div>
            <div class="shop-specs">${specs.join(' · ')}<br><span class="muted">${item.desc}</span></div>
            <div class="shop-footer"><span class="price-tag">$${item.price.toLocaleString('ru-RU')}</span>
              <div style="display:flex;gap:5px;">
                <button class="buy-btn" ${canBuy ? '' : 'disabled'} data-buy="${item.id}" data-dest="base">На базу</button>
                <button class="buy-btn secondary" ${canBuy ? '' : 'disabled'} data-buy="${item.id}" data-dest="shop">В Тавричанку</button>
              </div>
            </div>
          </div>`;
        grid.appendChild(card);
      });
      grid.querySelectorAll('[data-buy]').forEach(btn => { btn.onclick = () => { TF.Game.buyItem(btn.dataset.buy, btn.dataset.dest); this.renderModal(); }; });
      bodyEl.appendChild(grid);
    }

    else if (this.currentModal === 'map') {
      titleEl.textContent = '📋 Список всех 22 полей Херсонщины';
      const openMapBtn = document.createElement('button'); openMapBtn.className = 'tab-btn active'; openMapBtn.textContent = '🗺 Открыть карту на весь экран';
      openMapBtn.onclick = () => { this.closeModal(); this.openFullMap(); }; tabsEl.appendChild(openMapBtn);
      const grid = document.createElement('div'); grid.className = 'list-grid';
      TF.World.fields.forEach(f => {
        const sum = TF.World.getFieldSummary(f);
        const card = document.createElement('div'); card.className = 'info-card' + (f.owned ? ' owned' : '');
        card.innerHTML = `
          <div class="row-between"><strong>${f.name}</strong><span class="muted">${f.ha} га</span></div>
          <div class="muted">Статус: <b style="color:#fff">${sum.status}</b> · Удобрено: ${sum.pctFert}%</div>
          <div class="row-between" style="margin-top:4px;">
            ${f.owned ? `<span style="color:#74e382;font-weight:700;font-size:12px;">✓ В собственности</span>` : `<span class="price-tag">$${f.price.toLocaleString('ru-RU')}</span>`}
            <div style="display:flex;gap:6px;">
              <button class="buy-btn secondary" data-focus="${f.id}">Показать</button>
              ${f.owned ? '' : `<button class="buy-btn" ${TF.Game.money >= TF.Game.getFieldBuyPrice(f) ? '' : 'disabled'} data-buyfield="${f.id}">Купить ($${TF.Game.getFieldBuyPrice(f).toLocaleString('ru-RU')})</button>`}
            </div>
          </div>`;
        grid.appendChild(card);
      });
      grid.querySelectorAll('[data-focus]').forEach(b => { b.onclick = () => { const f = TF.World.fields.find(x => x.id === Number(b.dataset.focus)); if (f) { TF.Game.focusCameraOn(f.x + f.w / 2, f.y + f.h / 2); this.closeModal(); } }; });
      grid.querySelectorAll('[data-buyfield]').forEach(b => { b.onclick = () => { TF.Game.buyField(Number(b.dataset.buyfield)); this.renderModal(); }; });
      bodyEl.appendChild(grid);
    }

    else if (this.currentModal === 'workers') {
      titleEl.textContent = '👷 Наёмники (ИИ) — Штат и Биржа труда';
      [{ id: 'assign', label: `Мой штат (${TF.AI.hiredWorkerIds.length})` }, { id: 'hire', label: 'Нанять в штат' }].forEach(t => {
        const b = document.createElement('button'); b.className = 'tab-btn' + (this.workerTab === t.id ? ' active' : ''); b.textContent = t.label;
        b.onclick = () => { this.workerTab = t.id; this.renderModal(); }; tabsEl.appendChild(b);
      });
      if (this.workerTab === 'hire') {
        const grid = document.createElement('div'); grid.className = 'list-grid';
        TF.DATA.WORKER_POOL.forEach(w => {
          const hired = TF.AI.isHired(w.id);
          const card = document.createElement('div'); card.className = 'info-card' + (hired ? ' owned' : '');
          card.innerHTML = `
            <div class="row-between"><strong>👷 ${w.name}</strong><span class="vs-tag">+${Math.round((w.speedBonus - 1) * 100)}% темп</span></div>
            <div class="muted">${w.role} · $${Math.round(w.wagePerSec * 60)}/мин</div>
            <div class="row-between" style="margin-top:6px;"><span class="price-tag">${hired ? 'В штате' : '$' + w.hireCost.toLocaleString('ru-RU')}</span>
              ${hired ? `<button class="buy-btn secondary" data-gotoassign="1">Назначить →</button>` : `<button class="buy-btn" ${TF.Game.money >= w.hireCost ? '' : 'disabled'} data-recruit="${w.id}">Нанять</button>`}
            </div>`;
          grid.appendChild(card);
        });
        grid.querySelectorAll('[data-recruit]').forEach(b => { b.onclick = () => { if (TF.AI.recruitWorker(b.dataset.recruit)) { this.workerTab = 'assign'; this.renderModal(); } }; });
        grid.querySelectorAll('[data-gotoassign]').forEach(b => { b.onclick = () => { this.workerTab = 'assign'; this.renderModal(); }; });
        bodyEl.appendChild(grid);
      } else {
        if (TF.AI.hiredWorkerIds.length === 0) {
          bodyEl.innerHTML = `<div class="info-card"><strong>Нет нанятых работников!</strong><p class="muted">Найми первого работника на Бирже труда.</p><div><button class="buy-btn" id="btnGoHire">💼 Биржа труда</button></div></div>`;
          document.getElementById('btnGoHire').onclick = () => { this.workerTab = 'hire'; this.renderModal(); };
          return;
        }
        const drivables = TF.Vehicles.getDrivables();
        const workFields = TF.World.fields.filter(f => f.owned || TF.Game.isContractField(f.id));
        const freeWorkers = TF.AI.getFreeWorkers();
        if (freeWorkers.length > 0) {
          const form = document.createElement('div'); form.className = 'info-card'; form.style.marginBottom = '14px';
          const recTask = TF.AI.getRecommendedTask(drivables[0]);
          form.innerHTML = `
            <strong>Назначить работника на поле</strong>
            <div class="list-grid" style="margin-top:6px;">
              <div><div class="muted">Работник</div><select id="aiWorkerSel" class="ui-select">${freeWorkers.map(w => `<option value="${w.id}">👷 ${w.name}</option>`).join('')}</select></div>
              <div><div class="muted">Техника</div><select id="aiVehSel" class="ui-select">${drivables.map(v => {
                const d = TF.DATA.getItem(v.modelId);
                const extra = v.frontAttachment ? ' + ' + TF.DATA.getItem(TF.Vehicles.getByUid(v.frontAttachment).modelId).name : (v.attachment ? ' + ' + TF.DATA.getItem(TF.Vehicles.getByUid(v.attachment).modelId).name : '');
                return `<option value="${v.uid}">${d.name}${extra}</option>`;
              }).join('')}</select></div>
              <div><div class="muted">Поле</div><select id="aiFieldSel" class="ui-select">${workFields.map(f => `<option value="${f.id}" ${this.preselectFieldId === f.id ? 'selected' : ''}>${f.name} (${f.ha} га)</option>`).join('')}</select></div>
              <div><div class="muted">Задача</div><select id="aiTaskSel" class="ui-select">
                <option value="harvest" ${recTask === 'harvest' ? 'selected' : ''}>🌾 Косить (Комбайн + Жатка)</option>
                <option value="haul" ${recTask === 'haul' ? 'selected' : ''}>🚛 Возить зерно на элеватор</option>
                <option value="plow" ${recTask === 'plow' ? 'selected' : ''}>🚜 Пахать / Культивировать</option>
                <option value="seed" ${recTask === 'seed' ? 'selected' : ''}>🌱 Сеять</option>
                <option value="fertilize" ${recTask === 'fertilize' ? 'selected' : ''}>💧 Удобрять (+50%)</option>
              </select></div>
              <div><div class="muted">Культура</div><select id="aiCropSel" class="ui-select">${Object.values(TF.DATA.CROPS).map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('')}</select></div>
            </div>
            <div style="margin-top:10px;display:flex;justify-content:flex-end;"><button class="buy-btn" id="btnHireSubmit">👷 Отправить</button></div>`;
          bodyEl.appendChild(form);
          const vehSel = form.querySelector('#aiVehSel'), taskSel = form.querySelector('#aiTaskSel');
          vehSel.onchange = () => { taskSel.value = TF.AI.getRecommendedTask(TF.Vehicles.getByUid(Number(vehSel.value))); };
          form.querySelector('#btnHireSubmit').onclick = () => {
            if (TF.AI.assign(document.getElementById('aiWorkerSel').value, TF.Vehicles.getByUid(Number(vehSel.value)), Number(document.getElementById('aiFieldSel').value), taskSel.value, document.getElementById('aiCropSel').value)) {
              this.preselectFieldId = null; this.renderModal();
            }
          };
        }
        const grid = document.createElement('div'); grid.className = 'list-grid';
        TF.AI.hiredWorkerIds.forEach(wId => {
          const w = TF.AI.getWorkerById(wId), v = TF.AI.getAssignedVehicle(wId), d = v ? TF.DATA.getItem(v.modelId) : null;
          const card = document.createElement('div'); card.className = 'info-card' + (v ? ' owned' : '');
          card.innerHTML = `
            <div class="row-between"><strong>👷 ${w.name}</strong><span class="${v ? 'ai-tag' : 'vs-tag'}" style="padding:2px 7px;border-radius:6px;font-size:11px;">${v ? TF.AI.getTaskLabel(v.ai.task) : 'Свободен'}</span></div>
            <div class="muted">${v ? `${d.name} · Поле №${v.ai.fieldId} · Топливо: ${Math.round((v.fuel / d.fuelCap) * 100)}%` : w.role}</div>
            ${v ? `<div class="row-between"><button class="buy-btn secondary" data-jump="${v.uid}">Смотреть</button><button class="buy-btn danger" data-fire="${v.uid}">Остановить</button></div>` : ''}`;
          grid.appendChild(card);
        });
        grid.querySelectorAll('[data-fire]').forEach(b => { b.onclick = () => { TF.AI.stopVehicle(TF.Vehicles.getByUid(Number(b.dataset.fire))); this.renderModal(); }; });
        grid.querySelectorAll('[data-jump]').forEach(b => { b.onclick = () => { TF.Game.selectVehicle(Number(b.dataset.jump)); this.closeModal(); }; });
        bodyEl.appendChild(grid);
      }
    }

    else if (this.currentModal === 'market') {
      titleEl.textContent = '📈 Рынок зерна — Элеваторы Херсонщины';
      const dud = TF.DATA.STATIONS.find(s => s.id === 'dud_elev'), tav = TF.DATA.STATIONS.find(s => s.id === 'tav_elev'), mar = TF.DATA.STATIONS.find(s => s.id === 'mar_elev');
      const table = document.createElement('table'); table.className = 'market-table';
      table.innerHTML = `<thead><tr><th>Культура</th><th>Жатка</th><th>Дудчино</th><th>Марьяновка</th><th>Тавричанка</th><th>Тренд</th></tr></thead><tbody>
        ${Object.values(TF.DATA.CROPS).map(c => {
          const diff = TF.World.prices[c.id] - TF.World.prevPrices[c.id];
          return `<tr><td><strong>${c.icon} ${c.name}</strong></td><td class="muted">${c.headerType === 'corn' ? 'Пропашная' : 'Зерновая'}</td><td>$${TF.World.getSellPrice(c.id, dud)}</td><td>$${TF.World.getSellPrice(c.id, mar)}</td><td><b style="color:#ffe07d">$${TF.World.getSellPrice(c.id, tav)}</b></td><td>${diff >= 0 ? `<span class="trend-up">▲ +$${diff}</span>` : `<span class="trend-down">▼ -$${Math.abs(diff)}</span>`}</td></tr>`;
        }).join('')}</tbody>`;
      bodyEl.appendChild(table);
    }

    else if (this.currentModal === 'fleet') {
      titleEl.textContent = '🔑 Твой автопарк';
      const grid = document.createElement('div'); grid.className = 'list-grid';
      TF.Vehicles.list.forEach(v => {
        const d = TF.DATA.getItem(v.modelId), isDrivable = v.category === 'tractor' || v.category === 'combine', sellPrice = Math.round(d.price * 0.6);
        const card = document.createElement('div'); card.className = 'info-card' + (v.uid === TF.Game.activeVehicleUid ? ' owned' : '');
        card.innerHTML = `
          <div class="row-between"><strong>${d.name} ${v.loanerForContractId ? '(Аренда)' : ''} ${v.broken ? '💥' : ''}</strong><span class="muted">${TF.World.getNearestVillageName(v.x, v.y)}</span></div>
          <div class="muted">${isDrivable ? `Топливо: ${Math.round((v.fuel / d.fuelCap) * 100)}% · ${v.broken ? 'Требуется ремонт' : 'На ходу · заезжай на СТО для ТО'}` : d.desc}</div>
          <div class="row-between" style="margin-top:4px;">
            ${isDrivable ? `<button class="buy-btn" data-sel="${v.uid}">Сесть</button>` : `<button class="buy-btn secondary" data-look="${v.uid}">Показать</button>`}
            ${isDrivable && (v.broken || v.fuel < d.fuelCap * 0.15) ? `<button class="buy-btn secondary" data-rescue="${v.uid}">🛠 Сервис</button>` : ''}
            <button class="buy-btn danger" data-sell="${v.uid}">Продать ($${sellPrice.toLocaleString('ru-RU')})</button>
          </div>`;
        grid.appendChild(card);
      });
      grid.querySelectorAll('[data-sel]').forEach(b => { b.onclick = () => { TF.Game.selectVehicle(Number(b.dataset.sel)); this.closeModal(); }; });
      grid.querySelectorAll('[data-rescue]').forEach(b => { b.onclick = () => { TF.Game.selectVehicle(Number(b.dataset.rescue)); this.openModal('rescue'); }; });
      grid.querySelectorAll('[data-look]').forEach(b => { b.onclick = () => { const v = TF.Vehicles.getByUid(Number(b.dataset.look)); if (v) { TF.Game.focusCameraOn(v.x, v.y); this.closeModal(); } }; });
      grid.querySelectorAll('[data-sell]').forEach(b => { b.onclick = () => { TF.Game.sellVehicle(Number(b.dataset.sell)); this.renderModal(); }; });
      bodyEl.appendChild(grid);
    }

    else if (this.currentModal === 'radio') {
      titleEl.textContent = '📻 Радио «Таврия FM»';
      const cur = TF.Radio.getCurrentTrack();
      const volPct = Math.round(TF.Radio.volume * 100);
      bodyEl.innerHTML = `
        <div class="radio-player-card">
          <div class="radio-now-label">${TF.Radio.playing ? '▶ Сейчас играет' : '⏸ На паузе'}</div>
          <div class="radio-now-title">${cur ? cur.title : 'Нет треков'}</div>
          <div class="radio-controls">
            <button class="hud-btn" id="radPrev">⏮</button>
            <button class="hud-btn accent-btn" id="radToggle">${TF.Radio.playing ? '⏸ Пауза' : '▶ Играть'}</button>
            <button class="hud-btn" id="radNext">⏭</button>
            <button class="hud-btn ${TF.Radio.shuffle ? 'active' : ''}" id="radShuf" title="Вперемешку">🔀</button>
          </div>
          <div class="radio-vol-row">
            <span>🔊 Громкость: <b id="radVolTxt">${volPct}%</b></span>
            <input type="range" id="radVol" min="0" max="100" value="${volPct}" />
          </div>
          <div class="radio-upload-row">
            <label class="hud-btn accent-btn radio-file-btn">
              📂 + Выбрать свои MP3 / WAV
              <input type="file" id="radFileInput" accept="audio/*" multiple hidden />
            </label>
          </div>
          <div class="radio-hint">Выбирай треки прямо с устройства кнопкой выше или кидай MP3 в папку <b>assets/radio/</b> и дописывай их в <b>playlist.js</b>.</div>
        </div>
        <div class="radio-list">
          ${TF.Radio.tracks.map((tr, i) => `
            <div class="radio-track-row ${i === TF.Radio.currentIdx ? 'current' : ''}">
              <button class="radio-track-play" data-idx="${i}">
                <span>${i === TF.Radio.currentIdx && TF.Radio.playing ? '🔊' : '🎵'}</span>
                <span>${tr.title}</span>
              </button>
              ${tr.custom ? `<button class="radio-track-del" data-del="${i}" title="Убрать">✕</button>` : ''}
            </div>
          `).join('')}
        </div>
      `;
      bodyEl.querySelector('#radPrev').onclick = () => TF.Radio.prev();
      bodyEl.querySelector('#radToggle').onclick = () => TF.Radio.togglePlay();
      bodyEl.querySelector('#radNext').onclick = () => TF.Radio.next();
      bodyEl.querySelector('#radShuf').onclick = () => TF.Radio.toggleShuffle();
      bodyEl.querySelector('#radVol').oninput = (e) => {
        const val = Number(e.target.value);
        TF.Radio.setVolume(val / 100);
        bodyEl.querySelector('#radVolTxt').textContent = val + '%';
      };
      bodyEl.querySelector('#radFileInput').onchange = (e) => {
        TF.Radio.addLocalFiles(e.target.files);
        e.target.value = '';
      };
      bodyEl.querySelectorAll('.radio-track-play').forEach(b => b.onclick = () => TF.Radio.playIndex(Number(b.dataset.idx)));
      bodyEl.querySelectorAll('.radio-track-del').forEach(b => b.onclick = () => TF.Radio.removeTrack(Number(b.dataset.del)));
    }

    else if (this.currentModal === 'menu') {
      const st = TF.Game.stats;
      const ownedCount = TF.World.fields.filter(f => f.owned).length;
      titleEl.textContent = '⚙ Меню и статистика';
      bodyEl.innerHTML = `
        <div class="list-grid">
          <div class="info-card">
            <strong>📊 Статистика хозяйства</strong>
            <p class="muted">
              • Прожито дней: <b>${TF.Game.totalDays}</b><br>
              • Полей в собственности: <b>${ownedCount} / ${TF.World.fields.length}</b><br>
              • Собрано урожая: <b>${(st.harvestedLiters / 1000).toFixed(1)} т</b><br>
              • Заработано всего: <b>$${Math.floor(st.totalEarned).toLocaleString('ru-RU')}</b><br>
              • Выполнено контрактов: <b>${st.contractsDone}</b>
            </p>
          </div>
          <div class="info-card">
            <strong>💾 Сохранение игры</strong>
            <p class="muted">Прогресс сохраняется автоматически каждые 30 секунд. Сохранение можно скачать файлом и перенести на другое устройство.</p>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">
              <button class="buy-btn" id="btnManualSave">💾 Сохранить</button>
              <button class="buy-btn secondary" id="btnExportSave">⬇ Экспорт (.json)</button>
              <button class="buy-btn secondary" id="btnImportSave">⬆ Импорт</button>
              <button class="buy-btn danger" id="btnResetGame">🗑 Заново</button>
            </div>
          </div>
          <div class="info-card">
            <strong>🚀 Версия и обновления (v${window.TF_APP_VERSION || '1.6.0'})</strong>
            <p class="muted">Игра сама проверяет новые версии на GitHub при запуске. Сохранения автоматически переносятся при обновлении.</p>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">
              <button class="buy-btn secondary" id="btnCheckUpdates">🔄 Проверить обновления</button>
            </div>
          </div>
        </div>`;
      document.getElementById('btnManualSave').onclick = () => { TF.Game.save(); this.toast('Сохранено!'); };
      document.getElementById('btnExportSave').onclick = () => TF.Game.exportSaveFile();
      document.getElementById('btnImportSave').onclick = () => document.getElementById('importSaveInput').click();
      document.getElementById('btnCheckUpdates').onclick = () => { if (TF.Updater) TF.Updater.check(false); };
      document.getElementById('btnResetGame').onclick = () => {
        if (confirm('Начать заново в Любимо-Павловке?')) { localStorage.removeItem(TF.Game.SAVE_KEY); location.reload(); }
      };
    }
  }
};
