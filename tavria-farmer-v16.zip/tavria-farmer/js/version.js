// Текущая локальная версия игры (должна совпадать с version.json при релизе)
window.TF_APP_VERSION = '1.6.0';
window.TF_GITHUB_REPO = 'Loker267/tavriafermer';
