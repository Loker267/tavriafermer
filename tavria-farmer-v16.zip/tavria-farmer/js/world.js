window.TF = window.TF || {};

TF.World = {
  fields: [],
  prices: {},
  prevPrices: {},
  trees: [],
  houses: [],
  villageStreets: [],
  tracks: [], // Следы от колёс на почве!
  strawSegments: [], // Непрерывные валки соломы и мульча прямо за комбайном!
  weather: 'clear', // 'clear' | 'rain'
  soilWetness: 0, // 0..1 — влажность почвы после дождя
  rainTimer: 0,

  init() {
    this.fields = TF.DATA.FIELDS_DEF.map(def => {
      const cols = Math.floor(def.w / TF.DATA.TILE_SIZE);
      const rows = Math.floor(def.h / TF.DATA.TILE_SIZE);
      const tiles = new Array(cols * rows);
      for (let i = 0; i < tiles.length; i++) {
        tiles[i] = {
          state: def.initState || 'stubble',
          crop: def.initCrop || null,
          growth: def.initState === 'ready' ? 1 : 0,
          fertilized: false
        };
      }
      const ha = +((cols * rows) * 0.045).toFixed(1);
      // Вычисляем широкий заезд (ворота) на поле со стороны ближайшей дороги!
      const entrance = this.computeFieldEntrance(def);
      return { ...def, cols, rows, ha, tiles, entrance };
    });

    this.initVillagesAndTrees();
    this.initPrices();
  },

  computeFieldEntrance(f) {
    // 4 середины сторон поля — выбираем ту, что ближе всего к дороге!
    const sides = [
      { side: 'top',    x: f.x + f.w / 2, y: f.y,       gx: f.x + f.w / 2, gy: f.y - 60 },
      { side: 'bottom', x: f.x + f.w / 2, y: f.y + f.h, gx: f.x + f.w / 2, gy: f.y + f.h + 60 },
      { side: 'left',   x: f.x,           y: f.y + f.h / 2, gx: f.x - 60,  gy: f.y + f.h / 2 },
      { side: 'right',  x: f.x + f.w,     y: f.y + f.h / 2, gx: f.x + f.w + 60, gy: f.y + f.h / 2 }
    ];
    let best = sides[0], bestD = Infinity;
    for (const s of sides) {
      // Не делаем въезд прямо в канал!
      if (Math.abs(s.gy - TF.DATA.CANAL.y) < 110) continue;
      let minRoad = Infinity;
      for (const r of TF.DATA.ROADS) {
        const d = this.pointToSegDist(s.x, s.y, r.x1, r.y1, r.x2, r.y2);
        if (d < minRoad) minRoad = d;
      }
      if (minRoad < bestD) { bestD = minRoad; best = s; }
    }
    return best;
  },

  pointToSegDist(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const lenSq = dx * dx + dy * dy;
    if (lenSq === 0) return Math.hypot(px - x1, py - y1);
    let t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  },

  isClearForTree(x, y) {
    if (x < 60 || x > TF.DATA.WORLD_W - 60 || y < 60 || y > TF.DATA.WORLD_H - 60) return false;
    for (const r of TF.DATA.ROADS) {
      if (this.pointToSegDist(x, y, r.x1, r.y1, r.x2, r.y2) < r.w / 2 + 52) return false;
    }
    if (Math.abs(y - TF.DATA.CANAL.y) < TF.DATA.CANAL.w / 2 + 56) return false;
    // Большой безопасный отступ от самих полей (54px) + ШИРОКИЕ 260px ВЪЕЗДЫ на каждое поле!
    for (const f of this.fields) {
      if (x >= f.x - 52 && x <= f.x + f.w + 52 && y >= f.y - 52 && y <= f.y + f.h + 52) return false;
      // Широкие ворота со стороны дороги (радиус 155px = проём 310px — проедет даже Lexion 8900 с жаткой!)
      if (Math.hypot(x - f.entrance.x, y - f.entrance.y) < 155) return false;
      // Второй запасной проём с противоположной стороны (радиус 120px)
      const oppX = f.entrance.side === 'left' ? f.x + f.w : f.entrance.side === 'right' ? f.x : f.x + f.w / 2;
      const oppY = f.entrance.side === 'top' ? f.y + f.h : f.entrance.side === 'bottom' ? f.y : f.y + f.h / 2;
      if (Math.hypot(x - oppX, y - oppY) < 120) return false;
    }
    for (const s of TF.DATA.STATIONS) {
      if (x >= s.x - 65 && x <= s.x + s.w + 65 && y >= s.y - 65 && y <= s.y + s.h + 65) return false;
    }
    for (const v of TF.DATA.VILLAGES) {
      const b = v.box;
      if (x >= b.x - 40 && x <= b.x + b.w + 40 && y >= b.y - 40 && y <= b.y + b.h + 40) return false;
    }
    return true;
  },

  isClearForHouse(hx, hy, hw, hh) {
    const cx = hx + hw / 2, cy = hy + hh / 2;
    for (const r of TF.DATA.ROADS) {
      if (this.pointToSegDist(cx, cy, r.x1, r.y1, r.x2, r.y2) < r.w / 2 + Math.max(hw, hh) / 2 + 24) return false;
    }
    return true;
  },

  initVillagesAndTrees() {
    this.trees = [];
    this.houses = [];
    this.villageStreets = [];
    const roofs = ['#8f4635', '#5e6b73', '#7c5338', '#4e697a', '#9c5a3c'];

    TF.DATA.VILLAGES.forEach((v, vi) => {
      const b = v.box;
      const padX = 54, padY = 54;
      const stepX = (b.w - padX * 2) / v.cols;
      const stepY = (b.h - padY * 2) / v.rows;

      for (let r = 0; r < v.rows; r++) {
        const sy = b.y + padY + r * stepY + stepY * 0.5;
        this.villageStreets.push({ x1: b.x + 20, y1: sy, x2: b.x + b.w + 70, y2: sy, w: 22 });
      }
      this.villageStreets.push({ x1: b.x + b.w / 2, y1: b.y + 20, x2: b.x + b.w / 2, y2: b.y + b.h - 20, w: 24 });

      let idx = 0;
      for (let r = 0; r < v.rows; r++) {
        const sy = b.y + padY + r * stepY + stepY * 0.5;
        for (let c = 0; c < v.cols; c++) {
          const hx = b.x + padX + c * stepX + 16;
          const hy1 = sy - 74;
          if (hy1 > b.y + 18 && this.isClearForHouse(hx, hy1, 66, 42)) {
            this.houses.push({
              x: hx, y: hy1, w: 66, h: 42,
              yardX: hx - 12, yardY: hy1 - 10, yardW: 92, yardH: 60,
              roof: roofs[(idx + vi) % roofs.length]
            });
          }
          const hy2 = sy + 28;
          if (hy2 + 44 < b.y + b.h - 18 && this.isClearForHouse(hx + 12, hy2, 64, 40)) {
            this.houses.push({
              x: hx + 12, y: hy2, w: 64, h: 40,
              yardX: hx, yardY: hy2 - 6, yardW: 90, yardH: 58,
              roof: roofs[(idx + vi + 2) % roofs.length]
            });
          }
          idx++;
        }
      }
    });

    const addWindbreak = (x1, y1, x2, y2, step) => {
      const dist = Math.hypot(x2 - x1, y2 - y1);
      const n = Math.floor(dist / step);
      for (let i = 0; i <= n; i++) {
        const t = n === 0 ? 0 : i / n;
        const tx = x1 + (x2 - x1) * t + Math.sin(i * 7.3 + x1) * 5;
        const ty = y1 + (y2 - y1) * t + Math.cos(i * 5.9 + y1) * 5;
        if (this.isClearForTree(tx, ty)) {
          this.trees.push({ x: tx, y: ty, r: 15 + (i % 3) * 3, shade: i % 3 });
        }
      }
    };

    // Лесополосы на щедром отступе 76px от краёв полей (комбайны свободно разворачиваются + 310px въезды!)
    const margin = 76;
    for (const f of this.fields) {
      addWindbreak(f.x - margin, f.y - margin, f.x + f.w + margin, f.y - margin, 58);
      addWindbreak(f.x - margin, f.y + f.h + margin, f.x + f.w + margin, f.y + f.h + margin, 58);
      addWindbreak(f.x - margin, f.y, f.x - margin, f.y + f.h, 58);
      addWindbreak(f.x + f.w + margin, f.y, f.x + f.w + margin, f.y + f.h, 58);
    }
  },

  addTrack(x, y, angle, width) {
    if (this.tracks.length > 520) this.tracks.shift();
    this.tracks.push({ x, y, angle, w: width, wet: this.soilWetness > 0.3 });
  },

  addStrawSegment(x, y, angle, len, type = 'swath') {
    // Не наслаиваем сегменты слишком плотно в одной точке
    for (let i = this.strawSegments.length - 1; i >= Math.max(0, this.strawSegments.length - 16); i--) {
      const s = this.strawSegments[i];
      if (Math.hypot(s.x - x, s.y - y) < 13) return;
    }
    if (this.strawSegments.length > 6500) this.strawSegments.shift();
    this.strawSegments.push({ x, y, angle, len: len || 20, type });
  },

  clearStrawInArea(x, y, radius) {
    const r2 = radius * radius;
    for (let i = this.strawSegments.length - 1; i >= 0; i--) {
      const s = this.strawSegments[i];
      const dx = s.x - x, dy = s.y - y;
      if (dx * dx + dy * dy <= r2) {
        this.strawSegments.splice(i, 1);
      }
    }
  },

  updateWetness(deltaGameHours, seasonIdx) {
    if (this.weather === 'rain') {
      this.soilWetness = Math.min(1.0, this.soilWetness + deltaGameHours * 0.55);
    } else if (this.soilWetness > 0) {
      const dryRate = seasonIdx === 1 ? 0.34 : (seasonIdx === 2 ? 0.18 : 0.25);
      this.soilWetness = Math.max(0, this.soilWetness - deltaGameHours * dryRate);
    }
  },

  getSurfaceAt(x, y) {
    // 1. Проверка бетонных парковок и дворов станций
    for (const s of TF.DATA.STATIONS) {
      if (x >= s.x - 30 && x <= s.x + s.w + 30 && y >= s.y - 30 && y <= s.y + s.h + 30) return 'asphalt';
    }
    for (const key of ['base', 'shop']) {
      const lot = TF.DATA.PARKING_LOTS[key];
      if (x >= lot.x && x <= lot.x + lot.w && y >= lot.y && y <= lot.y + lot.h) return 'asphalt';
    }
    // 2. Проверка дорог (асфальт / грунтовка)
    let onDirt = false;
    for (const r of TF.DATA.ROADS) {
      const dx = r.x2 - r.x1, dy = r.y2 - r.y1;
      const lenSq = dx * dx + dy * dy;
      const t = lenSq === 0 ? 0 : Math.max(0, Math.min(1, ((x - r.x1) * dx + (y - r.y1) * dy) / lenSq));
      const px = r.x1 + t * dx, py = r.y1 + t * dy;
      if (Math.hypot(x - px, y - py) <= r.w * 0.58) {
        if (r.type === 'asphalt') return 'asphalt';
        onDirt = true;
      }
    }
    if (onDirt) return 'dirt';

    // 3. Проверка полей (пашня vs стерня/посев)
    const field = this.getFieldAt(x, y);
    if (field) {
      const hit = this.getTileAt(field, x, y);
      if (hit && hit.tile.state === 'plowed') return 'plowed';
      return 'stubble';
    }
    return 'grass';
  },

  rollWeather(seasonIdx) {
    // Вероятность дождя: выше весной и осенью, ниже летом (зимой снег/ясно)
    const chance = seasonIdx === 3 ? 0.0 : (seasonIdx === 1 ? 0.16 : 0.28);
    const wasRain = this.weather === 'rain';
    this.weather = Math.random() < chance ? 'rain' : 'clear';
    if (this.weather === 'rain' && !wasRain) {
      TF.UI.toast('🌧 Пошёл дождь! Комбайны не могут косить мокрое зерно, пока не распогодится.');
    } else if (this.weather === 'clear' && wasRain) {
      TF.UI.toast('☀ Дождь закончился — можно снова выходить на уборку!');
    }
  },

  isOnRoad(x, y) {
    for (const r of TF.DATA.ROADS) {
      if (this.pointToSegDist(x, y, r.x1, r.y1, r.x2, r.y2) <= r.w / 2 + 24) return true;
    }
    return false;
  },

  isOnBridge(x, y) {
    for (const br of TF.DATA.BRIDGES) {
      if (Math.abs(x - br.x) <= br.w / 2 - 4 && Math.abs(y - br.y) <= br.h / 2 + 22) return true;
    }
    return false;
  },

  resolveCollision(x, y, radius, prevX, prevY) {
    let nx = Math.max(50, Math.min(TF.DATA.WORLD_W - 50, x));
    let ny = Math.max(50, Math.min(TF.DATA.WORLD_H - 50, y));
    let hit = false;

    const cy = TF.DATA.CANAL.y;
    const halfCanal = TF.DATA.CANAL.w / 2 + radius + 6;
    if (Math.abs(ny - cy) < halfCanal && !this.isOnBridge(nx, ny)) {
      ny = prevY <= cy ? cy - halfCanal : cy + halfCanal;
      hit = true;
    }

    for (let i = 0; i < this.trees.length; i++) {
      const tr = this.trees[i];
      const dx = nx - tr.x;
      if (Math.abs(dx) > radius + tr.r + 4) continue;
      const dy = ny - tr.y;
      if (Math.abs(dy) > radius + tr.r + 4) continue;
      const d = Math.hypot(dx, dy);
      const minD = radius + tr.r * 0.72;
      if (d < minD && d > 0.001) {
        nx += (dx / d) * (minD - d);
        ny += (dy / d) * (minD - d);
        hit = true;
      }
    }

    for (let i = 0; i < this.houses.length; i++) {
      const h = this.houses[i];
      const cx = Math.max(h.x, Math.min(nx, h.x + h.w));
      const cy2 = Math.max(h.y, Math.min(ny, h.y + h.h));
      const dx = nx - cx, dy = ny - cy2, d = Math.hypot(dx, dy);
      if (d < radius && d > 0.001) { nx += (dx / d) * (radius - d); ny += (dy / d) * (radius - d); hit = true; }
    }

    for (let i = 0; i < TF.DATA.STATIONS.length; i++) {
      const s = TF.DATA.STATIONS[i];
      const cx = Math.max(s.x, Math.min(nx, s.x + s.w));
      const cy2 = Math.max(s.y, Math.min(ny, s.y + s.h));
      const dx = nx - cx, dy = ny - cy2, d = Math.hypot(dx, dy);
      if (d < radius && d > 0.001) { nx += (dx / d) * (radius - d); ny += (dy / d) * (radius - d); hit = true; }
    }

    return { x: nx, y: ny, hit };
  },

  initPrices() {
    for (const key in TF.DATA.CROPS) {
      const base = TF.DATA.CROPS[key].basePrice;
      this.prices[key] = Math.round(base * (0.92 + Math.random() * 0.16));
      this.prevPrices[key] = base;
    }
  },

  fluctuatePrices(seasonIdx) {
    for (const key in TF.DATA.CROPS) {
      this.prevPrices[key] = this.prices[key];
      const base = TF.DATA.CROPS[key].basePrice;
      const seasonBonus = seasonIdx === 3 ? 1.16 : (seasonIdx === 0 ? 1.08 : 1.0);
      this.prices[key] = Math.round(this.prices[key] * 0.4 + base * seasonBonus * (0.78 + Math.random() * 0.46) * 0.6);
    }
  },

  getSellPrice(cropId, station) {
    return Math.round((this.prices[cropId] || 300) * (station && station.priceMult ? station.priceMult : 1.0));
  },

  getFieldAt(x, y) {
    for (let i = 0; i < this.fields.length; i++) {
      const f = this.fields[i];
      if (x >= f.x && x < f.x + f.w && y >= f.y && y < f.y + f.h) return f;
    }
    return null;
  },

  getTileAt(field, x, y) {
    const c = Math.floor((x - field.x) / TF.DATA.TILE_SIZE);
    const r = Math.floor((y - field.y) / TF.DATA.TILE_SIZE);
    if (c < 0 || r < 0 || c >= field.cols || r >= field.rows) return null;
    return { col: c, row: r, idx: r * field.cols + c, tile: field.tiles[r * field.cols + c] };
  },

  getNearestVillageName(x, y) {
    let best = TF.DATA.VILLAGES[0], bestD = Infinity;
    for (const v of TF.DATA.VILLAGES) {
      const d = Math.hypot(v.x - x, v.y - y);
      if (d < bestD) { bestD = d; best = v; }
    }
    return best.name;
  },

  getStationAt(x, y, pad = 105) {
    for (const s of TF.DATA.STATIONS) {
      if (x >= s.x - pad && x <= s.x + s.w + pad && y >= s.y - pad && y <= s.y + s.h + pad) return s;
    }
    return null;
  },

  updateGrowth(deltaGameDays, seasonIdx) {
    const season = TF.DATA.SEASONS[seasonIdx];
    if (season.growthMult <= 0) return;
    const rainBoost = this.weather === 'rain' ? 1.25 : 1.0;
    for (const f of this.fields) {
      if (!f.owned && !TF.Game.isContractField(f.id)) continue;
      for (let i = 0; i < f.tiles.length; i++) {
        const t = f.tiles[i];
        if (t.state === 'seeded' && t.crop) {
          t.growth += (deltaGameDays * season.growthMult * rainBoost) / TF.DATA.CROPS[t.crop].growDays;
          if (t.growth >= 1) { t.growth = 1; t.state = 'ready'; }
        }
      }
    }
  },

  getFieldSummary(field) {
    let stubble = 0, plowed = 0, seeded = 0, ready = 0, fert = 0;
    let cropCounts = {};
    for (const t of field.tiles) {
      if (t.state === 'stubble') stubble++;
      else if (t.state === 'plowed') plowed++;
      else if (t.state === 'seeded') seeded++;
      else if (t.state === 'ready') ready++;
      if (t.fertilized) fert++;
      if (t.crop) cropCounts[t.crop] = (cropCounts[t.crop] || 0) + 1;
    }
    const total = field.tiles.length;
    let mainCrop = null, maxC = 0;
    for (const k in cropCounts) { if (cropCounts[k] > maxC) { maxC = cropCounts[k]; mainCrop = k; } }
    let status = 'Стерня (нужна вспашка)';
    if (ready > total * 0.15) status = 'Готово к уборке!';
    else if (seeded > total * 0.15) status = 'Растёт';
    else if (plowed > total * 0.15) status = 'Вспахано (можно сеять)';
    return { status, mainCrop, pctReady: Math.round((ready / total) * 100), pctFert: Math.round((fert / total) * 100), pctPlowed: Math.round((plowed / total) * 100), pctStubble: Math.round((stubble / total) * 100) };
  },

  // Скрытый лунный цикл (12 игровых дней): в новолуние ночь глубокая 0.87, в полнолуние мягче 0.58!
  getNightAlpha(hour, totalDays) {
    const moonWave = 0.5 + 0.5 * Math.sin(((totalDays % 12) / 12) * Math.PI * 2);
    const maxDark = 0.87 - moonWave * 0.27; // 0.60..0.87
    if (hour >= 7 && hour <= 18.5) return 0;
    if (hour > 18.5 && hour < 21.2) return ((hour - 18.5) / 2.7) * maxDark;
    if (hour >= 21.2 || hour <= 4.6) return maxDark;
    return ((7 - hour) / 2.4) * maxDark;
  },

  drawParkingLots(ctx, minX, maxX, minY, maxY) {
    const lots = TF.DATA.PARKING_LOTS;
    for (const key of ['base', 'shop']) {
      const lot = lots[key];
      if (lot.x + lot.w < minX || lot.x > maxX || lot.y + lot.h < minY || lot.y > maxY) continue;
      const unlocked = key === 'base' ? 4 : (TF.Game.shopParkingSlots || 0);

      // Бетонная плита парковки
      ctx.save();
      ctx.fillStyle = '#5c6260';
      ctx.fillRect(lot.x, lot.y, lot.w, lot.h);
      ctx.strokeStyle = '#d9dedc'; ctx.lineWidth = 2;
      ctx.strokeRect(lot.x, lot.y, lot.w, lot.h);

      lot.bays.forEach((bay, idx) => {
        const isLocked = idx >= unlocked;
        const occupied = TF.Vehicles.isBayOccupied(bay);
        ctx.fillStyle = isLocked ? 'rgba(20,20,20,0.45)' : (occupied ? 'rgba(210,80,60,0.22)' : 'rgba(79,184,90,0.22)');
        ctx.fillRect(bay.x - 42, bay.y - 26, 84, 52);
        ctx.strokeStyle = isLocked ? 'rgba(255,255,255,0.2)' : (occupied ? '#e06052' : '#74e382');
        ctx.lineWidth = 2;
        ctx.strokeRect(bay.x - 42, bay.y - 26, 84, 52);

        ctx.font = 'bold 12px system-ui, sans-serif'; ctx.textAlign = 'center';
        ctx.fillStyle = isLocked ? '#999' : '#fff';
        ctx.fillText(isLocked ? '🔒' : `P${idx + 1}`, bay.x, bay.y + 4);
      });

      ctx.font = 'bold 13px system-ui, sans-serif'; ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(14,20,16,0.85)';
      ctx.fillRect(lot.x + lot.w / 2 - 125, lot.y - 24, 250, 20);
      ctx.fillStyle = '#ffe07d';
      ctx.fillText(`🅿 ${lot.name} (${unlocked}/${lot.bays.length})`, lot.x + lot.w / 2, lot.y - 10);
      ctx.restore();
    }
  },

  draw(ctx, cam, viewW, viewH, seasonIdx, hour, nowSec) {
    const season = TF.DATA.SEASONS[seasonIdx];
    const isWinter = seasonIdx === 3;
    const isNight = hour >= 20 || hour <= 6;
    const minX = cam.x - (viewW / cam.zoom) * 0.65;
    const maxX = cam.x + (viewW / cam.zoom) * 0.65;
    const minY = cam.y - (viewH / cam.zoom) * 0.65;
    const maxY = cam.y + (viewH / cam.zoom) * 0.65;

    ctx.fillStyle = isWinter ? '#cfdce3' : (seasonIdx === 2 ? '#7b8749' : '#6c8a47');
    ctx.fillRect(minX, minY, maxX - minX, maxY - minY);

    for (const v of TF.DATA.VILLAGES) {
      const b = v.box;
      if (b.x + b.w < minX || b.x > maxX || b.y + b.h < minY || b.y > maxY) continue;
      ctx.fillStyle = isWinter ? '#c0d1d9' : '#5f7d40';
      ctx.fillRect(b.x, b.y, b.w, b.h);
    }

    ctx.save();
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#9e8b69';
    for (const st of this.villageStreets) {
      ctx.lineWidth = st.w;
      ctx.beginPath(); ctx.moveTo(st.x1, st.y1); ctx.lineTo(st.x2, st.y2); ctx.stroke();
    }
    ctx.restore();

    // Грунтовые заезды на все 22 поля (чётко видно, где въезжать!)
    ctx.save();
    ctx.fillStyle = '#9c8663';
    for (const f of this.fields) {
      const e = f.entrance;
      if (e.x < minX - 180 || e.x > maxX + 180 || e.y < minY - 180 || e.y > maxY + 180) continue;
      if (e.side === 'top' || e.side === 'bottom') {
        ctx.fillRect(e.x - 85, e.side === 'top' ? e.y - 110 : e.y, 170, 110);
      } else {
        ctx.fillRect(e.side === 'left' ? e.x - 110 : e.x, e.y - 85, 110, 170);
      }
    }
    ctx.restore();

    // Каховский канал (живая рябь воды)
    const cy = TF.DATA.CANAL.y, cw = TF.DATA.CANAL.w;
    if (cy + cw + 30 > minY && cy - cw - 30 < maxY) {
      ctx.fillStyle = '#8b918d'; ctx.fillRect(0, cy - cw / 2 - 12, TF.DATA.WORLD_W, cw + 24);
      ctx.fillStyle = '#6f7571'; ctx.fillRect(0, cy - cw / 2 - 4, TF.DATA.WORLD_W, cw + 8);
      ctx.fillStyle = isWinter ? '#9bc3d9' : '#1f6d9c'; ctx.fillRect(0, cy - cw / 2, TF.DATA.WORLD_W, cw);
      ctx.strokeStyle = isWinter ? 'rgba(255,255,255,0.32)' : 'rgba(135, 212, 255, 0.28)';
      ctx.lineWidth = 2;
      const startW = Math.max(0, Math.floor(minX / 90) * 90);
      const endW = Math.min(TF.DATA.WORLD_W, maxX + 90);
      const drift = (nowSec * 18) % 90;
      ctx.beginPath();
      for (let wx = startW; wx <= endW; wx += 90) {
        const rx = wx + drift;
        ctx.moveTo(rx, cy - 16); ctx.quadraticCurveTo(rx + 22, cy - 21, rx + 44, cy - 16);
        ctx.moveTo(rx + 30, cy + 12); ctx.quadraticCurveTo(rx + 52, cy + 17, rx + 74, cy + 12);
      }
      ctx.stroke();
    }

    // Дороги
    ctx.save();
    ctx.lineCap = 'square';
    const wet = this.soilWetness || 0;
    for (const r of TF.DATA.ROADS) {
      if (r.type !== 'dirt') continue;
      ctx.strokeStyle = wet > 0.35 ? '#6f5a3c' : '#a89069'; ctx.lineWidth = r.w;
      ctx.beginPath(); ctx.moveTo(r.x1, r.y1); ctx.lineTo(r.x2, r.y2); ctx.stroke();
    }
    for (const r of TF.DATA.ROADS) {
      if (r.type !== 'asphalt') continue;
      ctx.strokeStyle = '#736c5b'; ctx.lineWidth = r.w + 14;
      ctx.beginPath(); ctx.moveTo(r.x1, r.y1); ctx.lineTo(r.x2, r.y2); ctx.stroke();
      ctx.strokeStyle = '#44494f'; ctx.lineWidth = r.w;
      ctx.beginPath(); ctx.moveTo(r.x1, r.y1); ctx.lineTo(r.x2, r.y2); ctx.stroke();
      ctx.strokeStyle = 'rgba(245,245,245,0.68)'; ctx.lineWidth = 3; ctx.setLineDash([22, 20]); ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.restore();

    // Мосты
    for (const br of TF.DATA.BRIDGES) {
      ctx.save();
      ctx.fillStyle = '#9aa09e'; ctx.fillRect(br.x - br.w / 2 - 8, br.y - br.h / 2, br.w + 16, br.h);
      ctx.fillStyle = br.type === 'asphalt' ? '#44494f' : '#a89069'; ctx.fillRect(br.x - br.w / 2 + 4, br.y - br.h / 2, br.w - 8, br.h);
      ctx.fillStyle = '#d9dedc';
      ctx.fillRect(br.x - br.w / 2 - 8, br.y - br.h / 2, 8, br.h);
      ctx.fillRect(br.x + br.w / 2, br.y - br.h / 2, 8, br.h);
      if (br.type === 'asphalt') {
        ctx.strokeStyle = 'rgba(245,245,245,0.75)'; ctx.lineWidth = 3; ctx.setLineDash([14, 14]);
        ctx.beginPath(); ctx.moveTo(br.x, br.y - br.h / 2 + 6); ctx.lineTo(br.x, br.y + br.h / 2 - 6); ctx.stroke(); ctx.setLineDash([]);
      }
      ctx.restore();
    }

    // Поля
    const ts = TF.DATA.TILE_SIZE;
    for (const f of this.fields) {
      if (f.x + f.w < minX || f.x > maxX || f.y + f.h < minY || f.y > maxY) continue;
      ctx.fillStyle = '#4a3a26'; ctx.fillRect(f.x - 4, f.y - 4, f.w + 8, f.h + 8);
      const c0 = Math.max(0, Math.floor((minX - f.x) / ts)), c1 = Math.min(f.cols - 1, Math.ceil((maxX - f.x) / ts));
      const r0 = Math.max(0, Math.floor((minY - f.y) / ts)), r1 = Math.min(f.rows - 1, Math.ceil((maxY - f.y) / ts));

      for (let r = r0; r <= r1; r++) {
        for (let c = c0; c <= c1; c++) {
          const tile = f.tiles[r * f.cols + c];
          const tx = f.x + c * ts, ty = f.y + r * ts;
          let fill = wet > 0.35 ? '#8d7a4d' : '#a69260';
          if (tile.state === 'plowed') {
            fill = wet > 0.35 ? (tile.fertilized ? '#291c12' : '#3a291b') : (tile.fertilized ? '#3d2c1e' : '#57402c');
          } else if (tile.state === 'seeded' && tile.crop) {
            const cd = TF.DATA.CROPS[tile.crop];
            fill = tile.growth < 0.45 ? cd.colorYoung : cd.colorMid;
          } else if (tile.state === 'ready' && tile.crop) fill = TF.DATA.CROPS[tile.crop].colorRipe;
          ctx.fillStyle = fill; ctx.fillRect(tx, ty, ts, ts);
          if (tile.state === 'plowed' || tile.state === 'seeded') {
            ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(tx, ty + 10, ts, 3); ctx.fillRect(tx, ty + 26, ts, 3);
          }
          if (tile.fertilized && tile.state !== 'ready') {
            ctx.fillStyle = 'rgba(130, 225, 255, 0.28)'; ctx.fillRect(tx + 4, ty + 4, 6, 6);
          }
        }
      }
      const isContract = TF.Game.isContractField(f.id);
      ctx.strokeStyle = f.owned ? '#6ee87a' : (isContract ? '#4ba3e3' : 'rgba(255, 210, 90, 0.72)');
      ctx.lineWidth = (f.owned || isContract) ? 4 : 3;
      ctx.strokeRect(f.x, f.y, f.w, f.h);

      ctx.save();
      ctx.font = 'bold 20px system-ui, sans-serif'; ctx.textAlign = 'center';
      const label = f.owned ? `Поле №${f.id} (${f.ha} га)` : (isContract ? `📋 Контракт · Поле №${f.id}` : `Поле №${f.id} · $${f.price.toLocaleString('ru-RU')}`);
      const lw = ctx.measureText(label).width + 20;
      ctx.fillStyle = f.owned ? 'rgba(18, 42, 22, 0.8)' : (isContract ? 'rgba(18, 40, 62, 0.85)' : 'rgba(42, 30, 14, 0.82)');
      ctx.fillRect(f.x + f.w / 2 - lw / 2, f.y + f.h / 2 - 15, lw, 30);
      ctx.fillStyle = f.owned ? '#a8ffb0' : (isContract ? '#9ed7ff' : '#ffe07d');
      ctx.fillText(label, f.x + f.w / 2, f.y + f.h / 2 + 7);
      ctx.restore();
    }

    // Следы от колёс на полях и грунтовках (темнее по грязи)
    ctx.save();
    for (let i = 0; i < this.tracks.length; i++) {
      const tr = this.tracks[i];
      if (tr.x < minX || tr.x > maxX || tr.y < minY || tr.y > maxY) continue;
      ctx.fillStyle = tr.wet ? 'rgba(34, 24, 14, 0.22)' : 'rgba(48, 36, 22, 0.11)';
      ctx.save();
      ctx.translate(tr.x, tr.y);
      ctx.rotate(tr.angle);
      ctx.fillRect(-5, -tr.w * 0.42, 10, 3.6);
      ctx.fillRect(-5,  tr.w * 0.42 - 3.6, 10, 3.6);
      ctx.restore();
    }
    ctx.restore();

    // Реалистичные непрерывные валки соломы и измельчённая стерня из-под комбайна
    if (this.strawSegments.length > 0) {
      ctx.save();
      for (let i = 0; i < this.strawSegments.length; i++) {
        const s = this.strawSegments[i];
        if (s.x < minX - 40 || s.x > maxX + 40 || s.y < minY - 40 || s.y > maxY + 40) continue;
        ctx.save();
        ctx.translate(s.x, s.y);
        ctx.rotate(s.angle);
        if (s.type === 'swath') {
          const hl = s.len * 0.58;
          ctx.fillStyle = 'rgba(72, 54, 22, 0.24)';
          ctx.beginPath(); ctx.roundRect(-hl, -9, hl * 2, 18, 6); ctx.fill();
          ctx.fillStyle = '#cfa948';
          ctx.beginPath(); ctx.roundRect(-hl + 1, -7, hl * 2 - 2, 14, 5); ctx.fill();
          ctx.fillStyle = '#ebd37a';
          ctx.beginPath(); ctx.roundRect(-hl + 3, -4, hl * 2 - 6, 8, 4); ctx.fill();
          ctx.fillStyle = 'rgba(255, 246, 198, 0.68)';
          ctx.fillRect(-hl + 5, -1.5, hl * 2 - 10, 3);
        } else {
          ctx.fillStyle = 'rgba(136, 108, 56, 0.55)';
          ctx.fillRect(-10, -14, 7, 2.5); ctx.fillRect(2, -8, 8, 2.5);
          ctx.fillRect(-7, 6, 8, 2.5); ctx.fillRect(4, 12, 7, 2.5);
          ctx.fillStyle = 'rgba(196, 166, 94, 0.52)';
          ctx.fillRect(-2, -1, 6, 2); ctx.fillRect(-11, 1, 5, 2);
        }
        ctx.restore();
      }
      ctx.restore();
    }

    // Станции
    for (const s of TF.DATA.STATIONS) {
      if (s.x + s.w < minX - 60 || s.x > maxX + 60 || s.y + s.h < minY - 60 || s.y > maxY + 60) continue;
      ctx.fillStyle = '#6c7270'; ctx.fillRect(s.x - 16, s.y - 16, s.w + 32, s.h + 32);
      ctx.fillStyle = s.type === 'elevator' ? '#d9c998' : s.type === 'shop' ? '#2c5a82' : s.type === 'supply' ? '#3d7845' : '#8c4c30';
      ctx.fillRect(s.x, s.y, s.w, s.h);
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.strokeRect(s.x, s.y, s.w, s.h);
      ctx.strokeStyle = '#f5c71a'; ctx.lineWidth = 3; ctx.setLineDash([8, 6]); ctx.strokeRect(s.x - 24, s.y - 24, s.w + 48, s.h + 48); ctx.setLineDash([]);
      if (s.type === 'elevator') {
        ctx.fillStyle = '#e8e3d5';
        for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(s.x + 48 + k * 75, s.y + s.h / 2, 26, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#8b8778'; ctx.lineWidth = 2; ctx.stroke(); }
      }
      ctx.save();
      ctx.font = 'bold 15px system-ui, sans-serif'; ctx.textAlign = 'center';
      const tw = ctx.measureText(s.name).width + 16;
      ctx.fillStyle = 'rgba(15, 22, 18, 0.88)'; ctx.fillRect(s.x + s.w / 2 - tw / 2, s.y - 36, tw, 24);
      ctx.fillStyle = '#ffe07d'; ctx.fillText(s.name, s.x + s.w / 2, s.y - 19);
      ctx.restore();

      // Приёмная решётка (яма выгрузки) на элеваторах!
      if (s.type === 'elevator' && s.pitX) {
        ctx.save();
        ctx.fillStyle = '#252927';
        ctx.fillRect(s.pitX - 48, s.pitY - 26, 96, 52);
        // Металлические прутья решётки
        ctx.strokeStyle = '#555d59'; ctx.lineWidth = 2;
        for (let gx = s.pitX - 42; gx <= s.pitX + 42; gx += 10) {
          ctx.beginPath(); ctx.moveTo(gx, s.pitY - 24); ctx.lineTo(gx, s.pitY + 24); ctx.stroke();
        }
        // Жёлто-чёрная рамка зоны выгрузки
        ctx.strokeStyle = '#f5c71a'; ctx.lineWidth = 3; ctx.setLineDash([8, 6]);
        ctx.strokeRect(s.pitX - 52, s.pitY - 30, 104, 60);
        ctx.setLineDash([]);
        ctx.font = 'bold 11px system-ui, sans-serif'; ctx.textAlign = 'center';
        ctx.fillStyle = '#ffe07d';
        ctx.fillText('▼ ВЫГРУЗКА', s.pitX, s.pitY + 42);
        ctx.restore();
      }
    }

    // Размеченные парковки выдачи техники (Любимо-Павловка + Тавричанка)
    this.drawParkingLots(ctx, minX, maxX, minY, maxY);

    // Дома
    for (const h of this.houses) {
      if (h.x + 100 < minX || h.x - 20 > maxX || h.y + 80 < minY || h.y - 20 > maxY) continue;
      ctx.strokeStyle = 'rgba(72, 54, 34, 0.45)'; ctx.lineWidth = 2; ctx.strokeRect(h.yardX, h.yardY, h.yardW, h.yardH);
      ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(h.x + 5, h.y + 5, h.w, h.h);
      ctx.fillStyle = h.roof; ctx.fillRect(h.x, h.y, h.w, h.h);
      ctx.strokeStyle = 'rgba(255,255,255,0.28)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(h.x, h.y + h.h / 2); ctx.lineTo(h.x + h.w, h.y + h.h / 2); ctx.stroke();
      if (isNight) {
        ctx.fillStyle = 'rgba(255, 224, 130, 0.9)';
        ctx.fillRect(h.x + 10, h.y + h.h - 4, 12, 4);
        ctx.fillRect(h.x + h.w - 22, h.y + h.h - 4, 12, 4);
      }
    }

    // Лесополосы (с широкими проёмами-заездами на каждое поле!)
    const treeColors = isWinter ? ['#8fa399', '#7f948b', '#9cb0a7'] : ['#2d5a27', '#386b2f', '#244d20'];
    for (const tr of this.trees) {
      if (tr.x < minX - 40 || tr.x > maxX + 40 || tr.y < minY - 40 || tr.y > maxY + 40) continue;
      ctx.fillStyle = 'rgba(0,0,0,0.18)'; ctx.beginPath(); ctx.arc(tr.x + 5, tr.y + 5, tr.r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = treeColors[tr.shade]; ctx.beginPath(); ctx.arc(tr.x, tr.y, tr.r, 0, Math.PI * 2); ctx.fill();
    }

    ctx.save();
    ctx.font = '800 32px system-ui, sans-serif'; ctx.textAlign = 'center';
    for (const v of TF.DATA.VILLAGES) {
      const lx = v.box.x + v.box.w / 2, ly = v.box.y - 18;
      if (lx < minX - 300 || lx > maxX + 300 || ly < minY - 100 || ly > maxY + 100) continue;
      ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillText(v.name, lx + 2, ly + 2);
      ctx.fillStyle = '#ffffff'; ctx.fillText(v.name, lx, ly);
    }
    ctx.restore();

    if (season.skyTint) {
      ctx.fillStyle = season.skyTint;
      ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
    }
  }
};
