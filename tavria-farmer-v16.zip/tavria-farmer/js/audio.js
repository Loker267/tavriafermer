window.TF = window.TF || {};

// 3D-аудиодвижок v0.6: дизели, 3D-боты, ветер степи, ночные сверчки, дождь и звук перегрузки зерна!
TF.Audio = {
  ctx: null,
  master: null,
  muted: false,
  ready: false,
  noiseBuffer: null,
  whiteNoiseBuffer: null,
  playerEngine: null,
  botChannels: [],
  ambientWindGain: null,
  rainGain: null,
  grainGain: null,
  cricketTimer: 0,

  init() {
    const unlock = () => {
      if (this.ready) return;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.68;
        this.master.connect(this.ctx.destination);

        this.noiseBuffer = this.createBrownNoiseBuffer(2.0);
        this.whiteNoiseBuffer = this.createWhiteNoiseBuffer(2.0);
        this.playerEngine = this.createEngineRig();
        for (let i = 0; i < 4; i++) this.botChannels.push(this.createEngineRig());

        // 1. Внешний шум ветра Херсонской степи
        const windSrc = this.ctx.createBufferSource();
        windSrc.buffer = this.noiseBuffer; windSrc.loop = true;
        const windF = this.ctx.createBiquadFilter();
        windF.type = 'bandpass'; windF.frequency.value = 340; windF.Q.value = 0.7;
        this.ambientWindGain = this.ctx.createGain();
        this.ambientWindGain.gain.value = 0.045;
        windSrc.connect(windF); windF.connect(this.ambientWindGain); this.ambientWindGain.connect(this.master);
        windSrc.start();

        // 2. Звук дождя (мягкий шелест капель)
        const rainSrc = this.ctx.createBufferSource();
        rainSrc.buffer = this.whiteNoiseBuffer; rainSrc.loop = true;
        const rainF = this.ctx.createBiquadFilter();
        rainF.type = 'bandpass'; rainF.frequency.value = 1400; rainF.Q.value = 0.5;
        this.rainGain = this.ctx.createGain();
        this.rainGain.gain.value = 0;
        rainSrc.connect(rainF); rainF.connect(this.rainGain); this.rainGain.connect(this.master);
        rainSrc.start();

        // 3. Звук сыплющегося зерна при перегрузке из комбайна в прицеп
        const grSrc = this.ctx.createBufferSource();
        grSrc.buffer = this.whiteNoiseBuffer; grSrc.loop = true;
        const grF = this.ctx.createBiquadFilter();
        grF.type = 'bandpass'; grF.frequency.value = 2400; grF.Q.value = 1.2;
        this.grainGain = this.ctx.createGain();
        this.grainGain.gain.value = 0;
        grSrc.connect(grF); grF.connect(this.grainGain); this.grainGain.connect(this.master);
        grSrc.start();

        this.ready = true;
      } catch (e) { console.warn('Audio init skipped:', e); }
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
  },

  toggleMute() {
    this.muted = !this.muted;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(this.muted ? 0 : 0.68, this.ctx.currentTime, 0.05);
    return this.muted;
  },

  createBrownNoiseBuffer(seconds) {
    const sr = this.ctx.sampleRate, len = Math.floor(sr * seconds);
    const buf = this.ctx.createBuffer(1, len, sr), data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { last = (last + 0.08 * (Math.random() * 2 - 1)) / 1.08; data[i] = last * 3.2; }
    return buf;
  },

  createWhiteNoiseBuffer(seconds) {
    const sr = this.ctx.sampleRate, len = Math.floor(sr * seconds);
    const buf = this.ctx.createBuffer(1, len, sr), data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    return buf;
  },

  createEngineRig() {
    const ctx = this.ctx;
    const gain = ctx.createGain(); gain.gain.value = 0;
    const panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (panner) { gain.connect(panner); panner.connect(this.master); } else gain.connect(this.master);

    const osc = ctx.createOscillator(); osc.type = 'sawtooth'; osc.frequency.value = 34;
    const sub = ctx.createOscillator(); sub.type = 'triangle'; sub.frequency.value = 22;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 140; lp.Q.value = 2.0;
    const oscGain = ctx.createGain(); oscGain.gain.value = 0.26;
    osc.connect(lp); sub.connect(lp); lp.connect(oscGain); oscGain.connect(gain);

    const noise = ctx.createBufferSource(); noise.buffer = this.noiseBuffer; noise.loop = true;
    const noiseFilter = ctx.createBiquadFilter(); noiseFilter.type = 'bandpass'; noiseFilter.frequency.value = 185; noiseFilter.Q.value = 0.9;
    const noiseGain = ctx.createGain(); noiseGain.gain.value = 0.45;
    noise.connect(noiseFilter); noiseFilter.connect(noiseGain); noiseGain.connect(gain);

    osc.start(); sub.start(); noise.start();
    return { gain, panner, osc, sub, lp, noiseFilter, noiseGain };
  },

  playCricket() {
    if (!this.ready || this.muted) return;
    const now = this.ctx.currentTime;
    for (let k = 0; k < 3; k++) {
      const osc = this.ctx.createOscillator(), g = this.ctx.createGain();
      osc.type = 'sine'; osc.frequency.value = 4100 + Math.random() * 250;
      g.gain.setValueAtTime(0.015, now + k * 0.06);
      g.gain.exponentialRampToValueAtTime(0.0005, now + k * 0.06 + 0.045);
      osc.connect(g); g.connect(this.master);
      osc.start(now + k * 0.06); osc.stop(now + k * 0.06 + 0.05);
    }
  },

  update(cam, activeVehicle, allVehicles, dt = 0.016) {
    if (!this.ready || !this.ctx || this.muted) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();
    const now = this.ctx.currentTime;

    // Внешние звуки: дождь, ветер, ночные сверчки!
    const isRain = TF.World.weather === 'rain';
    this.rainGain.gain.setTargetAtTime(isRain ? 0.14 : 0, now, 0.4);
    this.ambientWindGain.gain.setTargetAtTime(isRain ? 0.08 : 0.045, now, 0.4);
    const isNight = TF.Game.hour >= 20.5 || TF.Game.hour <= 5.0;
    if (isNight && !isRain) {
      this.cricketTimer -= dt;
      if (this.cricketTimer <= 0) {
        this.playCricket();
        this.cricketTimer = 2.5 + Math.random() * 4.0;
      }
    }

    // Звук перегрузки зерна рядом с камерой
    let pouringVol = 0;
    if (TF.Vehicles.activeGrainStreams && TF.Vehicles.activeGrainStreams.length > 0) {
      for (const s of TF.Vehicles.activeGrainStreams) {
        const d = Math.hypot(s.x1 - cam.x, s.y1 - cam.y);
        if (d < 800) pouringVol = Math.max(pouringVol, (1 - d / 800) * 0.16);
      }
    }
    this.grainGain.gain.setTargetAtTime(pouringVol, now, 0.08);

    // 1. Активная техника
    if (activeVehicle) {
      const def = TF.DATA.getItem(activeVehicle.modelId);
      const dead = activeVehicle.fuel <= 0 || activeVehicle.wear >= 100 || activeVehicle.broken;
      if (dead) {
        this.playerEngine.gain.gain.setTargetAtTime(0, now, 0.12);
      } else {
        const speedFrac = Math.min(1, Math.abs(activeVehicle.speed) / Math.max(1, def.maxSpeed));
        const isWorking = activeVehicle.working || (activeVehicle.attachment && TF.Vehicles.getByUid(activeVehicle.attachment)?.working);
        const baseFreq = def.hp > 400 ? 27 : (def.hp > 150 ? 32 : 38);
        const rpmFreq = baseFreq + speedFrac * 24 + (isWorking ? 7 : 0);
        this.playerEngine.osc.frequency.setTargetAtTime(rpmFreq, now, 0.08);
        this.playerEngine.sub.frequency.setTargetAtTime(rpmFreq * 0.5, now, 0.08);
        this.playerEngine.lp.frequency.setTargetAtTime(125 + speedFrac * 140 + (isWorking ? 60 : 0), now, 0.08);
        this.playerEngine.noiseFilter.frequency.setTargetAtTime(isWorking ? 280 : 165 + speedFrac * 90, now, 0.1);
        this.playerEngine.noiseGain.gain.setTargetAtTime(isWorking ? 0.65 : 0.35 + speedFrac * 0.2, now, 0.1);
        this.playerEngine.gain.gain.setTargetAtTime(0.16 + speedFrac * 0.18 + (isWorking ? 0.12 : 0), now, 0.08);
      }
    }

    // 2. 3D-звук ближайших ботов
    const bots = allVehicles
      .filter(v => v !== activeVehicle && (v.category === 'tractor' || v.category === 'combine') && (v.ai || Math.abs(v.speed) > 4 || v.working) && v.fuel > 0 && !v.broken)
      .map(v => ({ v, dist: Math.hypot(v.x - cam.x, v.y - cam.y) }))
      .filter(o => o.dist < 1350)
      .sort((a, b) => a.dist - b.dist);

    for (let i = 0; i < this.botChannels.length; i++) {
      const ch = this.botChannels[i];
      if (i < bots.length) {
        const { v, dist } = bots[i];
        const def = TF.DATA.getItem(v.modelId);
        const atten = Math.max(0, 1 / (1 + Math.pow(dist / 350, 1.7)) - 0.04);
        const pan = Math.max(-1, Math.min(1, (v.x - cam.x) / 680));
        const isWorking = v.working || (v.attachment && TF.Vehicles.getByUid(v.attachment)?.working);
        const baseFreq = def.hp > 400 ? 27 : 34;
        ch.osc.frequency.setTargetAtTime(baseFreq + (isWorking ? 14 : 8), now, 0.1);
        ch.sub.frequency.setTargetAtTime(baseFreq * 0.5, now, 0.1);
        ch.noiseFilter.frequency.setTargetAtTime(v.category === 'combine' && isWorking ? 320 : 190, now, 0.1);
        ch.gain.gain.setTargetAtTime(atten * (isWorking ? 0.40 : 0.25), now, 0.1);
        if (ch.panner) ch.panner.pan.setTargetAtTime(pan, now, 0.08);
      } else {
        ch.gain.gain.setTargetAtTime(0, now, 0.12);
      }
    }
  },

  playHitch() {
    if (!this.ready || this.muted) return;
    const now = this.ctx.currentTime, osc = this.ctx.createOscillator(), g = this.ctx.createGain();
    osc.type = 'triangle'; osc.frequency.setValueAtTime(210, now); osc.frequency.exponentialRampToValueAtTime(75, now + 0.14);
    g.gain.setValueAtTime(0.35, now); g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(g); g.connect(this.master); osc.start(now); osc.stop(now + 0.2);
  },

  playBump() {
    if (!this.ready || this.muted) return;
    const now = this.ctx.currentTime, osc = this.ctx.createOscillator(), g = this.ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(95, now); osc.frequency.exponentialRampToValueAtTime(32, now + 0.16);
    g.gain.setValueAtTime(0.4, now); g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    osc.connect(g); g.connect(this.master); osc.start(now); osc.stop(now + 0.2);
  },

  playBreakdown() {
    if (!this.ready || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator(), g1 = this.ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(140, now); osc.frequency.exponentialRampToValueAtTime(28, now + 0.45);
    g1.gain.setValueAtTime(0.5, now); g1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    osc.connect(g1); g1.connect(this.master); osc.start(now); osc.stop(now + 0.52);

    const hiss = this.ctx.createBufferSource(); hiss.buffer = this.noiseBuffer;
    const hp = this.ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 900;
    const g2 = this.ctx.createGain(); g2.gain.setValueAtTime(0.45, now + 0.08); g2.gain.exponentialRampToValueAtTime(0.001, now + 1.3);
    hiss.connect(hp); hp.connect(g2); g2.connect(this.master); hiss.start(now + 0.08); hiss.stop(now + 1.35);
  },

  playCash() {
    if (!this.ready || this.muted) return;
    const now = this.ctx.currentTime;
    [520, 680].forEach((freq, idx) => {
      const osc = this.ctx.createOscillator(), g = this.ctx.createGain();
      osc.type = 'sine'; osc.frequency.setValueAtTime(freq, now + idx * 0.08);
      g.gain.setValueAtTime(0.18, now + idx * 0.08); g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.22);
      osc.connect(g); g.connect(this.master); osc.start(now + idx * 0.08); osc.stop(now + idx * 0.08 + 0.24);
    });
  }
};
