const CACHE_NAME = 'tavria-farmer-v1.6.0';
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/version.js',
  './js/shop_images.js',
  './js/data.js',
  './js/audio.js',
  './assets/radio/playlist.js',
  './js/radio.js',
  './js/world.js',
  './js/models.js',
  './js/vehicles.js',
  './js/ai.js',
  './js/ui.js',
  './js/updater.js',
  './js/main.js',
  './assets/audio/diesel_loop.mp3',
  './assets/audio/combine_thresh.mp3',
  './assets/audio/hitch_clank.mp3',
  './assets/audio/breakdown.mp3',
  './assets/radio/steppe_breeze.mp3',
  './assets/radio/harvest_groove.mp3'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS).catch(() => {}))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = event.request.url;
  // Никогда не кэшируем проверку обновлений с GitHub!
  if (url.includes('raw.githubusercontent.com') || url.includes('version.json')) {
    return;
  }
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((resp) => {
        if (resp && resp.status === 200 && resp.type === 'basic') {
          const copy = resp.clone();
          caches.open(CACHE_NAME).then((c) => c.put(event.request, copy)).catch(() => {});
        }
        return resp;
      }).catch(() => cached);
    })
  );
});
